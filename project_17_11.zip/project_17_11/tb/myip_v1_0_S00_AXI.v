`timescale 1 ns / 1 ps
//==============================================================================
// myip_v1_0_S00_AXI : AXI4-Lite slave bao quanh ntt_ip_v1_0 (NTT/INTT ML-KEM)
//
// BAN DO THANH GHI (byte offset tu base address, moi word 32 bit = 4 byte):
//   0x000  CTRL    (R/W) bit0 = START (ghi 1 -> tao 1 xung start, tu xoa)
//                        bit1 = MODE  (0 = NTT, 1 = INTT)
//   0x004  STATUS  (R)   bit0 = BUSY, bit1 = DONE
//   0x400 + 4*i  DIN [i]  (R/W) he so vao  i = 0..255 (12 bit thap)
//   0x800 + 4*i  DOUT[i]  (R)   he so ra   i = 0..255 (12 bit thap)
//
// => C_S_AXI_ADDR_WIDTH = 12 (4 KB)
//==============================================================================
module myip_v1_0_S00_AXI #
(
    parameter integer C_S_AXI_DATA_WIDTH = 32,
    parameter integer C_S_AXI_ADDR_WIDTH = 12
)
(
    input  wire                                  S_AXI_ACLK,
    input  wire                                  S_AXI_ARESETN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0]         S_AXI_AWADDR,
    input  wire [2:0]                            S_AXI_AWPROT,
    input  wire                                  S_AXI_AWVALID,
    output wire                                  S_AXI_AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0]         S_AXI_WDATA,
    input  wire [(C_S_AXI_DATA_WIDTH/8)-1:0]     S_AXI_WSTRB,
    input  wire                                  S_AXI_WVALID,
    output wire                                  S_AXI_WREADY,
    output wire [1:0]                            S_AXI_BRESP,
    output wire                                  S_AXI_BVALID,
    input  wire                                  S_AXI_BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0]         S_AXI_ARADDR,
    input  wire [2:0]                            S_AXI_ARPROT,
    input  wire                                  S_AXI_ARVALID,
    output wire                                  S_AXI_ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0]         S_AXI_RDATA,
    output wire [1:0]                            S_AXI_RRESP,
    output wire                                  S_AXI_RVALID,
    input  wire                                  S_AXI_RREADY
);
    localparam integer ADDR_LSB = 2;            // 32 bit -> 4 byte/word -> bo 2 bit thap

    //---------------- AXI4-Lite handshake (kieu template cua Vivado) ----------------
    reg                          axi_awready, axi_wready, axi_bvalid, axi_arready, axi_rvalid, aw_en;
    reg [1:0]                    axi_bresp, axi_rresp;
    reg [C_S_AXI_ADDR_WIDTH-1:0] axi_awaddr, axi_araddr;
    reg [C_S_AXI_DATA_WIDTH-1:0] axi_rdata;

    assign S_AXI_AWREADY = axi_awready;
    assign S_AXI_WREADY  = axi_wready;
    assign S_AXI_BRESP   = axi_bresp;
    assign S_AXI_BVALID  = axi_bvalid;
    assign S_AXI_ARREADY = axi_arready;
    assign S_AXI_RDATA   = axi_rdata;
    assign S_AXI_RRESP   = axi_rresp;
    assign S_AXI_RVALID  = axi_rvalid;

    // ---- kenh ghi ----
    always @(posedge S_AXI_ACLK) begin
        if (!S_AXI_ARESETN) begin axi_awready <= 1'b0; aw_en <= 1'b1; end
        else begin
            if (~axi_awready && S_AXI_AWVALID && S_AXI_WVALID && aw_en) begin
                axi_awready <= 1'b1; aw_en <= 1'b0;
            end else if (S_AXI_BREADY && axi_bvalid) begin
                aw_en <= 1'b1; axi_awready <= 1'b0;
            end else axi_awready <= 1'b0;
        end
    end
    always @(posedge S_AXI_ACLK) begin
        if (!S_AXI_ARESETN) axi_awaddr <= 0;
        else if (~axi_awready && S_AXI_AWVALID && S_AXI_WVALID && aw_en) axi_awaddr <= S_AXI_AWADDR;
    end
    always @(posedge S_AXI_ACLK) begin
        if (!S_AXI_ARESETN) axi_wready <= 1'b0;
        else if (~axi_wready && S_AXI_WVALID && S_AXI_AWVALID && aw_en) axi_wready <= 1'b1;
        else axi_wready <= 1'b0;
    end
    wire slv_reg_wren = axi_wready && S_AXI_WVALID && axi_awready && S_AXI_AWVALID;

    always @(posedge S_AXI_ACLK) begin
        if (!S_AXI_ARESETN) begin axi_bvalid <= 1'b0; axi_bresp <= 2'b00; end
        else if (axi_awready && S_AXI_AWVALID && ~axi_bvalid && axi_wready && S_AXI_WVALID) begin
            axi_bvalid <= 1'b1; axi_bresp <= 2'b00;
        end else if (S_AXI_BREADY && axi_bvalid) axi_bvalid <= 1'b0;
    end

    // ---- kenh doc ----
    always @(posedge S_AXI_ACLK) begin
        if (!S_AXI_ARESETN) begin axi_arready <= 1'b0; axi_araddr <= 0; end
        else if (~axi_arready && S_AXI_ARVALID) begin axi_arready <= 1'b1; axi_araddr <= S_AXI_ARADDR; end
        else axi_arready <= 1'b0;
    end
    always @(posedge S_AXI_ACLK) begin
        if (!S_AXI_ARESETN) begin axi_rvalid <= 1'b0; axi_rresp <= 2'b00; end
        else if (axi_arready && S_AXI_ARVALID && ~axi_rvalid) begin axi_rvalid <= 1'b1; axi_rresp <= 2'b00; end
        else if (axi_rvalid && S_AXI_RREADY) axi_rvalid <= 1'b0;
    end
    wire slv_reg_rden = axi_arready & S_AXI_ARVALID & ~axi_rvalid;

    //---------------- core NTT + 2 mang nho (thay cho mem_in / mem_out cua testbench) ----------------
    reg        mode_reg;                    // CTRL[1]
    reg        start_pulse;                 // CTRL[0] -> 1 xung
    wire       core_busy, core_done;

    wire [7:0]  ext_addr;
    wire        ext_ready, ext_rvalid;
    wire [11:0] ext_rdata, ext_din;

    reg [11:0] mem_in  [0:255];             // PS ghi vao qua AXI
    reg [11:0] mem_out [0:255];             // core ghi ket qua, PS doc qua AXI

    wire [7:0] wr_idx = axi_awaddr[ADDR_LSB+7:ADDR_LSB];   // [9:2]
    wire [1:0] wr_sel = axi_awaddr[11:10];
    wire [7:0] rd_idx = axi_araddr[ADDR_LSB+7:ADDR_LSB];
    wire [1:0] rd_sel = axi_araddr[11:10];

    // PS ghi mem_in
    always @(posedge S_AXI_ACLK)
        if (slv_reg_wren && wr_sel == 2'b01) mem_in[wr_idx] <= S_AXI_WDATA[11:0];

    // PS ghi CTRL
    always @(posedge S_AXI_ACLK) begin
        start_pulse <= 1'b0;                                  // mac dinh tu xoa
        if (!S_AXI_ARESETN) mode_reg <= 1'b0;
        else if (slv_reg_wren && wr_sel == 2'b00 && axi_awaddr[ADDR_LSB+1:ADDR_LSB] == 2'd0) begin
            mode_reg    <= S_AXI_WDATA[1];
            start_pulse <= S_AXI_WDATA[0];
        end
    end

    // BAT TAY phia core:  mang vao tra ext_din = mem_in[ext_addr] (tuc thoi),  ext_wr_en = ext_ready
    assign ext_din = mem_in[ext_addr];

    // mang ra: luu moi he so khi ext_rvalid  (giong tb: mem_out[ext_addr] = ext_rdata)
    always @(posedge S_AXI_ACLK)
        if (ext_rvalid) mem_out[ext_addr] <= ext_rdata;

    ntt_ip_v1_0 u_core (
        .clk       (S_AXI_ACLK),
        .rst_n     (S_AXI_ARESETN),
        .start     (start_pulse),
        .mode      (mode_reg),
        .ext_wr_en (ext_ready),
        .ext_din   (ext_din),
        .ext_addr  (ext_addr),
        .ext_ready (ext_ready),
        .ext_rdata (ext_rdata),
        .ext_rvalid(ext_rvalid),
        .busy      (core_busy),
        .done      (core_done),
        .dbg_state_top(),
        .dbg_state_bf ()
    );

    //---------------- doc thanh ghi ----------------
    reg [C_S_AXI_DATA_WIDTH-1:0] reg_data_out;
    always @(*) begin
        reg_data_out = 0;
        case (rd_sel)
            2'b00: case (axi_araddr[ADDR_LSB+1:ADDR_LSB])
                       2'd0: reg_data_out = {30'd0, mode_reg, 1'b0};
                       2'd1: reg_data_out = {30'd0, core_done, core_busy};
                       default: reg_data_out = 0;
                   endcase
            2'b01: reg_data_out = {20'd0, mem_in [rd_idx]};
            2'b10: reg_data_out = {20'd0, mem_out[rd_idx]};
            default: reg_data_out = 0;
        endcase
    end
    always @(posedge S_AXI_ACLK) begin
        if (!S_AXI_ARESETN) axi_rdata <= 0;
        else if (slv_reg_rden) axi_rdata <= reg_data_out;
    end
endmodule