`timescale 1ns/1ps
//==============================================================================
// tb_myip_axi_full : TESTBENCH AXI4-Lite DAY DU cho myip_v1_0 (NTT/INTT ML-KEM, q = 3329)
//
//   Gia lap CPU (AXI master) -> myip_v1_0 -> myip_v1_0_S00_AXI -> u_core (ntt_ip_v1_0)
//
//   T1  gia tri sau reset (CTRL, STATUS)
//   T2  thanh ghi: ghi/doc lai DIN, CTRL, STATUS chi doc, bit cao cua DIN bi cat
//   T3  1 mach tu FILE: NTT(ntt_input_single) == ntt_expected_single
//                       INTT(ket qua NTT)     == intt_expected_single (= dau vao)
//                       DIN khong bi core pha; DOUT la chi doc
//   T4  NCASES bo du lieu tu ntt_input_100cases.txt (moi bo 256 he so, chay lien tiep, khong reset):
//                       NTT == mo hinh vang FIPS 203 Alg.9 ; INTT(NTT(x)) == x
//
//   FILE RA (DATA_DIR): axi_ntt.txt  = 256 he so doc tu DOUT sau NTT  (qua AXI)
//                       axi_intt.txt = 256 he so doc tu DOUT sau INTT (qua AXI)
//                       moi dong 1 he so hex, cung dinh dang intt_output_single.txt
//
//   Ban do dia chi (byte offset): CTRL 0x000 | STATUS 0x004 | DIN 0x400+4i | DOUT 0x800+4i
//
//   SUA DONG `define DATA_DIR ben duoi cho dung thu muc data (dung dau / va co / o cuoi).
//   Giam NCASES (vd 10) neu mo phong lau.
//==============================================================================
`ifndef DATA_DIR
`define DATA_DIR "D:/ntt_ipcore_mlkem_1_11/ntt_ipcore_mlkem/data/"
`endif

module tb_myip_axi_full;
    parameter integer NCASES = 100;                 // 0 = bo qua T4 (toi da 100)

    localparam [63:0] Q   = 64'd3329;
    localparam [11:0] F12 = 12'd3303;               // 128^-1 mod 3329
    localparam [11:0] A_CTRL = 12'h000, A_STAT = 12'h004, A_DIN = 12'h400, A_DOUT = 12'h800;

    //---------------- clock / reset / AXI master ----------------
    reg clk = 1'b0;  always #5 clk = ~clk;          // 100 MHz
    reg aresetn = 1'b0;

    reg  [11:0] awaddr = 0;  reg awvalid = 0;  wire awready;
    reg  [31:0] wdata  = 0;  reg [3:0] wstrb = 4'hF;  reg wvalid = 0;  wire wready;
    wire [1:0]  bresp;       wire bvalid;      reg bready = 1;
    reg  [11:0] araddr = 0;  reg arvalid = 0;  wire arready;
    wire [31:0] rdata;       wire [1:0] rresp; wire rvalid;  reg rready = 1;

    myip_v1_0 #(.C_S00_AXI_DATA_WIDTH(32), .C_S00_AXI_ADDR_WIDTH(12)) dut (
        .s00_axi_aclk   (clk),     .s00_axi_aresetn(aresetn),
        .s00_axi_awaddr (awaddr),  .s00_axi_awprot (3'b000), .s00_axi_awvalid(awvalid), .s00_axi_awready(awready),
        .s00_axi_wdata  (wdata),   .s00_axi_wstrb  (wstrb),  .s00_axi_wvalid (wvalid),  .s00_axi_wready (wready),
        .s00_axi_bresp  (bresp),   .s00_axi_bvalid (bvalid), .s00_axi_bready (bready),
        .s00_axi_araddr (araddr),  .s00_axi_arprot (3'b000), .s00_axi_arvalid(arvalid), .s00_axi_arready(arready),
        .s00_axi_rdata  (rdata),   .s00_axi_rresp  (rresp),  .s00_axi_rvalid (rvalid),  .s00_axi_rready (rready));

    integer errors = 0;

    //---------------- AXI4-Lite master tasks ----------------
    // Quy uoc lay mau: sau @(posedge clk) doc tin hieu = gia tri TRUOC canh (dung nhu flip-flop).
    task axi_write(input [11:0] addr, input [31:0] data);
        reg aw_ok, w_ok, b_ok; integer tmo;
        begin
            @(posedge clk); #1;
            awaddr = addr; awvalid = 1; wdata = data; wvalid = 1; wstrb = 4'hF;
            aw_ok = 0; w_ok = 0; tmo = 0;
            while (!(aw_ok && w_ok) && tmo < 1000) begin           // bat tay AW + W
                @(posedge clk);
                if (awvalid && awready) aw_ok = 1;
                if (wvalid  && wready ) w_ok  = 1;
                #1;
                if (aw_ok) awvalid = 0;
                if (w_ok)  wvalid  = 0;
                tmo = tmo + 1;
            end
            awvalid = 0; wvalid = 0;
            if (!(aw_ok && w_ok)) begin errors = errors + 1; $display("[FAIL] axi_write 0x%03h: timeout AW/W", addr); end
            b_ok = 0; tmo = 0;
            while (!b_ok && tmo < 1000) begin                       // bat tay B
                @(posedge clk);
                if (bvalid && bready) begin
                    b_ok = 1;
                    if (bresp !== 2'b00) begin errors = errors + 1; $display("[FAIL] axi_write 0x%03h: BRESP=%0d", addr, bresp); end
                end
                tmo = tmo + 1;
            end
            if (!b_ok) begin errors = errors + 1; $display("[FAIL] axi_write 0x%03h: timeout BVALID", addr); end
        end
    endtask

    task axi_read(input [11:0] addr, output [31:0] data);
        reg ar_ok, r_ok; integer tmo;
        begin
            @(posedge clk); #1;
            araddr = addr; arvalid = 1; ar_ok = 0; tmo = 0;
            while (!ar_ok && tmo < 1000) begin                      // bat tay AR
                @(posedge clk);
                if (arvalid && arready) ar_ok = 1;
                #1;
                tmo = tmo + 1;
            end
            arvalid = 0;
            if (!ar_ok) begin errors = errors + 1; $display("[FAIL] axi_read 0x%03h: timeout ARREADY", addr); end
            r_ok = 0; tmo = 0; data = 32'hDEADBEEF;
            while (!r_ok && tmo < 1000) begin                       // bat tay R
                @(posedge clk);
                if (rvalid && rready) begin
                    r_ok = 1; data = rdata;
                    if (rresp !== 2'b00) begin errors = errors + 1; $display("[FAIL] axi_read 0x%03h: RRESP=%0d", addr, rresp); end
                end
                tmo = tmo + 1;
            end
            if (!r_ok) begin errors = errors + 1; $display("[FAIL] axi_read 0x%03h: timeout RVALID", addr); end
        end
    endtask

    task expect32(input [8*32-1:0] name, input [11:0] addr, input [31:0] exp);
        reg [31:0] d;
        begin
            axi_read(addr, d);
            if (d !== exp) begin errors = errors + 1; $display("  [FAIL] %0s @0x%03h: doc %08h, mong doi %08h", name, addr, d, exp); end
            else $display("  [ OK ] %0s @0x%03h = %08h", name, addr, d);
        end
    endtask

    //---------------- du lieu + mo hinh vang (FIPS 203) ----------------
    reg [11:0] in_buf [0:255];          // he so dau vao dang thu
    reg [11:0] res    [0:255];          // ket qua doc tu DOUT
    reg [11:0] gold   [0:255];
    reg [11:0] in_single [0:255], exp_single [0:255], intt_exp_single [0:255];
    reg [11:0] big [0:25599];           // 100 bo x 256 he so
    reg [11:0] ntt_keep [0:255];

    function [11:0] g_mul(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t * b; g_mul = t % Q; end endfunction
    function [11:0] g_add(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t + b; g_add = t % Q; end endfunction
    function [11:0] g_sub(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t + Q - b; g_sub = t % Q; end endfunction
    function [11:0] g_zeta(input [6:0] k);
        reg [6:0] rev; reg [63:0] r, bb; integer i;
        begin
            for (i = 0; i < 7; i = i + 1) rev[i] = k[6-i];
            r = 1; bb = 17;
            for (i = 0; i < 7; i = i + 1) begin
                if (rev[i]) r = (r * bb) % Q;
                bb = (bb * bb) % Q;
            end
            g_zeta = r;
        end
    endfunction
    task golden_ntt;                                   // Algorithm 9
        integer m, len, start_, j; reg [11:0] z, t;
        begin
            m = 1; len = 128;
            while (len >= 2) begin
                start_ = 0;
                while (start_ < 256) begin
                    z = g_zeta(m); m = m + 1;
                    for (j = start_; j < start_ + len; j = j + 1) begin
                        t = g_mul(z, gold[j + len]);
                        gold[j + len] = g_sub(gold[j], t);
                        gold[j]       = g_add(gold[j], t);
                    end
                    start_ = start_ + 2 * len;
                end
                len = len / 2;
            end
        end
    endtask

    //---------------- cac tac vu cap cao ----------------
    task load_din;                                     // CPU ghi 256 he so vao DIN
        integer i;
        begin for (i = 0; i < 256; i = i + 1) axi_write(A_DIN + 4*i, {20'd0, in_buf[i]}); end
    endtask

    task read_dout;                                    // CPU doc 256 he so tu DOUT
        integer i; reg [31:0] d;
        begin
            for (i = 0; i < 256; i = i + 1) begin
                axi_read(A_DOUT + 4*i, d);
                res[i] = d[11:0];
                if (d[31:12] !== 20'd0) begin errors = errors + 1; $display("  [FAIL] DOUT[%0d] bit cao != 0: %08h", i, d); end
            end
        end
    endtask

    task run_core(input m);                            // m: 0 = NTT, 1 = INTT ; ghi CTRL roi poll DONE
        reg [31:0] s; integer n; reg saw_busy;
        begin
            axi_write(A_CTRL, {30'd0, m, 1'b1});       // START + MODE
            saw_busy = 0; s = 0; n = 0;
            while (!s[1] && n < 20000) begin
                axi_read(A_STAT, s);
                if (s[0]) saw_busy = 1;
                n = n + 1;
            end
            if (!s[1]) begin errors = errors + 1; $display("  [FAIL] timeout cho DONE (%0d lan poll)", n); end
            else begin
                if (!saw_busy) begin errors = errors + 1; $display("  [FAIL] khong thay BUSY=1 trong luc chay"); end
                if (s[0])      begin errors = errors + 1; $display("  [FAIL] DONE=1 nhung BUSY van = 1 (STATUS=%08h)", s); end
                $display("  --- DONE sau %0d lan poll, STATUS = %08h, t = %0t", n, s, $time);
            end
        end
    endtask

    task write_res_file(input [8*256-1:0] fn);         // ghi res[0..255], moi dong 1 he so hex
        integer i, fd;
        begin
            fd = $fopen(fn, "w");
            if (fd == 0) begin errors = errors + 1; $display("  [FAIL] khong mo duoc file de ghi: %0s", fn); end
            else begin
                for (i = 0; i < 256; i = i + 1) $fdisplay(fd, "%03x", res[i]);
                $fclose(fd);
                $display("  --- da ghi 256 he so ra %0s", fn);
            end
        end
    endtask

    task compare_res(input [8*32-1:0] name);           // res[] so voi gold[]
        integer i, mism;
        begin
            mism = 0;
            for (i = 0; i < 256; i = i + 1)
                if (res[i] !== gold[i]) begin
                    mism = mism + 1;
                    if (mism <= 5) $display("  [FAIL] %0s [%0d] DUT=%0d (0x%03h) GOLD=%0d (0x%03h)", name, i, res[i], res[i], gold[i], gold[i]);
                end
            if (mism == 0) $display("  [ OK ] %0s : 256/256 he so khop (res[0]=%0d res[255]=%0d)", name, res[0], res[255]);
            else begin errors = errors + 1; $display("  [FAIL] %0s : lech %0d / 256 he so", name, mism); end
        end
    endtask

    task verify_din_readback(input [8*32-1:0] name);   // DIN phai giu nguyen dau vao
        integer i, mism; reg [31:0] d;
        begin
            mism = 0;
            for (i = 0; i < 256; i = i + 1) begin
                axi_read(A_DIN + 4*i, d);
                if (d !== {20'd0, in_buf[i]}) begin mism = mism + 1; if (mism <= 5) $display("  [FAIL] DIN[%0d] = %08h, mong doi %03h", i, d, in_buf[i]); end
            end
            if (mism == 0) $display("  [ OK ] %0s : DIN doc lai khop 256/256", name);
            else begin errors = errors + 1; $display("  [FAIL] %0s : DIN lech %0d", name, mism); end
        end
    endtask

    //---------------- kich ban ----------------
    integer n, c, nx, mism_file;
    reg [31:0] d;
    integer fails_before;
    reg [8*256-1:0] fname;

    initial begin
        #400_000_000;
        $display("[FAIL] WATCHDOG: mo phong qua lau"); $finish;
    end

    initial begin
        // ---------------- doc file ----------------
        fname = {`DATA_DIR, "ntt_input_single.txt"};     $readmemh(fname, in_single);
        fname = {`DATA_DIR, "ntt_expected_single.txt"};  $readmemh(fname, exp_single);
        fname = {`DATA_DIR, "intt_expected_single.txt"}; $readmemh(fname, intt_exp_single);
        nx = 0;
        for (n = 0; n < 256; n = n + 1) if (^in_single[n] === 1'bx || ^exp_single[n] === 1'bx || ^intt_exp_single[n] === 1'bx) nx = nx + 1;
        if (nx != 0) begin
            $display("[FAIL] doc file that bai (%0d o X) - kiem tra DATA_DIR = %0s", nx, `DATA_DIR);
            $finish;
        end
        if (NCASES > 0) begin fname = {`DATA_DIR, "ntt_input_100cases.txt"}; $readmemh(fname, big); end

        // ---------------- reset ----------------
        aresetn = 0; repeat (10) @(posedge clk); #1 aresetn = 1; repeat (5) @(posedge clk);

        //------------------------------------------------------------------
        $display("\n########## T1: GIA TRI SAU RESET ##########");
        expect32("CTRL   sau reset", A_CTRL, 32'h0);
        expect32("STATUS sau reset", A_STAT, 32'h0);

        //------------------------------------------------------------------
        $display("\n########## T2: THANH GHI ##########");
        axi_write(A_DIN + 4*0,   32'hFFFFF123); expect32("DIN[0]   cat 12 bit", A_DIN + 4*0,   32'h0000_0123);
        axi_write(A_DIN + 4*255, 32'h00000ABC); expect32("DIN[255] bien cuoi",  A_DIN + 4*255, 32'h0000_0ABC);
        axi_write(A_DIN + 4*128, 32'h00000555); expect32("DIN[128] giua",       A_DIN + 4*128, 32'h0000_0555);
        axi_write(A_CTRL, 32'h2);               expect32("CTRL ghi MODE=1",     A_CTRL, 32'h2);
        axi_write(A_CTRL, 32'h0);               expect32("CTRL ghi MODE=0",     A_CTRL, 32'h0);
        axi_write(A_STAT, 32'hFFFFFFFF);        expect32("STATUS chi doc",      A_STAT, 32'h0);
        expect32("CTRL khong bi STATUS lam hong", A_CTRL, 32'h0);

        //------------------------------------------------------------------
        $display("\n########## T3: 1 MACH TU FILE (NTT roi INTT) ##########");
        for (n = 0; n < 256; n = n + 1) begin in_buf[n] = in_single[n]; gold[n] = in_single[n]; end
        golden_ntt;
        mism_file = 0;
        for (n = 0; n < 256; n = n + 1) if (gold[n] !== exp_single[n]) mism_file = mism_file + 1;
        if (mism_file == 0) $display("  [ OK ] mo hinh vang trong tb KHOP ntt_expected_single.txt");
        else begin errors = errors + 1; $display("  [FAIL] mo hinh vang lech file expected: %0d he so", mism_file); end

        $display("  --- CPU ghi 256 he so vao DIN, START (NTT)");
        load_din;
        verify_din_readback("DIN truoc khi chay NTT");
        run_core(1'b0);
        read_dout;
        for (n = 0; n < 256; n = n + 1) gold[n] = exp_single[n];
        fname = {`DATA_DIR, "axi_ntt.txt"};  write_res_file(fname);
        compare_res("NTT (file)");
        for (n = 0; n < 256; n = n + 1) ntt_keep[n] = res[n];
        verify_din_readback("DIN sau khi chay NTT");

        $display("  --- DOUT la chi doc: ghi 0xFFF vao DOUT[0] roi doc lai");
        axi_write(A_DOUT, 32'h00000FFF);
        axi_read(A_DOUT, d);
        if (d[11:0] !== ntt_keep[0]) begin errors = errors + 1; $display("  [FAIL] DOUT[0] bi ghi duoc tu AXI: %08h", d); end
        else $display("  [ OK ] DOUT[0] khong doi (%03h)", d[11:0]);

        $display("  --- INTT cua ket qua NTT (CTRL = 0x3), phai ra lai dau vao");
        for (n = 0; n < 256; n = n + 1) in_buf[n] = ntt_keep[n];
        load_din;
        run_core(1'b1);
        expect32("CTRL giu MODE, START tu xoa", A_CTRL, 32'h2);
        read_dout;
        for (n = 0; n < 256; n = n + 1) gold[n] = intt_exp_single[n];
        fname = {`DATA_DIR, "axi_intt.txt"}; write_res_file(fname);
        compare_res("INTT (file)");
        for (n = 0; n < 256; n = n + 1) gold[n] = in_single[n];
        compare_res("INTT(NTT(x)) == x");

        //------------------------------------------------------------------
        if (NCASES > 0) begin
            $display("\n########## T4: %0d BO DU LIEU (ntt_input_100cases.txt), chay lien tiep khong reset ##########", NCASES);
            fails_before = errors;
            for (c = 0; c < NCASES; c = c + 1) begin
                for (n = 0; n < 256; n = n + 1) begin in_buf[n] = big[c*256 + n]; gold[n] = big[c*256 + n]; end
                golden_ntt;
                load_din;  run_core(1'b0);  read_dout;
                mism_file = 0;
                for (n = 0; n < 256; n = n + 1) if (res[n] !== gold[n]) mism_file = mism_file + 1;
                if (mism_file != 0) begin errors = errors + 1; $display("  [FAIL] case %0d NTT lech %0d he so", c, mism_file); end
                for (n = 0; n < 256; n = n + 1) in_buf[n] = res[n];
                load_din;  run_core(1'b1);  read_dout;
                mism_file = 0;
                for (n = 0; n < 256; n = n + 1) if (res[n] !== big[c*256 + n]) mism_file = mism_file + 1;
                if (mism_file != 0) begin errors = errors + 1; $display("  [FAIL] case %0d INTT(NTT(x)) != x, lech %0d he so", c, mism_file); end
                if ((c % 10) == 9) $display("  ... xong %0d / %0d bo (loi tich luy = %0d)", c + 1, NCASES, errors);
            end
            if (errors == fails_before) $display("  [ OK ] T4: %0d/%0d bo khop (NTT va INTT)", NCASES, NCASES);
        end

        //------------------------------------------------------------------
        $display("\n==================================================");
        if (errors == 0) $display("  TAT CA PASS  (tb_myip_axi_full)");
        else             $display("  CO %0d LOI  (tb_myip_axi_full)", errors);
        $display("==================================================");
        $finish;
    end
endmodule