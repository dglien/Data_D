# ---------------------------------------------------------------------------
# wave_tb_myip_axi_full.tcl : nhom tin hieu cho tb_myip_axi_full (AXI4-Lite + NTT/INTT)
# Dung:  cd D:/ntt_ipcore_mlkem/wave
#        source wave_common.tcl
#        source wave_tb_myip_axi_full.tcl
#        run -all
# (Simulation top phai la tb_myip_axi_full; da Run Behavioral Simulation truoc.)
# ---------------------------------------------------------------------------
set T    /tb_myip_axi_full
set S    $T/dut/myip_v1_0_S00_AXI_inst      ;# AXI4-Lite slave
set C    $S/u_core                          ;# core ntt_ip_v1_0

# Ban an toan cua add_grp: tin hieu nao khong tim thay thi bo qua, khong lam dung script
proc add_grp2 {name scope sigs {radix hex}} {
    set g [add_wave_group $name]
    foreach s $sigs {
        if {[catch {add_wave -into $g -radix $radix ${scope}/${s}} err]} {
            puts "  (bo qua: ${scope}/${s})"
        }
    }
    return $g
}

remove_wave [get_waves -quiet *]

add_grp2 "CLK_RST" $T {clk aresetn} bin
add_grp2 "KET QUA TB (errors, tien do)" $T {errors n c mism_file} unsigned

add_div "===== AXI4-Lite : kenh GHI (AW / W / B) ====="
add_grp2 "AW" $T {awvalid awready awaddr} hex
add_grp2 "W"  $T {wvalid wready wdata wstrb} hex
add_grp2 "B"  $T {bvalid bready bresp} hex

add_div "===== AXI4-Lite : kenh DOC (AR / R) ====="
add_grp2 "AR" $T {arvalid arready araddr} hex
add_grp2 "R"  $T {rvalid rready rdata rresp} hex

add_div "===== myip_v1_0_S00_AXI : thanh ghi + 2 mang nho ====="
add_grp2 "CTRL / STATUS" $S {mode_reg start_pulse core_busy core_done} bin
add_grp2 "dia chi da chot (awaddr / araddr)" $S {axi_awaddr axi_araddr wr_sel rd_sel wr_idx rd_idx} hex
add_grp2 "ghi thanh ghi (slv_reg_wren / rden)" $S {slv_reg_wren slv_reg_rden axi_rdata} hex
add_grp2 "BAT TAY voi core (ext_*)" $S {ext_ready ext_addr ext_din ext_rvalid ext_rdata} hex

add_div "===== u_core : FSM ====="
add_grp2 "STATE FSM_TOPCORE" $C/u_control {name_top} ascii
add_grp2 "STATE FSM_BUTTERFLY" $C/u_control {name_bf} ascii
add_grp2 "TOP counter / tin hieu" $C/u_control {st_top st_bf cnt_data cnt_data_clr load_en mode_r rd_done calc_done dout_vld sel_proc ext_ready ext_rvalid} hex
add_grp2 "BF counter (j_cnt,start_r,len,i,stage_cnt,scale_cnt)" $C/u_control {j_cnt start_r len i_cnt stage_cnt scale_cnt} unsigned
add_grp2 "BF flag ket thuc" $C/u_control {j_end grp_end last_stg k_end} bin

add_div "===== u_core : u_ram_a ====="
add_grp2 "RAM sel / port A (sau MUX)" $C/u_ram_a {sel_proc we_a re_a adr_a wdata_a rdata_a valid_a} hex
add_grp2 "RAM port B" $C/u_ram_a {we_b re_b addr_b wr_data_b rdata_b valid_b} hex

add_div "===== u_core : u_rom_zeta ====="
add_grp2 "ROM ZETA" $C/u_rom_zeta {rom_en zeta_addr zeta zeta_valid} hex

add_div "===== u_core : u_butterfly ====="
add_grp2 "BF vao (a,b,z)" $C/u_butterfly {valid_in mode scale a b z} hex
add_grp2 "BF add/sub dung chung" $C/u_butterfly {as_valid as_a as_b add_r sub_r add_done} hex
add_grp2 "BF mul dung chung" $C/u_butterfly {mul_valid mul_x mul_y z_1 mul_done mul_t} hex
add_grp2 "BF chon ngo ra CT/GS" $C/u_butterfly {fin_valid fin_y0 fin_y1} hex
add_grp2 "BF ra (o0,o1)" $C/u_butterfly {valid_out y0 y1} hex

save_wave_config tb_myip_axi_full.wcfg