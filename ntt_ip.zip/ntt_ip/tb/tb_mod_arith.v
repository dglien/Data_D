`timescale 1ns/1ps
//==============================================================================
// TESTBENCH : tb_mod_arith
//   1) Kiem tra rieng mod_add / mod_sub / mod_mul : stream ngau nhien co "bong bong"
//      (i_start ngat quang) + gia tri bien (0, 1, 3327, 3328).
//      Moi don vi co 1 pipeline mong doi: o_done phai dung chu ky, o_y phai dung gia tri.
//   2) Kiem tra CHUOI  ADD -> SUB -> MUL :  o_done cua phep truoc chinh la i_start
//      cua phep sau.   m = ((x + y) - w) * u  mod q.
//        - phan A : giao dich don le, in log tung buoc (thay ro "xong cong -> tru -> nhan")
//        - phan B : stream lien tuc back-to-back
//==============================================================================
module tb_mod_arith;
    localparam integer Q = 3329;
    localparam integer N_RAND = 20000;

    reg i_clk = 1'b0;
    reg i_rst_n = 1'b0;
    always #5 i_clk = ~i_clk;

    integer errors = 0;
    integer seed   = 32'h1234_5678;

    function [11:0] rnd_val(input integer dummy);
        integer r, sel;
        begin
            sel = {$random(seed)} % 8;
            case (sel)
                0: rnd_val = 12'd0;
                1: rnd_val = 12'd1;
                2: rnd_val = 12'd3327;
                3: rnd_val = 12'd3328;
                default: begin
                    r = {$random(seed)} % Q;
                    rnd_val = r[11:0];
                end
            endcase
        end
    endfunction

    //==========================================================================
    // [1] DON VI: mod_add
    //==========================================================================
    reg         add_start = 1'b0;
    reg  [11:0] add_a = 0, add_b = 0;
    wire [11:0] add_y;
    wire        add_done;
    mod_add u_add (.i_clk(i_clk), .i_rst_n(i_rst_n), .i_start(add_start),
                   .i_a(add_a), .i_b(add_b), .o_y(add_y), .o_done(add_done));

    reg         add_ev = 0;  reg [11:0] add_ey = 0;
    integer     add_cnt = 0;
    always @(posedge i_clk) if (i_rst_n) begin
        if (add_done !== add_ev) begin
            errors = errors + 1; $display("[%0t] ERR ADD  o_done=%b expect %b", $time, add_done, add_ev);
        end else if (add_ev) begin
            add_cnt = add_cnt + 1;
            if (add_y !== add_ey) begin
                errors = errors + 1; $display("[%0t] ERR ADD  y=%0d expect %0d", $time, add_y, add_ey);
            end
        end
        add_ev <= add_start;
        add_ey <= (add_a + add_b) % Q;
    end

    //==========================================================================
    // [1] DON VI: mod_sub
    //==========================================================================
    reg         sub_start = 1'b0;
    reg  [11:0] sub_a = 0, sub_b = 0;
    wire [11:0] sub_y;
    wire        sub_done;
    mod_sub u_sub (.i_clk(i_clk), .i_rst_n(i_rst_n), .i_start(sub_start),
                   .i_a(sub_a), .i_b(sub_b), .o_y(sub_y), .o_done(sub_done));

    reg         sub_ev = 0;  reg [11:0] sub_ey = 0;
    integer     sub_cnt = 0;
    always @(posedge i_clk) if (i_rst_n) begin
        if (sub_done !== sub_ev) begin
            errors = errors + 1; $display("[%0t] ERR SUB  o_done=%b expect %b", $time, sub_done, sub_ev);
        end else if (sub_ev) begin
            sub_cnt = sub_cnt + 1;
            if (sub_y !== sub_ey) begin
                errors = errors + 1; $display("[%0t] ERR SUB  y=%0d expect %0d", $time, sub_y, sub_ey);
            end
        end
        sub_ev <= sub_start;
        sub_ey <= (sub_a + Q - sub_b) % Q;
    end

    //==========================================================================
    // [1] DON VI: mod_mul (do tre 3 chu ky)
    //==========================================================================
    reg         mul_start = 1'b0;
    reg  [11:0] mul_a = 0, mul_b = 0;
    wire [11:0] mul_y;
    wire        mul_done;
    mod_mul u_mul (.i_clk(i_clk), .i_rst_n(i_rst_n), .i_start(mul_start),
                   .i_a(mul_a), .i_b(mul_b), .o_y(mul_y), .o_done(mul_done));

    reg [2:0]   mul_ev = 0;
    reg [11:0]  mul_e0 = 0, mul_e1 = 0, mul_e2 = 0;
    integer     mul_cnt = 0;
    always @(posedge i_clk) if (i_rst_n) begin
        if (mul_done !== mul_ev[2]) begin
            errors = errors + 1; $display("[%0t] ERR MUL  o_done=%b expect %b", $time, mul_done, mul_ev[2]);
        end else if (mul_ev[2]) begin
            mul_cnt = mul_cnt + 1;
            if (mul_y !== mul_e2) begin
                errors = errors + 1; $display("[%0t] ERR MUL  y=%0d expect %0d", $time, mul_y, mul_e2);
            end
        end
        mul_ev <= {mul_ev[1:0], mul_start};
        mul_e0 <= (mul_a * mul_b) % Q;
        mul_e1 <= mul_e0;
        mul_e2 <= mul_e1;
    end

    //==========================================================================
    // [2] CHUOI ADD -> SUB -> MUL
    //   c_add_done  ==  c_sub.i_start      c_sub_done  ==  c_mul.i_start
    //==========================================================================
    reg         c_start = 1'b0;
    reg  [11:0] c_x = 0, c_y = 0, c_w = 0, c_u = 0;
    reg  [11:0] c_w1 = 0, c_u1 = 0, c_u2 = 0;         // can w, u theo tung tang
    wire [11:0] c_add_y, c_sub_y, c_mul_y;
    wire        c_add_done, c_sub_done, c_mul_done;

    always @(posedge i_clk) begin
        c_w1 <= c_w;
        c_u1 <= c_u;  c_u2 <= c_u1;
    end

    mod_add c_add (.i_clk(i_clk), .i_rst_n(i_rst_n), .i_start(c_start),
                   .i_a(c_x), .i_b(c_y), .o_y(c_add_y), .o_done(c_add_done));
    mod_sub c_sub (.i_clk(i_clk), .i_rst_n(i_rst_n), .i_start(c_add_done),
                   .i_a(c_add_y), .i_b(c_w1), .o_y(c_sub_y), .o_done(c_sub_done));
    mod_mul c_mul (.i_clk(i_clk), .i_rst_n(i_rst_n), .i_start(c_sub_done),
                   .i_a(c_sub_y), .i_b(c_u2), .o_y(c_mul_y), .o_done(c_mul_done));

    // mong doi: tre tong = 1 + 1 + 3 = 5 chu ky
    reg [4:0]   c_ev = 0;
    reg [11:0]  c_e [0:4];
    integer     c_cnt = 0;
    integer     k;
    initial for (k = 0; k < 5; k = k + 1) c_e[k] = 0;
    always @(posedge i_clk) if (i_rst_n) begin
        if (c_mul_done !== c_ev[4]) begin
            errors = errors + 1; $display("[%0t] ERR CHAIN o_done=%b expect %b", $time, c_mul_done, c_ev[4]);
        end else if (c_ev[4]) begin
            c_cnt = c_cnt + 1;
            if (c_mul_y !== c_e[4]) begin
                errors = errors + 1; $display("[%0t] ERR CHAIN y=%0d expect %0d", $time, c_mul_y, c_e[4]);
            end
        end
        c_ev <= {c_ev[3:0], c_start};
        c_e[0] <= ((((c_x + c_y) % Q) + Q - c_w) % Q * c_u) % Q;
        c_e[1] <= c_e[0]; c_e[2] <= c_e[1]; c_e[3] <= c_e[2]; c_e[4] <= c_e[3];
    end

    // ---- log tung buoc cua chuoi (chi in 4 giao dich dau cua phan A) ----
    reg log_en = 1'b0;
    always @(posedge i_clk) if (log_en) begin
        if (c_start)     $display("[%0t] CHAIN  ADD start : x=%0d y=%0d", $time, c_x, c_y);
        if (c_add_done)  $display("[%0t] CHAIN  ADD done  : (x+y)=%0d       -> SUB start (w=%0d)", $time, c_add_y, c_w1);
        if (c_sub_done)  $display("[%0t] CHAIN  SUB done  : (x+y-w)=%0d     -> MUL start (u=%0d)", $time, c_sub_y, c_u2);
        if (c_mul_done)  $display("[%0t] CHAIN  MUL done  : result=%0d  (expect %0d)", $time, c_mul_y, c_e[4]);
    end

    //==========================================================================
    // KICH BAN
    //==========================================================================
    integer n;
    initial begin
        $timeformat(-9, 0, " ns", 10);
        $dumpfile("tb_mod_arith.vcd");
        $dumpvars(0, tb_mod_arith);
        repeat (4) @(negedge i_clk);
        i_rst_n = 1'b1;
        repeat (2) @(negedge i_clk);

        $display("==== [1] STREAM NGAU NHIEN: ADD / SUB / MUL (rieng le) ====");
        for (n = 0; n < N_RAND; n = n + 1) begin
            @(negedge i_clk);
            add_start = ({$random(seed)} % 10) < 7;  add_a = rnd_val(0); add_b = rnd_val(0);
            sub_start = ({$random(seed)} % 10) < 7;  sub_a = rnd_val(0); sub_b = rnd_val(0);
            mul_start = ({$random(seed)} % 10) < 7;  mul_a = rnd_val(0); mul_b = rnd_val(0);
        end
        @(negedge i_clk);
        add_start = 0; sub_start = 0; mul_start = 0;
        repeat (8) @(negedge i_clk);
        $display("  ADD : %0d phep da kiem tra", add_cnt);
        $display("  SUB : %0d phep da kiem tra", sub_cnt);
        $display("  MUL : %0d phep da kiem tra", mul_cnt);

        $display("==== [2A] CHUOI ADD->SUB->MUL, giao dich don le (co log) ====");
        log_en = 1'b1;
        for (n = 0; n < 4; n = n + 1) begin
            @(negedge i_clk);
            c_x = rnd_val(0); c_y = rnd_val(0); c_w = rnd_val(0); c_u = rnd_val(0);
            c_start = 1'b1;
            @(negedge i_clk);
            c_start = 1'b0;
            repeat (8) @(negedge i_clk);
            $display("  ---");
        end
        log_en = 1'b0;

        $display("==== [2B] CHUOI ADD->SUB->MUL, stream back-to-back ====");
        for (n = 0; n < 5000; n = n + 1) begin
            @(negedge i_clk);
            c_start = ({$random(seed)} % 10) < 8;
            c_x = rnd_val(0); c_y = rnd_val(0); c_w = rnd_val(0); c_u = rnd_val(0);
        end
        @(negedge i_clk); c_start = 1'b0;
        repeat (10) @(negedge i_clk);
        $display("  CHAIN: %0d giao dich da kiem tra", c_cnt);

        $display("==============================================");
        if (errors == 0 && add_cnt > 0 && sub_cnt > 0 && mul_cnt > 0 && c_cnt > 0)
            $display("  TB_MOD_ARITH : *** PASS ***  (0 loi)");
        else
            $display("  TB_MOD_ARITH : *** FAIL ***  (%0d loi)", errors);
        $display("==============================================");
        $finish;
    end
endmodule
