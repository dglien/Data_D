`timescale 1ns/1ps
//==============================================================================
// TESTBENCH : tb_ntt_top   (kiem tra he thong ntt_top, khong AXI: dung MEM_IN / MEM_OUT)
//
// Cac lop kiem tra:
//   [A] MO HINH THAM CHIEU  : NTT / INTT theo FIPS 203 (thuat toan 9, 10), zeta tinh doc lap
//       bang 17^BitRev7(i) mod 3329 -> doi chieu luon noi dung ROM.
//   [B] SCOREBOARD TUNG BUTTERFLY (shadow RAM): moi lan valid_in
//         - a, b doc tu RAM phai bang shadow[addr_a], shadow[addr_b]   (kiem tra dia chi + RAM)
//         - z doc tu ROM phai bang zeta_ref[zeta_addr]
//         - do tre valid_in -> valid_out phai = 5 chu ky
//       moi lan WR: y0, y1 phai bang gia tri mong doi, roi cap nhat shadow.
//   [C] GIAO THUC : trang thai FSM_TOP / FSM_BUTTERFLY chi duoc chuyen theo dung so do,
//       busy/done dung theo state, moi dia chi MEM_OUT ghi dung 1 lan, so butterfly = 896.
//   [D] KET QUA CUOI : MEM_OUT == mo hinh tham chieu.
//
// Cac kich ban : NTT ngau nhien | INTT ngau nhien | round-trip NTT->INTT |
//                tat ca = 0 | tat ca = 3328 | xung don vi | doc nghich | giu start | reset giua chung
//
// Log: chuyen state TOP, ranh gioi tang/nhom, va chi tiet 2 butterfly dau (pipeline
//      SUB_PRE -> MUL -> ADD/SUB -> WR).
//==============================================================================
module tb_ntt_top;
    localparam integer Q        = 3329;
    localparam integer N_BF     = 896;           // 7 tang x 128 cap
    localparam integer TIMEOUT  = 60000;         // chu ky toi da cho 1 lan chay
    localparam integer INV128   = 3303;          // 128^-1 mod q

    //--------------------------------------------------------------------------
    // Clock / reset / DUT
    //--------------------------------------------------------------------------
    reg         i_clk   = 1'b0;
    reg         i_rst_n = 1'b0;
    reg         i_start = 1'b0;
    reg         i_mode  = 1'b0;
    wire        o_in_en;
    wire [7:0]  o_in_addr;
    reg  [11:0] i_in_data = 12'd0;
    wire        o_out_we;
    wire [7:0]  o_out_addr;
    wire [11:0] o_out_data;
    wire        o_busy, o_done;

    always #5 i_clk = ~i_clk;                    // 100 MHz

    ntt_top dut (
        .i_clk(i_clk), .i_rst_n(i_rst_n), .i_start(i_start), .i_mode(i_mode),
        .o_in_en(o_in_en), .o_in_addr(o_in_addr), .i_in_data(i_in_data),
        .o_out_we(o_out_we), .o_out_addr(o_out_addr), .o_out_data(o_out_data),
        .o_busy(o_busy), .o_done(o_done)
    );

    //--------------------------------------------------------------------------
    // MEM_IN / MEM_OUT (mo hinh ben ngoai)
    //--------------------------------------------------------------------------
    reg [11:0] mem_in  [0:255];
    reg [11:0] mem_out [0:255];
    always @(posedge i_clk) if (o_in_en)  i_in_data <= mem_in[o_in_addr];   // doc dong bo, tre 1 chu ky
    always @(posedge i_clk) if (o_out_we) mem_out[o_out_addr] <= o_out_data;

    //--------------------------------------------------------------------------
    // Ten state (de xem dang chu tren waveform: chon Radix = ASCII)
    //--------------------------------------------------------------------------
    function [95:0] top_name(input [2:0] s);
        case (s)
            3'd0: top_name = "IDLE        ";
            3'd1: top_name = "LOAD_DATA   ";
            3'd2: top_name = "EX          ";
            3'd3: top_name = "READ_OUT    ";
            3'd4: top_name = "FIN         ";
            default: top_name = "???         ";
        endcase
    endfunction
    function [95:0] bf_name(input [2:0] s);
        case (s)
            3'd0: bf_name = "IDLE        ";
            3'd1: bf_name = "READ        ";
            3'd2: bf_name = "EX          ";
            3'd3: bf_name = "WR          ";
            3'd4: bf_name = "NEXT_BF     ";
            3'd5: bf_name = "NEXT_GRP    ";
            3'd6: bf_name = "NEXT_STAGE  ";
            3'd7: bf_name = "DONE        ";
        endcase
    endfunction

    wire [2:0]  top_state = dut.state;
    wire [2:0]  bf_state  = dut.u_butterfly.state;
    reg  [95:0] top_state_name, bf_state_name;
    always @* top_state_name = top_name(top_state);
    always @* bf_state_name  = bf_name(bf_state);

    //--------------------------------------------------------------------------
    // [A] MO HINH THAM CHIEU
    //--------------------------------------------------------------------------
    integer zeta_ref [0:127];
    integer ref_f    [0:255];
    integer orig_f   [0:255];

    function integer brev7(input integer x);
        integer b;
        begin
            brev7 = 0;
            for (b = 0; b < 7; b = b + 1) brev7 = brev7 | (((x >> b) & 1) << (6 - b));
        end
    endfunction

    integer zi, zk, zp;
    initial begin
        for (zi = 0; zi < 128; zi = zi + 1) begin
            zp = 1;
            for (zk = 0; zk < brev7(zi); zk = zk + 1) zp = (zp * 17) % Q;
            zeta_ref[zi] = zp;
        end
    end

    task ref_ntt;                                // FIPS 203 - thuat toan 9
        integer len, st, j, i, z, t;
        begin
            i = 1; len = 128;
            while (len >= 2) begin
                st = 0;
                while (st < 256) begin
                    z = zeta_ref[i]; i = i + 1;
                    for (j = st; j < st + len; j = j + 1) begin
                        t = (z * ref_f[j + len]) % Q;
                        ref_f[j + len] = (ref_f[j] + Q - t) % Q;
                        ref_f[j]       = (ref_f[j] + t) % Q;
                    end
                    st = st + 2 * len;
                end
                len = len / 2;
            end
        end
    endtask

    task ref_intt;                               // FIPS 203 - thuat toan 10 (CHUA nhan 3303)
        integer len, st, j, i, z, t;
        begin
            i = 127; len = 2;
            while (len <= 128) begin
                st = 0;
                while (st < 256) begin
                    z = zeta_ref[i]; i = i - 1;
                    for (j = st; j < st + len; j = j + 1) begin
                        t = ref_f[j];
                        ref_f[j]       = (t + ref_f[j + len]) % Q;
                        ref_f[j + len] = (z * ((ref_f[j + len] + Q - t) % Q)) % Q;
                    end
                    st = st + 2 * len;
                end
                len = len * 2;
            end
        end
    endtask

    //--------------------------------------------------------------------------
    // Bien dem / co
    //--------------------------------------------------------------------------
    integer cyc = 0;                              // dem chu ky
    integer errors = 0;                           // tong loi
    integer seed   = 32'h00C0_FFEE;
    reg     verbose_run = 1'b0;                   // in chi tiet cho lan chay nay
    reg     hold_mode   = 1'b0;                   // i_start duoc giu (khong kiem tra do rong done)

    integer n_bf_run, n_wr_run, n_stage_run, n_inrd_run, n_outwr_run;
    integer done_cycles;
    integer cyc_start, cyc_load, cyc_ex, cyc_rd, cyc_fin;
    reg     out_seen [0:255];

    // shadow RAM + gia tri mong doi
    integer sh [0:255];
    integer e_y0, e_y1, e_aa, e_ab;
    integer cyc_vin;
    integer ea, eb, ez, et;

    //--------------------------------------------------------------------------
    // Giam sat : chay moi chu ky
    //--------------------------------------------------------------------------
    reg [2:0] top_prev = 3'd0, bf_prev = 3'd0;
    reg       rst_prev = 1'b0;
    reg       done_prev = 1'b0;
    reg       detail;
    integer   k;

    wire        bf_valid_in  = dut.u_butterfly.valid_in;
    wire        bf_valid_out = dut.u_butterfly.valid_out;

    always @(posedge i_clk) begin
        cyc = cyc + 1;
        detail = verbose_run && (n_wr_run < 2) && (top_state == 3'd2);

        //======================= [C] giao thuc TOP =======================
        if (i_rst_n && rst_prev) begin
            if (top_state !== top_prev) begin
                // chuyen state hop le?
                case (top_prev)
                    3'd0: if (top_state !== 3'd1) begin errors = errors + 1; $display("[%0t] ERR  TOP chuyen state sai: IDLE -> %0s", $time, top_name(top_state)); end
                    3'd1: if (top_state !== 3'd2) begin errors = errors + 1; $display("[%0t] ERR  TOP chuyen state sai: LOAD_DATA -> %0s", $time, top_name(top_state)); end
                    3'd2: if (top_state !== 3'd3) begin errors = errors + 1; $display("[%0t] ERR  TOP chuyen state sai: EX -> %0s", $time, top_name(top_state)); end
                    3'd3: if (top_state !== 3'd4) begin errors = errors + 1; $display("[%0t] ERR  TOP chuyen state sai: READ_OUT -> %0s", $time, top_name(top_state)); end
                    3'd4: if (top_state !== 3'd0) begin errors = errors + 1; $display("[%0t] ERR  TOP chuyen state sai: FIN -> %0s", $time, top_name(top_state)); end
                    default: ;
                endcase
                $display("[%0t] TOP  : %0s -> %0s   (cyc=%0d, busy=%b done=%b)", $time,
                         top_name(top_prev), top_name(top_state), cyc, o_busy, o_done);
                if (top_state == 3'd2) begin cyc_load = cyc - cyc_start; end
                if (top_state == 3'd3) begin cyc_ex   = cyc - cyc_start - cyc_load; end
            end
            // busy / done phai khop state
            case (top_state)
                3'd0: if (o_busy !== 1'b0 || o_done !== 1'b0) begin errors = errors + 1; $display("[%0t] ERR  IDLE: busy=%b done=%b", $time, o_busy, o_done); end
                3'd4: if (o_busy !== 1'b0 || o_done !== 1'b1) begin errors = errors + 1; $display("[%0t] ERR  FIN : busy=%b done=%b", $time, o_busy, o_done); end
                default: if (o_busy !== 1'b1 || o_done !== 1'b0) begin errors = errors + 1; $display("[%0t] ERR  %0s: busy=%b done=%b", $time, top_name(top_state), o_busy, o_done); end
            endcase
            // do rong xung done
            if (o_done) done_cycles = done_cycles + 1;
            if (done_prev && !o_done && !hold_mode && done_cycles != 1) begin
                errors = errors + 1; $display("[%0t] ERR  done rong %0d chu ky (can 1)", $time, done_cycles);
            end
        end

        //======================= MEM_IN / MEM_OUT dem =====================
        if (o_in_en)  n_inrd_run  = n_inrd_run + 1;
        if (o_out_we) begin
            n_outwr_run = n_outwr_run + 1;
            if (out_seen[o_out_addr]) begin errors = errors + 1; $display("[%0t] ERR  MEM_OUT ghi trung dia chi %0d", $time, o_out_addr); end
            out_seen[o_out_addr] = 1'b1;
        end

        //======================= FSM_BUTTERFLY ============================
        if (i_rst_n && rst_prev && bf_state !== bf_prev) begin
            case (bf_prev)
                3'd0: if (bf_state !== 3'd1) begin errors = errors + 1; $display("[%0t] ERR  BF chuyen state sai: IDLE -> %0s", $time, bf_name(bf_state)); end
                3'd1: if (bf_state !== 3'd2) begin errors = errors + 1; $display("[%0t] ERR  BF chuyen state sai: READ -> %0s", $time, bf_name(bf_state)); end
                3'd2: if (bf_state !== 3'd3) begin errors = errors + 1; $display("[%0t] ERR  BF chuyen state sai: EX -> %0s", $time, bf_name(bf_state)); end
                3'd3: if (bf_state < 3'd4)   begin errors = errors + 1; $display("[%0t] ERR  BF chuyen state sai: WR -> %0s", $time, bf_name(bf_state)); end
                3'd4, 3'd5, 3'd6: if (bf_state !== 3'd1) begin errors = errors + 1; $display("[%0t] ERR  BF chuyen state sai: %0s -> %0s", $time, bf_name(bf_prev), bf_name(bf_state)); end
                3'd7: if (bf_state !== 3'd0) begin errors = errors + 1; $display("[%0t] ERR  BF chuyen state sai: DONE -> %0s", $time, bf_name(bf_state)); end
            endcase
            if (detail || (verbose_run && bf_prev == 3'd7) || (verbose_run && bf_state == 3'd7))
                $display("[%0t]   BF : %0s -> %0s   (j_cnt=%0d start_r=%0d len=%0d i=%0d stage=%0d)", $time,
                         bf_name(bf_prev), bf_name(bf_state),
                         dut.u_butterfly.j_cnt, dut.u_butterfly.start_r, dut.u_butterfly.len,
                         dut.u_butterfly.i_idx, dut.u_butterfly.stage_cnt);
            if (bf_prev == 3'd6) begin
                n_stage_run = n_stage_run + 1;
                $display("[%0t]   ==== xong tang %0d -> vao tang %0d : len=%0d, i=%0d ====", $time,
                         dut.u_butterfly.stage_cnt - 1, dut.u_butterfly.stage_cnt,
                         dut.u_butterfly.len, dut.u_butterfly.i_idx);
            end
        end

        // ---- khoi tao shadow RAM khi vao EX ----
        if (i_rst_n && top_state == 3'd2 && top_prev != 3'd2)
            for (k = 0; k < 256; k = k + 1) sh[k] = mem_in[k];

        // ---- [B] valid_in : a, b, z hop le ----
        if (bf_valid_in) begin
            n_bf_run = n_bf_run + 1;
            cyc_vin  = cyc;
            ea = dut.u_butterfly.i_a;  eb = dut.u_butterfly.i_b;  ez = dut.u_butterfly.i_z;
            e_aa = dut.u_butterfly.o_addr_a;  e_ab = dut.u_butterfly.o_addr_b;
            if (ea !== sh[e_aa]) begin errors = errors + 1; $display("[%0t] ERR  BF doc a=%0d != RAM[%0d]=%0d", $time, ea, e_aa, sh[e_aa]); end
            if (eb !== sh[e_ab]) begin errors = errors + 1; $display("[%0t] ERR  BF doc b=%0d != RAM[%0d]=%0d", $time, eb, e_ab, sh[e_ab]); end
            if (ez !== zeta_ref[dut.u_butterfly.o_zeta_addr]) begin
                errors = errors + 1;
                $display("[%0t] ERR  BF doc z=%0d != zeta[%0d]=%0d", $time, ez, dut.u_butterfly.o_zeta_addr, zeta_ref[dut.u_butterfly.o_zeta_addr]);
            end
            if (dut.mode_q == 1'b0) begin
                et = (ez * eb) % Q;  e_y0 = (ea + et) % Q;  e_y1 = (ea + Q - et) % Q;
            end else begin
                e_y0 = (ea + eb) % Q;  e_y1 = (ez * ((eb + Q - ea) % Q)) % Q;
            end
            if (verbose_run && n_wr_run < 2 && n_bf_run <= 2)
                $display("[%0t]   BF#%0d valid_in : a=%0d b=%0d z=%0d  (addr_a=%0d addr_b=%0d zeta_addr=%0d) -> mong doi y0=%0d y1=%0d",
                         $time, n_bf_run, ea, eb, ez, e_aa, e_ab, dut.u_butterfly.o_zeta_addr, e_y0, e_y1);
            if (verbose_run && dut.u_butterfly.j_cnt == 0 && n_bf_run > 2)
                $display("[%0t]   NHOM MOI : start_r=%0d len=%0d zeta_addr=i=%0d (stage %0d)", $time,
                         dut.u_butterfly.start_r, dut.u_butterfly.len, dut.u_butterfly.o_zeta_addr, dut.u_butterfly.stage_cnt);
        end

        // ---- log pipeline cac phep toan (chi 2 butterfly dau) ----
        if (detail) begin
            if (dut.u_butterfly.pre_done) $display("[%0t]      SUB_PRE done : (b-a) mod q = %0d   [INTT]", $time, dut.u_butterfly.pre_y);
            if (dut.u_butterfly.mul_done) $display("[%0t]      MUL     done : z*x   mod q = %0d   -> start ADD, SUB", $time, dut.u_butterfly.mul_y);
            if (dut.u_butterfly.add_done) $display("[%0t]      ADD     done : y0 = %0d              (== valid_out)", $time, dut.u_butterfly.add_y);
            if (dut.u_butterfly.sub_done) $display("[%0t]      SUB     done : y1 = %0d              [NTT]", $time, dut.u_butterfly.sub_y);
        end

        // ---- [B] do tre valid_in -> valid_out ----
        if (bf_valid_out && (cyc - cyc_vin) != 5) begin
            errors = errors + 1; $display("[%0t] ERR  do tre valid_in->valid_out = %0d (can 5)", $time, cyc - cyc_vin);
        end

        // ---- [B] WR : kiem tra y0, y1 va cap nhat shadow ----
        if (dut.u_butterfly.o_we_a) begin
            n_wr_run = n_wr_run + 1;
            if (dut.u_butterfly.o_addr_a !== e_aa || dut.u_butterfly.o_addr_b !== e_ab) begin
                errors = errors + 1; $display("[%0t] ERR  WR dia chi (%0d,%0d) != (%0d,%0d)", $time,
                         dut.u_butterfly.o_addr_a, dut.u_butterfly.o_addr_b, e_aa, e_ab);
            end
            if (dut.u_butterfly.o_y0 !== e_y0 || dut.u_butterfly.o_y1 !== e_y1) begin
                errors = errors + 1; $display("[%0t] ERR  WR y0=%0d y1=%0d  mong doi y0=%0d y1=%0d  (addr %0d,%0d)", $time,
                         dut.u_butterfly.o_y0, dut.u_butterfly.o_y1, e_y0, e_y1, e_aa, e_ab);
            end
            if (detail || (verbose_run && n_wr_run <= 2))
                $display("[%0t]   BF#%0d WR : RAM[%0d] <= y0=%0d ; RAM[%0d] <= y1=%0d   (%s)", $time, n_wr_run,
                         e_aa, dut.u_butterfly.o_y0, e_ab, dut.u_butterfly.o_y1,
                         (dut.u_butterfly.o_y0 === e_y0 && dut.u_butterfly.o_y1 === e_y1) ? "OK " : "SAI");
            sh[e_aa] = e_y0;
            sh[e_ab] = e_y1;
        end

        top_prev = top_state;
        bf_prev  = bf_state;
        rst_prev = i_rst_n;
        done_prev = o_done;
        if (!o_done) done_cycles = 0;
    end

    //--------------------------------------------------------------------------
    // Nap du lieu
    //--------------------------------------------------------------------------
    integer ii;
    task fill_random;  begin for (ii = 0; ii < 256; ii = ii + 1) mem_in[ii] = {$random(seed)} % Q; end endtask
    task fill_const(input integer v); begin for (ii = 0; ii < 256; ii = ii + 1) mem_in[ii] = v; end endtask
    task fill_impulse; begin for (ii = 0; ii < 256; ii = ii + 1) mem_in[ii] = (ii == 0) ? 12'd1 : 12'd0; end endtask
    task fill_ramp;    begin for (ii = 0; ii < 256; ii = ii + 1) mem_in[ii] = (ii * 13) % Q; end endtask

    //--------------------------------------------------------------------------
    // Chay 1 lan: start -> done, doi chieu ket qua
    //--------------------------------------------------------------------------
    integer tcnt, mism, tests_run = 0, tests_failed = 0, err_before;

    task run_core(input mode, input verbose, input hold, input [255:0] name);
        begin
            err_before = errors;
            verbose_run = verbose;  hold_mode = hold;
            n_bf_run = 0; n_wr_run = 0; n_stage_run = 0; n_inrd_run = 0; n_outwr_run = 0; done_cycles = 0;
            for (ii = 0; ii < 256; ii = ii + 1) begin out_seen[ii] = 1'b0; mem_out[ii] = 12'hFFF; ref_f[ii] = mem_in[ii]; end
            if (mode) ref_intt; else ref_ntt;

            $display("");
            $display("################################################################");
            $display("# TEST %0s  | mode = %0s", name, mode ? "INTT" : "NTT");
            $display("################################################################");

            @(negedge i_clk);
            i_mode = mode; i_start = 1'b1; cyc_start = cyc + 1;
            $display("[%0t] TB   : i_start = 1, i_mode = %0d", $time, mode);
            if (!hold) begin @(negedge i_clk); i_start = 1'b0; end

            tcnt = 0;
            while (!o_done && tcnt < TIMEOUT) begin @(negedge i_clk); tcnt = tcnt + 1; end
            if (!o_done) begin errors = errors + 1; $display("[%0t] ERR  TIMEOUT: khong thay o_done", $time); end
            else begin
                cyc_rd = cyc - cyc_start - cyc_load - cyc_ex;
                $display("[%0t] TB   : o_done = 1 sau %0d chu ky (LOAD=%0d, EX=%0d, READ_OUT=%0d)",
                         $time, cyc - cyc_start, cyc_load, cyc_ex, cyc_rd);
            end
            if (hold) begin                              // giu start: done phai giu den khi ha start
                repeat (4) @(negedge i_clk);
                if (!o_done || top_state !== 3'd4) begin errors = errors + 1; $display("[%0t] ERR  FIN khong giu khi i_start con cao", $time); end
                i_start = 1'b0;
            end
            repeat (3) @(negedge i_clk);
            if (top_state !== 3'd0 || o_busy || o_done) begin errors = errors + 1; $display("[%0t] ERR  khong ve IDLE sau done", $time); end

            // ---- [C] dem ----
            if (n_inrd_run  !== 256) begin errors = errors + 1; $display("ERR  so lan doc MEM_IN = %0d (can 256)", n_inrd_run); end
            if (n_outwr_run !== 256) begin errors = errors + 1; $display("ERR  so lan ghi MEM_OUT = %0d (can 256)", n_outwr_run); end
            if (n_bf_run    !== N_BF) begin errors = errors + 1; $display("ERR  so butterfly = %0d (can %0d)", n_bf_run, N_BF); end
            if (n_wr_run    !== N_BF) begin errors = errors + 1; $display("ERR  so lan WR = %0d (can %0d)", n_wr_run, N_BF); end
            if (n_stage_run !== 6)    begin errors = errors + 1; $display("ERR  so lan NEXT_STAGE = %0d (can 6)", n_stage_run); end

            // ---- [D] doi chieu MEM_OUT ----
            mism = 0;
            for (ii = 0; ii < 256; ii = ii + 1)
                if (mem_out[ii] !== ref_f[ii]) begin
                    mism = mism + 1;
                    if (mism <= 5) $display("ERR  MEM_OUT[%0d] = %0d, mong doi %0d", ii, mem_out[ii], ref_f[ii]);
                end
            errors = errors + mism;
            $display("[%0t] TB   : %0d butterfly, %0d tang | MEM_OUT khac tham chieu: %0d / 256 | out[0..3] = %0d %0d %0d %0d",
                     $time, n_bf_run, n_stage_run + 1, mism, mem_out[0], mem_out[1], mem_out[2], mem_out[3]);

            tests_run = tests_run + 1;
            if (errors != err_before) begin tests_failed = tests_failed + 1; $display(">>> %0s : FAIL", name); end
            else                      $display(">>> %0s : PASS", name);
        end
    endtask

    //--------------------------------------------------------------------------
    // KICH BAN CHINH
    //--------------------------------------------------------------------------
    integer rt_mism;
    initial begin
        $timeformat(-9, 0, " ns", 10);
        $dumpfile("tb_ntt_top.vcd");
        $dumpvars(0, tb_ntt_top);
        for (ii = 0; ii < 256; ii = ii + 1) begin mem_in[ii] = 0; mem_out[ii] = 0; sh[ii] = 0; out_seen[ii] = 0; end
        n_bf_run = 0; n_wr_run = 0; n_stage_run = 0; n_inrd_run = 0; n_outwr_run = 0; done_cycles = 0;
        cyc_load = 0; cyc_ex = 0; cyc_start = 0; cyc_vin = 0;

        // ---- reset ----
        $display("[%0t] TB   : RESET", $time);
        i_rst_n = 1'b0;
        repeat (5) @(negedge i_clk);
        i_rst_n = 1'b1;
        repeat (3) @(negedge i_clk);
        if (top_state !== 3'd0 || o_busy || o_done) begin errors = errors + 1; $display("ERR  sau reset phai o IDLE, busy=0, done=0"); end

        // ---- T1: NTT ngau nhien (log chi tiet) ----
        fill_random;
        run_core(1'b0, 1'b1, 1'b0, "T1_NTT_random");

        // ---- T2: INTT ngau nhien (log chi tiet) ----
        fill_random;
        run_core(1'b1, 1'b1, 1'b0, "T2_INTT_random");

        // ---- T3: round-trip : NTT -> (MEM_OUT thanh MEM_IN) -> INTT -> nhan 3303 ----
        fill_random;
        for (ii = 0; ii < 256; ii = ii + 1) orig_f[ii] = mem_in[ii];
        run_core(1'b0, 1'b0, 1'b0, "T3a_roundtrip_NTT");
        for (ii = 0; ii < 256; ii = ii + 1) mem_in[ii] = mem_out[ii];
        run_core(1'b1, 1'b0, 1'b0, "T3b_roundtrip_INTT");
        rt_mism = 0;
        for (ii = 0; ii < 256; ii = ii + 1)
            if (((mem_out[ii] * INV128) % Q) !== orig_f[ii]) rt_mism = rt_mism + 1;
        errors = errors + rt_mism;
        $display("[%0t] TB   : ROUND-TRIP INTT(NTT(f)) * 3303 == f : %0d / 256 sai", $time, rt_mism);
        $display(">>> T3_roundtrip : %0s", rt_mism == 0 ? "PASS" : "FAIL");

        // ---- T4..T7: bien ----
        fill_const(0);      run_core(1'b0, 1'b0, 1'b0, "T4_NTT_all_zero");
        fill_const(3328);   run_core(1'b0, 1'b0, 1'b0, "T5_NTT_all_3328");
        fill_impulse;       run_core(1'b0, 1'b0, 1'b0, "T6_NTT_impulse");
        fill_const(3328);   run_core(1'b1, 1'b0, 1'b0, "T7_INTT_all_3328");
        fill_ramp;          run_core(1'b1, 1'b0, 1'b0, "T8_INTT_ramp");

        // ---- T9: giu i_start cao sau done ----
        fill_random;
        run_core(1'b0, 1'b0, 1'b1, "T9_NTT_hold_start");

        // ---- T10: reset giua chung roi chay lai ----
        fill_random;
        $display("");
        $display("################################################################");
        $display("# TEST T10_reset_mid_run");
        $display("################################################################");
        n_wr_run = 0; n_bf_run = 0; n_stage_run = 0; verbose_run = 1'b0; hold_mode = 1'b0;
        @(negedge i_clk); i_mode = 1'b0; i_start = 1'b1;
        @(negedge i_clk); i_start = 1'b0;
        tcnt = 0;
        while (n_wr_run < 300 && tcnt < TIMEOUT) begin @(negedge i_clk); tcnt = tcnt + 1; end
        $display("[%0t] TB   : RESET giua EX (da WR %0d butterfly, top=%0s, bf=%0s)", $time, n_wr_run, top_name(top_state), bf_name(bf_state));
        i_rst_n = 1'b0;
        repeat (3) @(negedge i_clk);
        i_rst_n = 1'b1;
        repeat (3) @(negedge i_clk);
        if (top_state !== 3'd0 || bf_state !== 3'd0 || o_busy || o_done) begin
            errors = errors + 1; $display("ERR  sau reset giua chung phai ve IDLE (top=%0s bf=%0s)", top_name(top_state), bf_name(bf_state));
        end else $display("[%0t] TB   : sau reset: TOP=IDLE, BF=IDLE, busy=0, done=0  OK", $time);
        fill_random;
        run_core(1'b1, 1'b0, 1'b0, "T10b_INTT_after_reset");

        // ---- tong ket ----
        repeat (5) @(negedge i_clk);
        $display("");
        $display("================================================================");
        $display("  So lan chay : %0d   |  so lan loi : %0d  |  tong chu ky mo phong : %0d", tests_run, tests_failed, cyc);
        if (errors == 0) $display("  TB_NTT_TOP : *** PASS ***  (0 loi)");
        else             $display("  TB_NTT_TOP : *** FAIL ***  (%0d loi)", errors);
        $display("================================================================");
        $finish;
    end

    // watchdog
    initial begin
        #(10 * 20 * TIMEOUT);
        $display("ERR  WATCHDOG het gio");
        $finish;
    end
endmodule
