//==============================================================================
// MODULE : zeta_rom   (ROM ZETA 128 x 12)
// Boc IP "blk_mem_gen_1" cua Vivado Block Memory Generator.
//   Cau hinh IP : Memory Type = Single Port ROM, Width = 12, Depth = 128,
//                 Enable Port Type = Use ENA Pin, KHONG tick Output Register,
//                 Load Init File = zeta.coe (radix 10), Component Name = blk_mem_gen_1
//   zeta[k] = 17^BitRev7(k) mod 3329.  Doc dong bo, tre 1 chu ky.
//==============================================================================
module zeta_rom (
    input  wire        i_clk,
    input  wire        i_ena,
    input  wire [6:0]  i_addr,      // zeta_addr = i
    output wire [11:0] o_dout       // z
);
    blk_mem_gen_1 u_bram (
        .clka (i_clk),
        .ena  (i_ena),
        .addra(i_addr),
        .douta(o_dout)
    );
endmodule
