//==============================================================================
// MODULE : mod_sub      y = (a - b) mod q          (q = 3329)
// Do tre : 1 chu ky.  i_start = 1 -> chu ky ke tiep o_done = 1 va o_y hop le.
//==============================================================================
module mod_sub (
    input  wire        i_clk,
    input  wire        i_rst_n,
    input  wire        i_start,
    input  wire [11:0] i_a,
    input  wire [11:0] i_b,
    output reg  [11:0] o_y,
    output reg         o_done
);
    localparam [12:0] Q = 13'd3329;

    wire [12:0] diff_pos = {1'b0, i_a} - {1'b0, i_b};          // a >= b
    wire [12:0] diff_neg = {1'b0, i_a} + Q - {1'b0, i_b};      // a <  b

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            o_y    <= 12'd0;
            o_done <= 1'b0;
        end else begin
            o_done <= i_start;
            if (i_start) o_y <= (i_a >= i_b) ? diff_pos[11:0] : diff_neg[11:0];
        end
    end
endmodule
