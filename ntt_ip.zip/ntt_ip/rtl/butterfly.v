//==============================================================================
// MODULE : butterfly   (CT / GS hop nhat, q = 3329)  - chua FSM_BUTTERFLY
//
//   mode = 0 (NTT , Cooley-Tukey)      : t  = z * b ; y0 = a + t ; y1 = a - t
//   mode = 1 (INTT, Gentleman-Sande)   : y0 = a + b ; y1 = z * (b - a)
//
// Ben trong (counter / thanh ghi duoc viet thang trong module nay cho gon):
//   - FSM_BUTTERFLY : IDLE, READ, EX, WR, NEXT_BF, NEXT_GRP, NEXT_STAGE, DONE
//   - COUNTER J     : j_cnt     (0 .. len-1 trong 1 nhom)       -> addr_a = start_r + j_cnt
//   - COUNTER I     : i_idx     (chi so zeta  NTT 1->127 | INTT 127->1)
//   - REG START_R   : start_r   (bat dau nhom, += 2*len)
//   - REG LEN       : len       (NTT 128->2 chia 2 | INTT 2->128 nhan 2)
//   - stage_cnt     : dem 7 tang (0..6)
//   - DATAPATH      : u_sub_pre (b-a) -> u_mul (z*x) -> u_add / u_sub
//
// Dinh thoi (c0 = chu ky dau tien cua EX, luc do a,b,z tu RAM/ROM da hop le):
//   READ : phat addr_a, addr_b, zeta_addr + re_a/re_b/rom_en
//   c0   : valid_in = 1  (a,b,z hop le)         ; INTT: u_sub_pre nhan (b,a)
//   c1   : u_mul start   (3 chu ky)  ; INTT: u_sub_pre.o_done = 1
//   c4   : u_mul.o_done = 1 ; u_add / u_sub start
//   c5   : u_add.o_done = 1  == valid_out  -> FSM sang WR
//   WR   : we_a/we_b = 1, ghi y0 -> addr_a, y1 -> addr_b
//==============================================================================
module butterfly (
    input  wire        i_clk,
    input  wire        i_rst_n,
    input  wire        i_bf_start,      // tu FSM_TOP (trang thai EX)
    input  wire        i_mode,          // 0 = NTT, 1 = INTT  (giu nguyen trong luc chay)
    input  wire [11:0] i_a,             // RAM A - port A (doc, tre 1 chu ky)
    input  wire [11:0] i_b,             // RAM A - port B
    input  wire [11:0] i_z,             // ROM zeta
    output wire [7:0]  o_addr_a,        // = j
    output wire [7:0]  o_addr_b,        // = j + len
    output wire [11:0] o_y0,            // ghi vao addr_a
    output wire [11:0] o_y1,            // ghi vao addr_b
    output wire        o_we_a,
    output wire        o_we_b,
    output wire        o_re_a,
    output wire        o_re_b,
    output wire        o_rom_en,
    output wire [6:0]  o_zeta_addr,     // = i
    output wire        o_bf_done        // xung 1 chu ky khi xong 7 tang x 128 cap
);
    //--------------------------------------------------------------------------
    // FSM_BUTTERFLY
    //--------------------------------------------------------------------------
    localparam [2:0] S_IDLE       = 3'd0,
                     S_READ       = 3'd1,
                     S_EX         = 3'd2,
                     S_WR         = 3'd3,
                     S_NEXT_BF    = 3'd4,
                     S_NEXT_GRP   = 3'd5,
                     S_NEXT_STAGE = 3'd6,
                     S_DONE       = 3'd7;

    reg [2:0] state, next_state;

    // counter / thanh ghi
    reg [7:0] len;          // REG LEN
    reg [7:0] start_r;      // REG START_R
    reg [7:0] j_cnt;        // COUNTER J
    reg [6:0] i_idx;        // COUNTER I
    reg [2:0] stage_cnt;    // dem tang 0..6

    wire       valid_out;
    reg        valid_in;

    // ---- dieu kien re nhanh (tinh to hop tu thanh ghi hien tai) ----
    wire       j_last     = ((j_cnt + 8'd1) == len);           // cap cuoi cua nhom
    wire [8:0] nxt_start  = {1'b0, start_r} + {len, 1'b0};     // start_r + 2*len
    wire       grp_last   = nxt_start[8];                      // nxt_start >= 256
    wire       stage_last = (stage_cnt == 3'd6);               // tang thu 7

    always @(posedge i_clk) begin
        if (!i_rst_n) state <= S_IDLE;
        else          state <= next_state;
    end

    always @* begin
        next_state = state;
        case (state)
            S_IDLE:       if (i_bf_start) next_state = S_READ;
            S_READ:       next_state = S_EX;
            S_EX:         if (valid_out) next_state = S_WR;
            S_WR: begin
                if      (!j_last)     next_state = S_NEXT_BF;
                else if (!grp_last)   next_state = S_NEXT_GRP;
                else if (!stage_last) next_state = S_NEXT_STAGE;
                else                  next_state = S_DONE;
            end
            S_NEXT_BF:    next_state = S_READ;
            S_NEXT_GRP:   next_state = S_READ;
            S_NEXT_STAGE: next_state = S_READ;
            S_DONE:       next_state = S_IDLE;
            default:      next_state = S_IDLE;
        endcase
    end

    // ---- cap nhat counter / thanh ghi theo state ----
    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            len <= 8'd128; start_r <= 8'd0; j_cnt <= 8'd0;
            i_idx <= 7'd1; stage_cnt <= 3'd0;
        end else begin
            case (state)
                S_IDLE: begin                       // nap gia tri ban dau theo mode
                    len       <= i_mode ? 8'd2   : 8'd128;
                    i_idx     <= i_mode ? 7'd127 : 7'd1;
                    start_r   <= 8'd0;
                    j_cnt     <= 8'd0;
                    stage_cnt <= 3'd0;
                end
                S_WR: begin                         // xong 1 cap -> j_cnt + 1
                    j_cnt <= j_cnt + 8'd1;
                end
                S_NEXT_GRP: begin                   // sang nhom ke trong cung tang
                    start_r <= nxt_start[7:0];
                    j_cnt   <= 8'd0;
                    i_idx   <= i_mode ? (i_idx - 7'd1) : (i_idx + 7'd1);
                end
                S_NEXT_STAGE: begin                 // sang tang ke
                    len       <= i_mode ? (len << 1) : (len >> 1);
                    start_r   <= 8'd0;
                    j_cnt     <= 8'd0;
                    i_idx     <= i_mode ? (i_idx - 7'd1) : (i_idx + 7'd1);
                    stage_cnt <= stage_cnt + 3'd1;
                end
                default: ;
            endcase
        end
    end

    // valid_in = 1 o chu ky dau cua EX (luc a, b, z tu BRAM da hop le)
    always @(posedge i_clk) begin
        if (!i_rst_n) valid_in <= 1'b0;
        else          valid_in <= (state == S_READ);
    end

    //--------------------------------------------------------------------------
    // Dau ra dieu khien / dia chi (Moore, gan tu state)
    //--------------------------------------------------------------------------
    assign o_re_a      = (state == S_READ);
    assign o_re_b      = (state == S_READ);
    assign o_rom_en    = (state == S_READ);
    assign o_we_a      = (state == S_WR);
    assign o_we_b      = (state == S_WR);
    assign o_bf_done   = (state == S_DONE);
    assign o_addr_a    = start_r + j_cnt;               // j
    assign o_addr_b    = start_r + j_cnt + len;         // j + len
    assign o_zeta_addr = i_idx;                         // i

    //--------------------------------------------------------------------------
    // DATAPATH : cong / tru / nhan mod q, pipeline
    //--------------------------------------------------------------------------
    reg         v1;
    reg  [11:0] a1, a2, a3, a4;
    reg  [11:0] b1, b2, b3, b4;
    reg  [11:0] z1;
    reg  [11:0] r5;

    always @(posedge i_clk) begin
        if (!i_rst_n) v1 <= 1'b0;
        else          v1 <= valid_in;
        if (valid_in) begin
            a1 <= i_a; b1 <= i_b; z1 <= i_z;
        end
        a2 <= a1; a3 <= a2; a4 <= a3;               // can a, b theo ket qua nhan
        b2 <= b1; b3 <= b2; b4 <= b3;
    end

    // INTT: x = b - a
    wire [11:0] pre_y;
    wire        pre_done;
    mod_sub u_sub_pre (
        .i_clk(i_clk), .i_rst_n(i_rst_n),
        .i_start(valid_in & i_mode),
        .i_a(i_b), .i_b(i_a),
        .o_y(pre_y), .o_done(pre_done)
    );

    // NTT: t = z*b | INTT: z*(b-a)
    wire [11:0] mul_y;
    wire        mul_done;
    mod_mul u_mul (
        .i_clk(i_clk), .i_rst_n(i_rst_n),
        .i_start(v1),
        .i_a(i_mode ? pre_y : b1), .i_b(z1),
        .o_y(mul_y), .o_done(mul_done)
    );

    // y0 = a + (NTT: t | INTT: b)
    wire [11:0] add_y;
    wire        add_done;
    mod_add u_add (
        .i_clk(i_clk), .i_rst_n(i_rst_n),
        .i_start(mul_done),
        .i_a(a4), .i_b(i_mode ? b4 : mul_y),
        .o_y(add_y), .o_done(add_done)
    );

    // NTT: y1 = a - t
    wire [11:0] sub_y;
    wire        sub_done;
    mod_sub u_sub (
        .i_clk(i_clk), .i_rst_n(i_rst_n),
        .i_start(mul_done),
        .i_a(a4), .i_b(mul_y),
        .o_y(sub_y), .o_done(sub_done)
    );

    // INTT: y1 = z*(b-a), tre them 1 chu ky cho thang hang voi add
    always @(posedge i_clk) begin
        if (!i_rst_n)      r5 <= 12'd0;
        else if (mul_done) r5 <= mul_y;
    end

    assign valid_out = add_done;
    assign o_y0      = add_y;
    assign o_y1      = i_mode ? r5 : sub_y;
endmodule
