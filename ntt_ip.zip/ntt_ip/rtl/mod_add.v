//==============================================================================
// MODULE : mod_add      y = (a + b) mod q          (q = 3329)
// Do tre : 1 chu ky.  i_start = 1 -> chu ky ke tiep o_done = 1 va o_y hop le.
// o_y duoc GIU nguyen cho den lan i_start ke tiep.
//==============================================================================
module mod_add (
    input  wire        i_clk,
    input  wire        i_rst_n,
    input  wire        i_start,     // toan hang i_a, i_b hop le
    input  wire [11:0] i_a,
    input  wire [11:0] i_b,
    output reg  [11:0] o_y,
    output reg         o_done       // ket qua o_y hop le (xung 1 chu ky)
);
    localparam [12:0] Q = 13'd3329;

    wire [12:0] sum = {1'b0, i_a} + {1'b0, i_b};   // toi da 6656 < 8192
    wire [12:0] red = sum - Q;

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            o_y    <= 12'd0;
            o_done <= 1'b0;
        end else begin
            o_done <= i_start;
            if (i_start) o_y <= (sum >= Q) ? red[11:0] : sum[11:0];
        end
    end
endmodule
