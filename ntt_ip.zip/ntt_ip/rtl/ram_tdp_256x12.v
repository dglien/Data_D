//==============================================================================
// MODULE : ram_tdp_256x12   (RAM A - True Dual Port 256 x 12)
// Boc IP "blk_mem_gen_0" cua Vivado Block Memory Generator.
//   Cau hinh IP : Memory Type = True Dual Port RAM, Common Clock
//                 Width = 12, Depth = 256, Operating Mode = Read First (ca 2 port)
//                 Enable Port Type = Use ENA/ENB Pin, KHONG tick Primitives Output Register
//                 Byte Write Enable = off, Component Name = blk_mem_gen_0
//   Doc dong bo, du lieu ra tre 1 chu ky so voi dia chi.
//   Port A : nap du lieu (LOAD) / doc ket qua (READ_OUT) / butterfly (addr_a)
//   Port B : butterfly (addr_b = j + len)
//==============================================================================
module ram_tdp_256x12 (
    input  wire        i_clk,
    // Port A
    input  wire        i_ena,
    input  wire        i_wea,
    input  wire [7:0]  i_addra,
    input  wire [11:0] i_dina,
    output wire [11:0] o_douta,
    // Port B
    input  wire        i_enb,
    input  wire        i_web,
    input  wire [7:0]  i_addrb,
    input  wire [11:0] i_dinb,
    output wire [11:0] o_doutb
);
    blk_mem_gen_0 u_bram (
        .clka (i_clk),  .ena(i_ena), .wea(i_wea), .addra(i_addra),
        .dina (i_dina), .douta(o_douta),
        .clkb (i_clk),  .enb(i_enb), .web(i_web), .addrb(i_addrb),
        .dinb (i_dinb), .doutb(o_doutb)
    );
endmodule
