//==============================================================================
// MODULE : mod_mul      y = (a * b) mod q          (q = 3329), Barrett
// Do tre : 3 chu ky.
//   Tang 1 : p = a * b                       (12x12 -> 24 bit)
//   Tang 2 : t = floor(p * 5039 / 2^24)      (5039 = floor(2^24 / 3329))
//   Tang 3 : r = p - t*q ; neu r >= q thi r -= q   (r < 2q nen 1 lan tru la du)
// i_start = 1 -> sau 3 chu ky o_done = 1 va o_y hop le.
// Dieu kien: a, b trong [0, q-1]  =>  p < q^2 < 2^24.
//==============================================================================
module mod_mul (
    input  wire        i_clk,
    input  wire        i_rst_n,
    input  wire        i_start,
    input  wire [11:0] i_a,
    input  wire [11:0] i_b,
    output reg  [11:0] o_y,
    output reg         o_done
);
    localparam [23:0] Q = 24'd3329;

    // ---- tang 1 ----
    reg         s1_v;
    reg  [23:0] s1_p;
    // ---- tang 2 ----
    reg         s2_v;
    reg  [23:0] s2_p;
    reg  [11:0] s2_t;
    // ---- tang 3 (tinh to hop) ----
    wire [23:0] tq  = s2_t * 12'd3329;
    wire [23:0] r   = s2_p - tq;
    wire [23:0] r_c = r - Q;

    wire [36:0] pm  = {13'd0, s1_p} * 37'd5039;

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            s1_v <= 1'b0; s2_v <= 1'b0; o_done <= 1'b0;
            s1_p <= 24'd0; s2_p <= 24'd0; s2_t <= 12'd0; o_y <= 12'd0;
        end else begin
            // tang 1
            s1_v <= i_start;
            if (i_start) s1_p <= i_a * i_b;
            // tang 2
            s2_v <= s1_v;
            if (s1_v) begin
                s2_p <= s1_p;
                s2_t <= pm[35:24];
            end
            // tang 3
            o_done <= s2_v;
            if (s2_v) o_y <= (r >= Q) ? r_c[11:0] : r[11:0];
        end
    end
endmodule
