//==============================================================================
// MODULE : ntt_top   (TOP bao toan bo IP NTT/INTT ML-KEM, q = 3329)
//
//   ntt_top
//   |-- u_ram_a     : ram_tdp_256x12  (blk_mem_gen_0, True Dual Port 256x12)
//   |-- u_zeta_rom  : zeta_rom        (blk_mem_gen_1, ROM 128x12)
//   `-- u_butterfly : butterfly       (FSM_BUTTERFLY + counter j/i + reg start_r/len
//                                      + u_sub_pre / u_mul / u_add / u_sub)
//   + trong chinh module nay : FSM_TOP, COUNTER DATA, MUX Port A (sel_proc)
//
// Giao tiep ngoai (khong dung AXI):
//   MEM_IN  : core phat o_in_en/o_in_addr, MEM_IN tra i_in_data SAU 1 CHU KY
//   MEM_OUT : core ghi o_out_we/o_out_addr/o_out_data (ghi dong bo)
//   Dieu khien : i_start (xung), i_mode (0 NTT, 1 INTT), o_busy, o_done
//
// FSM_TOP : IDLE -> LOAD_DATA -> EX -> READ_OUT -> FIN -> IDLE
//   IDLE      : cho i_start, chot mode
//   LOAD_DATA : cnt 0..255, MEM_IN -> RAM A (port A)
//   EX        : butterfly chay 7 tang x 128 cap (chi tiet READ/EX/WR nam trong
//               FSM_BUTTERFLY), cho o_bf_done
//   READ_OUT  : cnt 0..255, RAM A (port A) -> MEM_OUT
//   FIN       : o_done = 1, cho i_start ha xuong roi ve IDLE
//
// Luu y: ket qua INTT la ket qua THO cua thuat toan 10 FIPS 203 (chua nhan 128^-1
//        = 3303 mod q o buoc cuoi).
//==============================================================================
module ntt_top (
    input  wire        i_clk,
    input  wire        i_rst_n,
    input  wire        i_start,
    input  wire        i_mode,          // 0 = NTT, 1 = INTT
    // MEM_IN
    output wire        o_in_en,
    output wire [7:0]  o_in_addr,
    input  wire [11:0] i_in_data,
    // MEM_OUT
    output wire        o_out_we,
    output wire [7:0]  o_out_addr,
    output wire [11:0] o_out_data,
    // trang thai
    output wire        o_busy,
    output wire        o_done
);
    //--------------------------------------------------------------------------
    // FSM_TOP
    //--------------------------------------------------------------------------
    localparam [2:0] S_IDLE      = 3'd0,
                     S_LOAD_DATA = 3'd1,
                     S_EX        = 3'd2,
                     S_READ_OUT  = 3'd3,
                     S_FIN       = 3'd4;

    reg [2:0] state, next_state;
    reg       mode_q;                   // mode chot luc start

    // COUNTER DATA : 0 -> 256 (nap / doc ra)
    reg  [8:0] cnt;
    wire       cnt_done = cnt[8];       // cnt = 256
    reg        dat_vld;                 // lenh doc truoc do 1 chu ky (du lieu dang ve)
    reg  [7:0] dat_addr;                // dia chi cua du lieu dang ve

    wire       bf_done;
    wire       sel_proc = (state == S_EX);    // 1: butterfly dieu khien port A

    wire       ld_issue = (state == S_LOAD_DATA) && !cnt_done;   // phat dia chi MEM_IN
    wire       rd_issue = (state == S_READ_OUT)  && !cnt_done;   // phat dia chi doc RAM
    wire       ld_we    = (state == S_LOAD_DATA) && dat_vld;     // ghi RAM A

    always @(posedge i_clk) begin
        if (!i_rst_n) state <= S_IDLE;
        else          state <= next_state;
    end

    always @* begin
        next_state = state;
        case (state)
            S_IDLE:      if (i_start)                   next_state = S_LOAD_DATA;
            S_LOAD_DATA: if (cnt_done && !dat_vld)      next_state = S_EX;
            S_EX:        if (bf_done)                   next_state = S_READ_OUT;
            S_READ_OUT:  if (cnt_done && !dat_vld)      next_state = S_FIN;
            S_FIN:       if (!i_start)                  next_state = S_IDLE;
            default:                                    next_state = S_IDLE;
        endcase
    end

    assign o_busy = (state != S_IDLE) && (state != S_FIN);
    assign o_done = (state == S_FIN);

    always @(posedge i_clk) begin
        if (!i_rst_n)                           mode_q <= 1'b0;
        else if (state == S_IDLE && i_start)    mode_q <= i_mode;
    end

    always @(posedge i_clk) begin
        if (!i_rst_n || state == S_IDLE || state == S_EX) cnt <= 9'd0;
        else if (ld_issue || rd_issue)                    cnt <= cnt + 9'd1;
    end

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            dat_vld  <= 1'b0;
            dat_addr <= 8'd0;
        end else begin
            dat_vld  <= ld_issue | rd_issue;
            dat_addr <= cnt[7:0];
        end
    end

    //--------------------------------------------------------------------------
    // MEM_IN / MEM_OUT
    //--------------------------------------------------------------------------
    assign o_in_en   = ld_issue;
    assign o_in_addr = cnt[7:0];

    wire [11:0] ram_douta, ram_doutb;
    assign o_out_we   = (state == S_READ_OUT) && dat_vld;
    assign o_out_addr = dat_addr;
    assign o_out_data = ram_douta;

    //--------------------------------------------------------------------------
    // butterfly + zeta_rom + RAM A (MUX port A theo sel_proc)
    //--------------------------------------------------------------------------
    wire [7:0]  bf_addr_a, bf_addr_b;
    wire [11:0] bf_y0, bf_y1, z;
    wire        bf_we_a, bf_we_b, bf_re_a, bf_re_b;
    wire        bf_rom_en;
    wire [6:0]  bf_zeta_addr;

    butterfly u_butterfly (
        .i_clk(i_clk), .i_rst_n(i_rst_n),
        .i_bf_start(sel_proc), .i_mode(mode_q),
        .i_a(ram_douta), .i_b(ram_doutb), .i_z(z),
        .o_addr_a(bf_addr_a), .o_addr_b(bf_addr_b),
        .o_y0(bf_y0), .o_y1(bf_y1),
        .o_we_a(bf_we_a), .o_we_b(bf_we_b), .o_re_a(bf_re_a), .o_re_b(bf_re_b),
        .o_rom_en(bf_rom_en), .o_zeta_addr(bf_zeta_addr),
        .o_bf_done(bf_done)
    );

    zeta_rom u_zeta_rom (
        .i_clk(i_clk), .i_ena(bf_rom_en), .i_addr(bf_zeta_addr), .o_dout(z)
    );

    wire        ram_ena   = sel_proc ? (bf_re_a | bf_we_a) : (ld_we | rd_issue);
    wire        ram_wea   = sel_proc ? bf_we_a : ld_we;
    wire [7:0]  ram_addra = sel_proc ? bf_addr_a : (ld_we ? dat_addr : cnt[7:0]);
    wire [11:0] ram_dina  = sel_proc ? bf_y0     : i_in_data;

    ram_tdp_256x12 u_ram_a (
        .i_clk(i_clk),
        .i_ena (ram_ena), .i_wea(ram_wea), .i_addra(ram_addra),
        .i_dina(ram_dina), .o_douta(ram_douta),
        .i_enb (bf_re_b | bf_we_b), .i_web(bf_we_b), .i_addrb(bf_addr_b),
        .i_dinb(bf_y1), .o_doutb(ram_doutb)
    );
endmodule
