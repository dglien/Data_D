# NTT/INTT IP Core cho ML-KEM (q = 3329) - Verilog

Core 256 hệ số × 12 bit, 7 tầng × 128 butterfly, CT (NTT) / GS (INTT) hợp nhất.
**Không còn AXI4-Lite**: dữ liệu vào từ `MEM_IN`, kết quả ghi ra `MEM_OUT`.

## Cấu trúc file

```
rtl/
  mod_add.v          y = (a+b) mod q            trễ 1   (i_start -> o_done)
  mod_sub.v          y = (a-b) mod q            trễ 1
  mod_mul.v          y = (a*b) mod q  Barrett   trễ 3
  butterfly.v        FSM_BUTTERFLY + counter j/i + reg start_r/len + datapath (dùng add/sub/mul)
  ram_tdp_256x12.v   wrapper IP blk_mem_gen_0 (True Dual Port RAM 256x12)
  zeta_rom.v         wrapper IP blk_mem_gen_1 (ROM 128x12, nạp zeta.coe)
  ntt_top.v          FSM_TOP + counter data + MUX port A + nối tất cả
sim_models/          model mô phỏng của 2 IP (CHỈ dùng khi sim không có IP) + zeta.coe
tb/
  tb_mod_arith.v     test add/sub/mul + chuỗi ADD->SUB->MUL
  tb_ntt_top.v       test hệ thống (scoreboard từng butterfly, log state, tham chiếu FIPS 203)
scripts/
  run_iverilog.sh    chạy cả 2 testbench bằng Icarus Verilog
  wave_ntt_top.tcl   gom nhóm waveform Vivado xsim   (wave_ntt_top.do cho ModelSim)
  wave_mod_arith.tcl gom nhóm waveform cho tb_mod_arith
```

## Cổng ntt_top

| Cổng | Hướng | Ý nghĩa |
|---|---|---|
| `i_clk`, `i_rst_n` | in | clock, reset đồng bộ mức thấp |
| `i_start` | in | xung bắt đầu (chỉ nhận ở IDLE) |
| `i_mode` | in | 0 = NTT, 1 = INTT (chốt lúc start) |
| `o_in_en`, `o_in_addr[7:0]` | out | địa chỉ đọc MEM_IN |
| `i_in_data[11:0]` | in | dữ liệu MEM_IN, **trễ 1 chu kỳ** sau địa chỉ (BRAM đồng bộ) |
| `o_out_we`, `o_out_addr[7:0]`, `o_out_data[11:0]` | out | ghi MEM_OUT (đồng bộ) |
| `o_busy`, `o_done` | out | `o_done` giữ ở FIN đến khi `i_start` hạ xuống (xung start 1 chu kỳ => done 1 chu kỳ) |

## FSM

**FSM_TOP** (trong `ntt_top.v`): `IDLE -> LOAD_DATA -> EX -> READ_OUT -> FIN -> IDLE`
- LOAD_DATA: counter data 0→255, MEM_IN → RAM A (port A). Xong khi cnt = 256 và dữ liệu cuối đã ghi.
- EX: `sel_proc = 1`, nhường port A cho butterfly, chờ `bf_done`.
- READ_OUT: counter data 0→255, RAM A → MEM_OUT.
- Sơ đồ FSM_TOPCORE trong ảnh có vòng EX↔WR: vòng đó chính là READ/EX/WR nằm trong FSM_BUTTERFLY nên mình để trong `butterfly.v`; ở top, EX chờ `bf_done`. Phần xuất kết quả ra MEM_OUT là state `READ_OUT`.

**FSM_BUTTERFLY** (trong `butterfly.v`): `IDLE, READ, EX, WR, NEXT_BF, NEXT_GRP, NEXT_STAGE, DONE` đúng theo ảnh.
Pipeline mỗi butterfly (c0 = chu kỳ `valid_in`): SUB_PRE (INTT) c1 → MUL done c4 → ADD/SUB done c5 (= `valid_out`) → WR.
Mỗi butterfly ≈ 9 chu kỳ; cả lần chạy ≈ 8.6k chu kỳ (LOAD 259 + EX 8065 + READ_OUT 257).

## Tạo IP trong Vivado

- `blk_mem_gen_0`: True Dual Port RAM, Common Clock, width 12, depth 256, **Read First** cả 2 port, *Use ENA/ENB pin*, **bỏ tick Output Register**, không byte-write.
- `blk_mem_gen_1`: Single Port ROM, width 12, depth 128, *Use ENA pin*, **bỏ tick Output Register**, Load Init File = `sim_models/zeta.coe` (radix 10).
- Khi đã có IP thì **không** add `sim_models/blk_mem_gen_*.v` vào project.

## Chạy mô phỏng

- Icarus: `sh scripts/run_iverilog.sh`
- Vivado: add `rtl/*` + `tb/*`, đặt top sim là `tb_ntt_top` (hoặc `tb_mod_arith`), `launch_simulation`, rồi `source scripts/wave_ntt_top.tcl` và `run all`. Các tín hiệu `top_state_name` / `bf_state_name` đặt radix ASCII (script đã đặt) để đọc tên state.

## Lưu ý

- Kết quả INTT là kết quả **thô** của thuật toán 10 FIPS 203, **chưa nhân 128⁻¹ = 3303**. Testbench kiểm round-trip `INTT(NTT(f)) × 3303 == f`.
- Đầu vào phải nằm trong [0, 3328].
- Ảnh có tín hiệu `in_wr_en` từ MEM_IN và `rom_en`; ở đây `i_start` coi như MEM_IN đã sẵn sàng, `rom_en` do butterfly phát (state READ).
