//==============================================================================
// MO HINH MO PHONG cua IP blk_mem_gen_0 (True Dual Port RAM 256x12, Read First,
// khong Output Register -> doc tre 1 chu ky). CHI DUNG DE MO PHONG KHI KHONG CO IP.
// Neu da generate IP trong Vivado thi KHONG them file nay vao project.
//==============================================================================
module blk_mem_gen_0 (
    input  wire        clka, ena, wea,
    input  wire [7:0]  addra,
    input  wire [11:0] dina,
    output reg  [11:0] douta,
    input  wire        clkb, enb, web,
    input  wire [7:0]  addrb,
    input  wire [11:0] dinb,
    output reg  [11:0] doutb
);
    reg [11:0] mem [0:255];
    integer k;
    initial begin
        for (k = 0; k < 256; k = k + 1) mem[k] = 12'd0;
        douta = 12'd0; doutb = 12'd0;
    end
    always @(posedge clka) if (ena) begin
        if (wea) mem[addra] <= dina;
        douta <= mem[addra];                 // Read First
    end
    always @(posedge clkb) if (enb) begin
        if (web) mem[addrb] <= dinb;
        doutb <= mem[addrb];
    end
endmodule
