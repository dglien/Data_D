# Gom nhom waveform cho tb_mod_arith
# Vivado xsim: sau khi chay launch_simulation, go trong Tcl Console:
#   source scripts/wave_mod_arith.tcl
# (hoac: Settings > Simulation > xsim.simulate.custom_tcl). Sau do 'run all'.
# Radix ASCII cho cac tin hieu *_state_name de doc ten state.
proc _wg {title sigs} {
  set g [add_wave_group $title]
  foreach {s r} $sigs { add_wave -into $g -radix $r $s }
  return $g
}

_wg {00_CLK_RST} {
  {/tb_mod_arith/i_clk} hex
  {/tb_mod_arith/i_rst_n} hex
}
_wg {01_ADD} {
  {/tb_mod_arith/add_start} hex
  {/tb_mod_arith/add_a} unsigned
  {/tb_mod_arith/add_b} unsigned
  {/tb_mod_arith/add_y} unsigned
  {/tb_mod_arith/add_done} hex
  {/tb_mod_arith/add_ey} unsigned
}
_wg {02_SUB} {
  {/tb_mod_arith/sub_start} hex
  {/tb_mod_arith/sub_a} unsigned
  {/tb_mod_arith/sub_b} unsigned
  {/tb_mod_arith/sub_y} unsigned
  {/tb_mod_arith/sub_done} hex
  {/tb_mod_arith/sub_ey} unsigned
}
_wg {03_MUL} {
  {/tb_mod_arith/mul_start} hex
  {/tb_mod_arith/mul_a} unsigned
  {/tb_mod_arith/mul_b} unsigned
  {/tb_mod_arith/mul_y} unsigned
  {/tb_mod_arith/mul_done} hex
  {/tb_mod_arith/mul_e2} unsigned
}
_wg {04_CHAIN_ADD} {
  {/tb_mod_arith/c_start} hex
  {/tb_mod_arith/c_x} unsigned
  {/tb_mod_arith/c_y} unsigned
  {/tb_mod_arith/c_add_y} unsigned
  {/tb_mod_arith/c_add_done} hex
}
_wg {05_CHAIN_SUB} {
  {/tb_mod_arith/c_w1} unsigned
  {/tb_mod_arith/c_sub_y} unsigned
  {/tb_mod_arith/c_sub_done} hex
}
_wg {06_CHAIN_MUL} {
  {/tb_mod_arith/c_u2} unsigned
  {/tb_mod_arith/c_mul_y} unsigned
  {/tb_mod_arith/c_mul_done} hex
}
_wg {07_TB_CHECKER} {
  {/tb_mod_arith/errors} unsigned
}
