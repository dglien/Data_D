#!/bin/sh
# Chay mo phong bang Icarus Verilog (thu muc goc ntt_ip/):  sh scripts/run_iverilog.sh
set -e
cd "$(dirname "$0")/.."
mkdir -p build
RTL="rtl/mod_add.v rtl/mod_sub.v rtl/mod_mul.v rtl/butterfly.v rtl/ram_tdp_256x12.v rtl/zeta_rom.v rtl/ntt_top.v"
MODELS="sim_models/blk_mem_gen_0.v sim_models/blk_mem_gen_1.v"
iverilog -g2005 -o build/arith.vvp rtl/mod_add.v rtl/mod_sub.v rtl/mod_mul.v tb/tb_mod_arith.v
iverilog -g2005 -o build/top.vvp   $RTL $MODELS tb/tb_ntt_top.v
echo "######## tb_mod_arith ########"; (cd build && vvp arith.vvp)
echo "######## tb_ntt_top   ########"; (cd build && vvp top.vvp)
