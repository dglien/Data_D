# Gom nhom waveform cho tb_ntt_top
# Vivado xsim: sau khi chay launch_simulation, go trong Tcl Console:
#   source scripts/wave_ntt_top.tcl
# (hoac: Settings > Simulation > xsim.simulate.custom_tcl). Sau do 'run all'.
# Radix ASCII cho cac tin hieu *_state_name de doc ten state.
proc _wg {title sigs} {
  set g [add_wave_group $title]
  foreach {s r} $sigs { add_wave -into $g -radix $r $s }
  return $g
}

_wg {00_CLK_RST} {
  {/tb_ntt_top/i_clk} hex
  {/tb_ntt_top/i_rst_n} hex
}
_wg {01_TOP_CTRL (FSM_TOP + counter data)} {
  {/tb_ntt_top/i_start} hex
  {/tb_ntt_top/i_mode} hex
  {/tb_ntt_top/o_busy} hex
  {/tb_ntt_top/o_done} hex
  {/tb_ntt_top/top_state_name} ascii
  {/tb_ntt_top/dut/state} unsigned
  {/tb_ntt_top/dut/mode_q} hex
  {/tb_ntt_top/dut/cnt} unsigned
  {/tb_ntt_top/dut/sel_proc} hex
  {/tb_ntt_top/dut/dat_vld} hex
  {/tb_ntt_top/dut/dat_addr} unsigned
  {/tb_ntt_top/dut/bf_done} hex
}
_wg {02_MEM_IN} {
  {/tb_ntt_top/o_in_en} hex
  {/tb_ntt_top/o_in_addr} unsigned
  {/tb_ntt_top/i_in_data} unsigned
}
_wg {03_MEM_OUT} {
  {/tb_ntt_top/o_out_we} hex
  {/tb_ntt_top/o_out_addr} unsigned
  {/tb_ntt_top/o_out_data} unsigned
}
_wg {04_RAM_A_PORT_A} {
  {/tb_ntt_top/dut/ram_ena} hex
  {/tb_ntt_top/dut/ram_wea} hex
  {/tb_ntt_top/dut/ram_addra} unsigned
  {/tb_ntt_top/dut/ram_dina} unsigned
  {/tb_ntt_top/dut/ram_douta} unsigned
}
_wg {05_RAM_A_PORT_B} {
  {/tb_ntt_top/dut/u_ram_a/i_enb} hex
  {/tb_ntt_top/dut/u_ram_a/i_web} hex
  {/tb_ntt_top/dut/u_ram_a/i_addrb} unsigned
  {/tb_ntt_top/dut/u_ram_a/i_dinb} unsigned
  {/tb_ntt_top/dut/ram_doutb} unsigned
}
_wg {06_ROM_ZETA} {
  {/tb_ntt_top/dut/bf_rom_en} hex
  {/tb_ntt_top/dut/bf_zeta_addr} unsigned
  {/tb_ntt_top/dut/z} unsigned
}
_wg {07_BUTTERFLY_FSM (state, counter j/i, reg start_r/len)} {
  {/tb_ntt_top/bf_state_name} ascii
  {/tb_ntt_top/dut/u_butterfly/state} unsigned
  {/tb_ntt_top/dut/u_butterfly/i_bf_start} hex
  {/tb_ntt_top/dut/u_butterfly/j_cnt} unsigned
  {/tb_ntt_top/dut/u_butterfly/start_r} unsigned
  {/tb_ntt_top/dut/u_butterfly/len} unsigned
  {/tb_ntt_top/dut/u_butterfly/i_idx} unsigned
  {/tb_ntt_top/dut/u_butterfly/stage_cnt} unsigned
  {/tb_ntt_top/dut/u_butterfly/o_re_a} hex
  {/tb_ntt_top/dut/u_butterfly/o_re_b} hex
  {/tb_ntt_top/dut/u_butterfly/o_we_a} hex
  {/tb_ntt_top/dut/u_butterfly/o_we_b} hex
  {/tb_ntt_top/dut/u_butterfly/o_addr_a} unsigned
  {/tb_ntt_top/dut/u_butterfly/o_addr_b} unsigned
  {/tb_ntt_top/dut/u_butterfly/valid_in} hex
  {/tb_ntt_top/dut/u_butterfly/valid_out} hex
  {/tb_ntt_top/dut/u_butterfly/o_bf_done} hex
}
_wg {08_BUTTERFLY_DATA (a, b, z -> y0, y1)} {
  {/tb_ntt_top/dut/u_butterfly/i_a} unsigned
  {/tb_ntt_top/dut/u_butterfly/i_b} unsigned
  {/tb_ntt_top/dut/u_butterfly/i_z} unsigned
  {/tb_ntt_top/dut/u_butterfly/o_y0} unsigned
  {/tb_ntt_top/dut/u_butterfly/o_y1} unsigned
}
_wg {09_SUB_PRE (b - a, chi INTT)} {
  {/tb_ntt_top/dut/u_butterfly/u_sub_pre/i_start} hex
  {/tb_ntt_top/dut/u_butterfly/u_sub_pre/i_a} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_sub_pre/i_b} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_sub_pre/o_y} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_sub_pre/o_done} hex
}
_wg {10_MUL (z * x mod q, 3 tang)} {
  {/tb_ntt_top/dut/u_butterfly/u_mul/i_start} hex
  {/tb_ntt_top/dut/u_butterfly/u_mul/i_a} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_mul/i_b} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_mul/s1_v} hex
  {/tb_ntt_top/dut/u_butterfly/u_mul/s2_v} hex
  {/tb_ntt_top/dut/u_butterfly/u_mul/o_y} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_mul/o_done} hex
}
_wg {11_ADD (y0)} {
  {/tb_ntt_top/dut/u_butterfly/u_add/i_start} hex
  {/tb_ntt_top/dut/u_butterfly/u_add/i_a} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_add/i_b} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_add/o_y} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_add/o_done} hex
}
_wg {12_SUB (y1 cua NTT)} {
  {/tb_ntt_top/dut/u_butterfly/u_sub/i_start} hex
  {/tb_ntt_top/dut/u_butterfly/u_sub/i_a} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_sub/i_b} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_sub/o_y} unsigned
  {/tb_ntt_top/dut/u_butterfly/u_sub/o_done} hex
}
_wg {13_TB_CHECKER} {
  {/tb_ntt_top/errors} unsigned
  {/tb_ntt_top/cyc} unsigned
  {/tb_ntt_top/n_bf_run} unsigned
  {/tb_ntt_top/n_wr_run} unsigned
  {/tb_ntt_top/n_stage_run} unsigned
}
