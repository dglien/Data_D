`timescale 1ns/1ps
//==============================================================================
// tb_all : TESTBENCH TONG - 1 mach lien tuc trong 1 lan mo phong, he so dau vao doc tu FILE
//
//   S1_ADD     : mod_add            -> add_done  --(r_add)-->
//   S2_SUB     : mod_sub            -> sub_done  --(r_sub)-->
//   S3_MUL     : mod_mul (Barrett)  -> mul_done  --(r_mul)-->
//   S4_BUTTERFLY_CT / GS / SCALE : khoi butterfly (1 add + 1 sub + 1 mul dung chung),
//                                   dau vao lay tu ket qua S1-S3
//   S5_NTT_FILE : doc data/ntt_input_single.txt vao mem_in (o nho trong tb)
//                 -> ext_wr_en, ext_addr = 0..255 -> RAM A -> FSM_TOPCORE: LOAD_DATA -> EX
//                 (FSM_BUTTERFLY) -> READ_DATA -> mem_out
//                 -> ghi data/ntt_output_single.txt ; so voi data/ntt_expected_single.txt
//                    va mo hinh vang trong tb
//   S6_INTT_FILE: INTT(ket qua S5) -> phai ra lai input ; ghi data/intt_output_single.txt
//
//   Sau khi chay xong, kiem bang phan mem:
//     python tools/check_ntt.py --mode ntt  --in data/ntt_input_single.txt  --out data/ntt_output_single.txt
//     python tools/check_ntt.py --mode intt --in data/ntt_output_single.txt  --out data/intt_output_single.txt
//
//   Tin hieu `stage` (radix ASCII) cho biet dang o buoc nao; name_top / name_bf cho biet state.
//   Duong dan thu muc data: sua dong `define DATA_DIR ben duoi (dung dau / va co / o cuoi), vi du
//       `define DATA_DIR "D:/Oanh/DATN/NTT_BaseLine/2710/ntt_ipcore/data/"
//==============================================================================
`ifndef DATA_DIR
`define DATA_DIR "D:/ntt_ipcore_mlkem/data/"
`endif
module tb_all;
    localparam [63:0] Q   = 64'd3329;
    localparam [11:0] F12 = 12'd3303;
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    // ---- tin hieu tb <-> top ; 2 mang nho (mem_in, mem_out) nam NGOAI IP, trong testbench ----
    reg         start = 0, mode = 0, wr_en = 0;            // wr_en = ext_wr_en
    reg  [11:0] ext_data = 0;                               // ext_din  (doc tu mem_in)
    wire [7:0]  ext_addr;                                   // ext_addr  = cnt_data
    wire        busy, done, din_ready, dout_valid;
    wire [11:0] dout;                                       // ext_rdata
    wire [2:0]  st_top;  wire [3:0] st_bf;

    ntt_ip_v1_0 dut (
        .clk(clk), .rst_n(rst_n),
        .start(start), .mode(mode),
        .ext_wr_en(wr_en), .ext_din(ext_data), .ext_addr(ext_addr), .ext_ready(din_ready),
        .ext_rdata(dout), .ext_rvalid(dout_valid),
        .busy(busy), .done(done),
        .dbg_state_top(st_top), .dbg_state_bf(st_bf));

    integer errors = 0;
    integer seed   = 32'hC0DE;

    //---------------- mo hinh vang ----------------
    reg [11:0] mem_in [0:255];
    reg [11:0] mem_out[0:255];
    reg [11:0] gold   [0:255];

    // mang dau vao tra du lieu theo dia chi IP dua ra: ext_din = mem_in[ext_addr]
    always @(negedge clk) ext_data = mem_in[ext_addr];
    function [11:0] g_mul(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t * b; g_mul = t % Q; end endfunction
    function [11:0] g_add(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t + b; g_add = t % Q; end endfunction
    function [11:0] g_sub(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t + Q - b; g_sub = t % Q; end endfunction
    function [11:0] g_zeta(input [6:0] k);
        reg [6:0] rev; reg [63:0] r, bb; integer i;
        begin
            for (i = 0; i < 7; i = i + 1) rev[i] = k[6-i];
            r = 1; bb = 17;
            for (i = 0; i < 7; i = i + 1) begin
                if (rev[i]) r = (r * bb) % Q;
                bb = (bb * bb) % Q;
            end
            g_zeta = r;
        end
    endfunction
    task golden_ntt;                                   // FIPS 203 Algorithm 9
        integer m, len, start_, j; reg [11:0] z, t;
        begin
            m = 1; len = 128;
            while (len >= 2) begin
                start_ = 0;
                while (start_ < 256) begin
                    z = g_zeta(m); m = m + 1;
                    for (j = start_; j < start_ + len; j = j + 1) begin
                        t = g_mul(z, gold[j + len]);
                        gold[j + len] = g_sub(gold[j], t);
                        gold[j]       = g_add(gold[j], t);
                    end
                    start_ = start_ + 2 * len;
                end
                len = len / 2;
            end
        end
    endtask
    task golden_intt;                                  // FIPS 203 Algorithm 10 (co nhan 128^-1)
        integer m, len, start_, j; reg [11:0] z, t, u;
        begin
            m = 127; len = 2;
            while (len <= 128) begin
                start_ = 0;
                while (start_ < 256) begin
                    z = g_zeta(m); m = m - 1;
                    for (j = start_; j < start_ + len; j = j + 1) begin
                        t = gold[j]; u = gold[j + len];
                        gold[j]       = g_add(t, u);
                        gold[j + len] = g_mul(z, g_sub(u, t));
                    end
                    start_ = start_ + 2 * len;
                end
                len = len * 2;
            end
            for (j = 0; j < 256; j = j + 1) gold[j] = g_mul(F12, gold[j]);
        end
    endtask

    //---------------- monitor state ----------------
    function [87:0] top_name(input [2:0] s);
        case (s)
            3'd0: top_name = "IDLE";       3'd1: top_name = "LOAD_DATA";
            3'd2: top_name = "EX";         3'd3: top_name = "READ_DATA";
            3'd4: top_name = "FIN";        default: top_name = "???";
        endcase
    endfunction
    function [87:0] bf_name(input [3:0] s);
        case (s)
            4'd0: bf_name = "IDLE";        4'd1: bf_name = "READ";
            4'd2: bf_name = "EX";          4'd3: bf_name = "WR";
            4'd4: bf_name = "NEXT_BF";     4'd5: bf_name = "NEXT_GRP";
            4'd6: bf_name = "NEXT_STAGE";  4'd7: bf_name = "SCALE";
            4'd8: bf_name = "DONE";        default: bf_name = "???";
        endcase
    endfunction
    function top_legal(input [2:0] p, input [2:0] c);
        top_legal = (p == 0 && c == 1) || (p == 1 && c == 2) || (p == 2 && c == 3) ||
                    (p == 3 && c == 4) || (p == 4 && c == 0);
    endfunction
    function bf_legal(input [3:0] p, input [3:0] c);
        bf_legal = (p == 0 && c == 1) || (p == 1 && c == 2) || (p == 2 && c == 3) ||
                   (p == 3 && (c == 4 || c == 5 || c == 6 || c == 7 || c == 8)) ||
                   (p == 4 && c == 1) || (p == 5 && c == 1) || (p == 6 && c == 1) ||
                   (p == 7 && c == 8) || (p == 8 && c == 0);
    endfunction

    wire [87:0] name_top = top_name(st_top);       // radix ASCII trong waveform
    wire [87:0] name_bf  = bf_name(st_bf);

    integer cyc = 0;  always @(posedge clk) cyc <= cyc + 1;
    reg [2:0] p_top = 0;  reg [3:0] p_bf = 0;
    integer n_load, n_ex, n_read, n_fin, n_rd, n_exb, n_wr, n_nbf, n_ng, n_ns, n_sc, n_scw, n_done, trace, ex_cycles;
    task clear_cnt; begin n_load = 0; n_ex = 0; n_read = 0; n_fin = 0; n_rd = 0; n_exb = 0; n_wr = 0; n_nbf = 0; n_ng = 0;
                          n_ns = 0; n_sc = 0; n_scw = 0; n_done = 0; trace = 12; ex_cycles = 0; end endtask

    always @(posedge clk) if (rst_n) begin
        if (st_top !== p_top) begin
            $display("  [cyc %6d] FSM_TOPCORE   : %-10s -> %-10s (busy=%b done=%b)", cyc, top_name(p_top), top_name(st_top), busy, done);
            if (!top_legal(p_top, st_top)) begin errors = errors + 1; $display("  [FAIL] chuyen state Top khong hop le"); end
            case (st_top) 3'd1: n_load = n_load + 1; 3'd2: n_ex = n_ex + 1; 3'd3: n_read = n_read + 1; 3'd4: n_fin = n_fin + 1; endcase
            p_top <= st_top;
        end
        if (st_bf == 4'd2) ex_cycles = ex_cycles + 1;
        if (st_bf !== p_bf) begin
            if (!bf_legal(p_bf, st_bf)) begin errors = errors + 1; $display("  [FAIL] chuyen state BF sai: %0s -> %0s", bf_name(p_bf), bf_name(st_bf)); end
            if (p_bf == 4'd2 && st_bf == 4'd3 && ex_cycles != 8) begin errors = errors + 1; $display("  [FAIL] EX = %0d chu ky (ky vong 8: valid_in o chu ky dau, valid_out sau 7 chu ky)", ex_cycles); end
            if (st_bf != 4'd2) ex_cycles = 0;
            case (st_bf) 4'd1: n_rd = n_rd + 1; 4'd2: n_exb = n_exb + 1; 4'd3: n_wr = n_wr + 1; 4'd4: n_nbf = n_nbf + 1;
                         4'd5: n_ng = n_ng + 1; 4'd6: n_ns = n_ns + 1; 4'd7: n_sc = n_sc + 1; endcase
            if (trace > 0 || st_bf == 4'd5 || st_bf == 4'd6 || st_bf == 4'd7 || (st_bf == 4'd0 && p_bf != 4'd0)) begin
                $display("  [cyc %6d]   FSM_BUTTERFLY: %-10s -> %-10s len=%0d i=%0d start_r=%0d j_cnt=%0d stage_cnt=%0d",
                         cyc, bf_name(p_bf), bf_name(st_bf), dut.u_control.len, dut.u_control.i_cnt, dut.u_control.start_r, dut.u_control.j_cnt, dut.u_control.stage_cnt);
                if (trace > 0) trace = trace - 1;
            end
            p_bf <= st_bf;
        end
        if (st_bf == 4'd7 && dut.u_control.wr_en_b) n_scw = n_scw + 1;
        if (dut.u_control.calc_done) begin n_done = n_done + 1; $display("  [cyc %6d]   >>> calc_done = 1 (DONE: Butterfly -> FSM_TOPCORE)", cyc); end
    end

    //==========================================================================
    // Cac khoi so hoc DOC LAP (de xem done cua tung phep truoc khi vao he thong)
    //==========================================================================
    reg [8*24-1:0] stage;                           // buoc dang chay (radix ASCII)

    reg         add_v = 0, sub_v = 0, mul_v = 0;
    reg  [11:0] add_a = 0, add_b = 0, sub_a = 0, sub_b = 0, mul_a = 0, mul_b = 0;
    wire [11:0] add_r, sub_r, mul_r;
    wire        add_done, sub_done, mul_done;
    mod_add u_add (.clk(clk), .rst_n(rst_n), .valid_in(add_v), .a(add_a), .b(add_b), .result(add_r), .done(add_done));
    mod_sub u_sub (.clk(clk), .rst_n(rst_n), .valid_in(sub_v), .a(sub_a), .b(sub_b), .result(sub_r), .done(sub_done));
    mod_mul u_mul (.clk(clk), .rst_n(rst_n), .valid_in(mul_v), .a(mul_a), .b(mul_b), .result(mul_r), .done(mul_done));

    reg         bfu_v = 0, bfu_gs = 0, bfu_sc = 0;
    reg  [11:0] bfu_a = 0, bfu_b = 0, bfu_z = 0;
    wire [11:0] bfu_o0, bfu_o1;
    wire        bfu_ov;
    butterfly u_bf_unit (.clk(clk), .rst_n(rst_n), .valid_in(bfu_v), .mode(bfu_gs), .scale(bfu_sc),
                         .a(bfu_a), .b(bfu_b), .z(bfu_z), .y0(bfu_o0), .y1(bfu_o1), .valid_out(bfu_ov));

    reg [11:0] r_add, r_sub, r_mul, r_o0, r_o1;

    task run_add(input [11:0] x, input [11:0] y);
        integer c;
        begin
            @(negedge clk); add_a = x; add_b = y; add_v = 1;
            @(negedge clk); add_v = 0; c = 1;
            while (!add_done) begin @(negedge clk); c = c + 1; end
            r_add = add_r;
            if (r_add !== g_add(x,y) || c != 1) begin errors = errors + 1; $display("  [FAIL] ADD %0d + %0d = %0d (exp %0d) lat=%0d", x, y, r_add, g_add(x,y), c); end
            else $display("  [ OK ] ADD %0d + %0d = %0d   -> add_done sau %0d chu ky", x, y, r_add, c);
        end
    endtask
    task run_sub(input [11:0] x, input [11:0] y);
        integer c;
        begin
            @(negedge clk); sub_a = x; sub_b = y; sub_v = 1;
            @(negedge clk); sub_v = 0; c = 1;
            while (!sub_done) begin @(negedge clk); c = c + 1; end
            r_sub = sub_r;
            if (r_sub !== g_sub(x,y) || c != 1) begin errors = errors + 1; $display("  [FAIL] SUB %0d - %0d = %0d (exp %0d) lat=%0d", x, y, r_sub, g_sub(x,y), c); end
            else $display("  [ OK ] SUB %0d - %0d = %0d   -> sub_done sau %0d chu ky", x, y, r_sub, c);
        end
    endtask
    task run_mul(input [11:0] x, input [11:0] y);
        integer c;
        begin
            @(negedge clk); mul_a = x; mul_b = y; mul_v = 1;
            @(negedge clk); mul_v = 0; c = 1;
            while (!mul_done) begin @(negedge clk); c = c + 1; end
            r_mul = mul_r;
            if (r_mul !== g_mul(x,y) || c != 5) begin errors = errors + 1; $display("  [FAIL] MUL %0d * %0d = %0d (exp %0d) lat=%0d", x, y, r_mul, g_mul(x,y), c); end
            else $display("  [ OK ] MUL %0d * %0d = %0d   -> mul_done sau %0d chu ky", x, y, r_mul, c);
        end
    endtask
    // mode: 0 = CT (NTT), 1 = GS (INTT), 2 = SCALE (nhan 128^-1)
    task run_bfu(input [1:0] mode, input [11:0] xa, input [11:0] xb, input [11:0] xz);
        integer c; reg [11:0] e0, e1, t, zn;
        begin
            zn = (xz == 0) ? 12'd0 : (Q - xz);
            case (mode)
                2'd0: begin t = g_mul(xz, xb); e0 = g_add(xa, t); e1 = g_sub(xa, t); end
                2'd1: begin e0 = g_add(xa, xb); e1 = g_mul(g_sub(xa, xb), zn); end
                default: begin e0 = xa; e1 = g_mul(xa, F12); end
            endcase
            @(negedge clk); bfu_a = xa; bfu_b = xb; bfu_z = xz; bfu_gs = (mode != 0); bfu_sc = (mode == 2); bfu_v = 1;
            @(negedge clk); bfu_v = 0; c = 1;
            while (!bfu_ov) begin
                @(negedge clk); c = c + 1;
                if (u_bf_unit.add_done) $display("     [chu ky %0d] add_done: mod_add/mod_sub xong (CT: ket qua cuoi | GS: truoc nhan)", c);
                if (u_bf_unit.mul_done) $display("     [chu ky %0d] mul_done: u_mod_mul xong (t=%0d)", c, u_bf_unit.mul_t);
            end
            r_o0 = bfu_o0; r_o1 = bfu_o1;
            if (c != 7 || r_o1 !== e1 || (mode != 2 && r_o0 !== e0)) begin
                errors = errors + 1; $display("  [FAIL] BUTTERFLY mode=%0d: o0=%0d(exp %0d) o1=%0d(exp %0d) lat=%0d", mode, r_o0, e0, r_o1, e1, c); end
            else $display("  [ OK ] BUTTERFLY %-5s a=%0d b=%0d z=%0d -> o0=%0d o1=%0d  (valid_out sau %0d chu ky)",
                          (mode==0) ? "CT" : (mode==1) ? "GS" : "SCALE", xa, xb, xz, r_o0, r_o1, c);
        end
    endtask

    //---------------- bo nho dau ra: luu moi he so khi dout_valid : mem_out[ext_addr] = ext_rdata ----------------
    integer out_idx = 0;
    always @(posedge clk) if (dout_valid && out_idx < 256) begin
        mem_out[ext_addr] = dout;                  // mang ket qua: mem_out[ext_addr] = ext_rdata
        out_idx = out_idx + 1;
    end

    //---------------- 1 lan chay ----------------
    integer i, guard, mism, t_load, t_calc0, t_calc1;
    task run(input m);
        begin
            clear_cnt; out_idx = 0;
            // (1) start + mode
            @(negedge clk); mode = m; start = 1;
            @(negedge clk); start = 0;
            guard = 0;
            while (!din_ready && guard < 100) begin @(negedge clk); guard = guard + 1; end
            if (!din_ready) begin errors = errors + 1; $display("  [FAIL] khong len din_ready (FSM_TOPCORE khong vao LOAD_DATA)"); end
            $display("  --- start xong, FSM_TOPCORE = LOAD_DATA, din_ready = %b", din_ready);
            // (2) ghi 256 he so bang write_enable, moi chu ky 1 he so
            $display("  --- ghi 256 he so: ext_wr_en = 1, IP dua ext_addr = 0..255, mang vao tra ext_din = mem_in[ext_addr]");
            t_load = cyc;
            @(negedge clk); wr_en = 1;                     // ext_wr_en = 1 : IP tu dua ext_addr = 0..255
            guard = 0;
            while (din_ready && guard < 1000) begin @(negedge clk); guard = guard + 1; end
            wr_en = 0;                                     // du 256 he so -> ext_ready = 0
            $display("  --- da ghi du 256 he so vao RAM (mat %0d chu ky) -> FSM tu chay %0s", cyc - t_load, m ? "INTT" : "NTT");
            // (3) cho FSM tinh va doc ra
            guard = 0;
            while (!done && guard < 400000) begin @(negedge clk); guard = guard + 1; end
            if (!done) begin errors = errors + 1; $display("  [FAIL] timeout cho done"); end
            repeat (4) @(negedge clk);
            if (out_idx != 256) begin errors = errors + 1; $display("  [FAIL] chi doc duoc %0d/256 he so", out_idx); end
            if (busy || st_top !== 3'd0 || st_bf !== 4'd0) begin errors = errors + 1; $display("  [FAIL] cuoi phai busy=0 va ca 2 FSM ve IDLE"); end

            // (4) so voi mo hinh vang
            mism = 0;
            for (i = 0; i < 256; i = i + 1) if (mem_out[i] !== gold[i]) begin
                mism = mism + 1; if (mism <= 5) $display("  [FAIL] [%0d] DUT=%0d GOLD=%0d", i, mem_out[i], gold[i]); end
            if (mism == 0) $display("  [ OK ] 256/256 he so khop mo hinh vang (mem_out[0]=%0d mem_out[255]=%0d)", mem_out[0], mem_out[255]);
            else begin errors = errors + 1; $display("  [FAIL] %0d/256 he so sai", mism); end
            $display("  --- Dem: Top[LOAD_DATA=%0d EX=%0d READ_DATA=%0d FIN=%0d] BF[READ=%0d EX=%0d WR=%0d NEXT_BF=%0d NEXT_GRP=%0d NEXT_STAGE=%0d SCALE=%0d ghi_scale=%0d calc_done=%0d]",
                     n_load, n_ex, n_read, n_fin, n_rd, n_exb, n_wr, n_nbf, n_ng, n_ns, n_sc, n_scw, n_done);
            if (n_load != 1 || n_ex != 1 || n_read != 1 || n_fin != 1 || n_done != 1) begin errors = errors + 1; $display("  [FAIL] Top phai qua moi state 1 lan, calc_done 1 xung"); end
            if (n_wr != 896 || n_rd != 896 || n_exb != 896 || n_nbf != 769 || n_ng != 120 || n_ns != 6) begin errors = errors + 1; $display("  [FAIL] ky vong 896 butterfly (7 tang x 128), NEXT_BF=769, NEXT_GRP=120, NEXT_STAGE=6"); end
            if (m == 0 && (n_sc != 0 || n_scw != 0))   begin errors = errors + 1; $display("  [FAIL] NTT khong duoc SCALE"); end
            if (m == 1 && (n_sc != 1 || n_scw != 256)) begin errors = errors + 1; $display("  [FAIL] INTT phai SCALE 256 he so"); end
        end
    endtask

    reg [11:0] in_single  [0:255];
    reg [11:0] exp_single [0:255];
    reg [11:0] ntt_out_keep [0:255];
    reg [8*100-1:0] fname;
    integer n, fd, nx, mism_file;
    initial begin
        clear_cnt; stage = "RESET";
        // ---- doc file he so dau vao va file dap an ----
        fname = {`DATA_DIR, "ntt_input_single.txt"};    $readmemh(fname, in_single);
        fname = {`DATA_DIR, "ntt_expected_single.txt"}; $readmemh(fname, exp_single);
        nx = 0;
        for (n = 0; n < 256; n = n + 1) if ((^in_single[n]) === 1'bx || (^exp_single[n]) === 1'bx) nx = nx + 1;
        if (nx != 0) begin
            errors = errors + 1;
            $display("[FAIL] doc file that bai (%0d o X) - kiem tra DATA_DIR = %0s", nx, `DATA_DIR);
            $finish;
        end
        $display("Da doc file: ntt_input_single[0]=%03X ntt_expected_single[0]=%03X", in_single[0], exp_single[0]);

        repeat (5) @(negedge clk); rst_n = 1; repeat (3) @(negedge clk);
        $display("\n#####  RESET xong: FSM_TOPCORE = IDLE, FSM_Butterfly = IDLE  #####");
        if (st_top !== 3'd0 || st_bf !== 4'd0 || busy !== 1'b0) begin errors = errors + 1; $display("[FAIL] trang thai sau reset"); end

        //------------------------------------------------------------------
        stage = "S1_ADD";
        $display("\n########## S1: PHEP CONG (mod_add) ##########");
        run_add(12'd2000, 12'd3000);
        $display("     >> add_done = 1 : chuyen ket qua r_add = %0d sang phep TRU", r_add);

        stage = "S2_SUB";
        $display("\n########## S2: PHEP TRU (mod_sub) ##########");
        run_sub(r_add, 12'd123);
        $display("     >> sub_done = 1 : chuyen ket qua r_sub = %0d sang phep NHAN", r_sub);

        stage = "S3_MUL";
        $display("\n########## S3: PHEP NHAN MODULO BARRETT (mod_mul, 5 tang) ##########");
        run_mul(r_sub, 12'd987);
        $display("     >> mul_done = 1 : r_mul = %0d -> lam he so xoay z cho BUTTERFLY", r_mul);

        //------------------------------------------------------------------
        stage = "S4_BUTTERFLY_CT";
        $display("\n########## S4: KHOI BUTTERFLY (1 add + 1 sub + 1 mul dung chung), dau vao = ket qua S1-S3 ##########");
        run_bfu(2'd0, r_add, r_sub, r_mul);
        $display("     >> valid_out = 1 : (o0,o1) = (%0d,%0d) di tiep vao GS", r_o0, r_o1);
        stage = "S4_BUTTERFLY_GS";
        run_bfu(2'd1, r_o0, r_o1, r_mul);
        stage = "S4_BUTTERFLY_SCALE";
        run_bfu(2'd2, r_o1, 12'd0, 12'd0);

        //------------------------------------------------------------------
        stage = "S5_NTT_FILE";
        $display("\n########## S5: NTT TOAN IP - he so dau vao doc tu file ntt_input_single.txt ##########");
        for (n = 0; n < 256; n = n + 1) begin mem_in[n] = in_single[n]; gold[n] = in_single[n]; end
        golden_ntt;                                                  // mo hinh vang trong tb
        mism_file = 0;
        for (n = 0; n < 256; n = n + 1) if (gold[n] !== exp_single[n]) mism_file = mism_file + 1;
        if (mism_file == 0) $display("  [ OK ] mo hinh vang trong tb KHOP file ntt_expected_single.txt (256/256)");
        else begin errors = errors + 1; $display("  [FAIL] mo hinh vang trong tb lech file expected: %0d he so", mism_file); end
        for (n = 0; n < 256; n = n + 1) gold[n] = exp_single[n];     // dung CHINH file lam dap an
        run(1'b0);
        for (n = 0; n < 256; n = n + 1) ntt_out_keep[n] = mem_out[n];
        fname = {`DATA_DIR, "ntt_output_single.txt"};
        fd = $fopen(fname, "w");
        if (fd == 0) begin errors = errors + 1; $display("[FAIL] khong mo duoc file ra: %0s", fname); end
        else begin
            for (n = 0; n < 256; n = n + 1) $fdisplay(fd, "%03X", mem_out[n]);
            $fclose(fd);
            $display("  --- Da ghi ket qua NTT cua IP ra file: %0s", fname);
        end

        //------------------------------------------------------------------
        stage = "S6_INTT_FILE";
        $display("\n########## S6: INTT cua ket qua S5 -> phai ra lai he so dau vao (khep kin) ##########");
        for (n = 0; n < 256; n = n + 1) begin mem_in[n] = ntt_out_keep[n]; gold[n] = in_single[n]; end
        run(1'b1);
        fname = {`DATA_DIR, "intt_output_single.txt"};
        fd = $fopen(fname, "w");
        if (fd == 0) begin errors = errors + 1; $display("[FAIL] khong mo duoc file ra: %0s", fname); end
        else begin
            for (n = 0; n < 256; n = n + 1) $fdisplay(fd, "%03X", mem_out[n]);
            $fclose(fd);
            $display("  --- Da ghi ket qua INTT cua IP ra file: %0s", fname);
        end

        stage = "DONE";
        $display("\n==================================================");
        if (errors == 0) $display(" tb_all : *** ALL STAGES PASSED (S1..S6) ***");
        else             $display(" tb_all : FAIL (%0d loi)", errors);
        $display(" Kiem bang phan mem:");
        $display("   python tools/check_ntt.py --mode ntt  --in data/ntt_input_single.txt --out data/ntt_output_single.txt");
        $display("   python tools/check_ntt.py --mode intt --in data/ntt_output_single.txt --out data/intt_output_single.txt");
        $display("==================================================");
        $finish;
    end
    initial begin #400000000; $display("[TIMEOUT] tb_all"); $finish; end
endmodule
