//==============================================================================
// rom_zeta : ROM he so xoay 128 x 12 bit (IP blk_mem_gen_zeta, nap ip/zeta.coe)
//   zeta[i] = 17^BitRev7(i) mod 3329  (FIPS 203 Appendix A)
//   Latency 1: rom_en=1 o chu ky t -> zeta, zeta_valid o chu ky t+1 ; giu zeta khi rom_en=0
//==============================================================================
module rom_zeta (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        rom_en,
    input  wire [6:0]  zeta_addr,     // = i
    output wire [11:0] zeta,
    output reg         zeta_valid
);
    blk_mem_gen_1 u_bram (
        .clka (clk),
        .ena  (rom_en),
        .addra(zeta_addr),
        .douta(zeta));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) zeta_valid <= 1'b0;
        else        zeta_valid <= rom_en;
    end
endmodule
