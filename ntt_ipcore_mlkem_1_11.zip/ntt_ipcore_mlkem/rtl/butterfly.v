//==============================================================================
// butterfly : KHOI BUTTERFLY CT/GS cho ML-KEM (q = 3329) - 1 mod_add, 1 mod_sub, 1 mod_mul DUNG CHUNG
//   u_mod_add : mod_add   (a + x)
//   u_mod_sub : mod_sub   (a - x)
//   u_mod_mul : mod_mul   (Barrett, 5 tang)
//
//   mode = 0 (NTT , CT) : t = z*b          -> y0 = a + t ; y1 = a - t        (FIPS 203 Alg. 9)
//   mode = 1 (INTT, GS) : y0 = a + b ; y1 = (a - b) * (-z) = z * (b - a)     (FIPS 203 Alg. 10)
//   scale = 1 (di cung GS): y1 = a * F , F = 128^-1 mod 3329 = 3303          (buoc cuoi INTT)
//
//   Cung 1 cap add/sub duoc dung o 2 vi tri pipeline khac nhau tuy che do (mux theo mode):
//        CT : as_valid = mul_done ; as_a = a tre 5 chu ky ; as_b = t
//        GS : as_valid = valid_in ; as_a = a              ; as_b = b      ; mul_x = a-b (tre 1 chu ky)
//   => mode phai GIU NGUYEN trong suot 1 lan chay (FSM Top chot mode o IDLE).
//
//   Latency valid_in -> valid_out = 7 chu ky, throughput 1/chu ky.
//   y0/y1 duoc giu den lan valid_out ke tiep.
//==============================================================================
module butterfly #(
    parameter [11:0] Q = 12'd3329,
    parameter [11:0] F = 12'd3303
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        valid_in,
    input  wire        mode,                // 0: CT/NTT   1: GS/INTT
    input  wire        scale,               // 1: nhan he so F (INTT)
    input  wire [11:0] a,
    input  wire [11:0] b,
    input  wire [11:0] z,                   // zeta (chua dao dau)
    output wire [11:0] y0,
    output wire [11:0] y1,
    output wire        valid_out
);
    // ---------------- chuan bi toan hang ----------------
    wire [11:0] b_eff = scale ? 12'd0 : b;
    wire [11:0] z_neg = (z == 12'd0) ? 12'd0 : (Q - z);
    wire [11:0] z_eff = scale ? F : (mode ? z_neg : z);

    reg [11:0] z_1;                                   // GS: z tre 1 chu ky cho khop (a-b)
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)         z_1 <= 12'd0;
        else if (valid_in)  z_1 <= z_eff;
    end

    // tri hoan 5 chu ky cho a (CT) va (a+b) (GS)
    reg [11:0] a_d  [1:5];
    reg [11:0] pa_d [1:5];
    wire [11:0] add_r, sub_r, mul_t;
    wire        add_done, sub_done, mul_done;
    integer     kk;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (kk = 1; kk <= 5; kk = kk + 1) begin a_d[kk] <= 0; pa_d[kk] <= 0; end
        end else begin
            a_d[1]  <= a;
            pa_d[1] <= add_r;
            for (kk = 2; kk <= 5; kk = kk + 1) begin a_d[kk] <= a_d[kk-1]; pa_d[kk] <= pa_d[kk-1]; end
        end
    end

    // ---------------- 1 mod_add + 1 mod_sub dung chung ----------------
    wire        as_valid = mode ? valid_in : mul_done;
    wire [11:0] as_a     = mode ? a        : a_d[5];
    wire [11:0] as_b     = mode ? b_eff    : mul_t;

    mod_add #(.Q(Q)) u_mod_add (.clk(clk), .rst_n(rst_n), .valid_in(as_valid),
        .a(as_a), .b(as_b), .result(add_r), .done(add_done));
    mod_sub #(.Q(Q)) u_mod_sub (.clk(clk), .rst_n(rst_n), .valid_in(as_valid),
        .a(as_a), .b(as_b), .result(sub_r), .done(sub_done));

    // ---------------- 1 mod_mul dung chung ----------------
    wire        mul_valid = mode ? add_done : valid_in;
    wire [11:0] mul_x     = mode ? sub_r    : b_eff;          // GS: a-b ; CT: b
    wire [11:0] mul_y     = mode ? z_1      : z_eff;          // GS: -z (hoac F) ; CT: z

    mod_mul #(.Q(Q)) u_mod_mul (.clk(clk), .rst_n(rst_n), .valid_in(mul_valid),
        .a(mul_x), .b(mul_y), .result(mul_t), .done(mul_done));

    // ---------------- ngo ra (thanh ghi giu ket qua) ----------------
    wire        fin_valid = mode ? mul_done : add_done;
    wire [11:0] fin_y0    = mode ? pa_d[5]  : add_r;          // GS: a+b ; CT: a+t
    wire [11:0] fin_y1    = mode ? mul_t    : sub_r;          // GS: (a-b)*(-z) ; CT: a-t

    reg [11:0] y0_r, y1_r;
    reg        v_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin y0_r <= 0; y1_r <= 0; v_r <= 0; end
        else begin
            v_r <= fin_valid;
            if (fin_valid) begin y0_r <= fin_y0; y1_r <= fin_y1; end
        end
    end

    assign y0        = y0_r;
    assign y1        = y1_r;
    assign valid_out = v_r;
endmodule
