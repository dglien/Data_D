//==============================================================================
// mod_mul : result = (a * b) mod q     -- Barrett, pipeline 5 tang (giu nguyen cau truc ML-DSA)
//   ML-KEM: q = 3329 (12 bit), k = 24, MU = floor(2^24 / q) = 5039
//   S1: p  = a*b                 (24 bit)
//   S2: m  = p*MU                (37 bit)
//   S3: tq = (m >> 24) * q
//   S4: r  = p - tq              (0 <= r < 2q, da kiem vet can 3329x3329 cap)
//   S5: tru q toi da 2 lan -> ket qua
// Latency = 5 chu ky, throughput = 1 phep nhan / chu ky.
// done = 1 chu ky khi ket qua hop le; ket qua giu nguyen den lan tiep theo.
//==============================================================================
module mod_mul #(
    parameter [11:0] Q  = 12'd3329,
    parameter [12:0] MU = 13'd5039
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        valid_in,
    input  wire [11:0] a,
    input  wire [11:0] b,
    output reg  [11:0] result,
    output reg         done
);
    // ---- S1
    reg [23:0] p1;  reg v1;
    // ---- S2
    reg [36:0] m2;  reg [23:0] p2;  reg v2;
    // ---- S3
    reg [23:0] tq3; reg [23:0] p3;  reg v3;
    // ---- S4
    reg [13:0] r4;  reg v4;

    wire [13:0] q1x = {2'b0, Q};
    wire [13:0] q2x = {1'b0, Q, 1'b0};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            p1 <= 0; v1 <= 0;
            m2 <= 0; p2 <= 0; v2 <= 0;
            tq3 <= 0; p3 <= 0; v3 <= 0;
            r4 <= 0; v4 <= 0;
            result <= 0; done <= 0;
        end else begin
            // S1
            v1 <= valid_in;
            if (valid_in) p1 <= a * b;
            // S2
            v2 <= v1;
            if (v1) begin m2 <= p1 * MU; p2 <= p1; end
            // S3
            v3 <= v2;
            if (v2) begin tq3 <= m2[36:24] * Q; p3 <= p2; end
            // S4
            v4 <= v3;
            if (v3) r4 <= p3[13:0] - tq3[13:0];   // r < 2q < 2^14 nen cat 14 bit la du
            // S5
            done <= v4;
            if (v4) begin
                if      (r4 >= q2x) result <= r4 - q2x;
                else if (r4 >= q1x) result <= r4 - q1x;
                else                result <= r4[11:0];
            end
        end
    end
endmodule
