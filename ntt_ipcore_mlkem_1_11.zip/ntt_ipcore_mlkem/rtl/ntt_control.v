//==============================================================================
// ntt_control : CONTROL PATH (FSM_TOPCORE + FSM_BUTTERFLY) + COUNTER, ML-KEM (q = 3329)
//
//  FSM_TOPCORE   : IDLE -> LOAD_DATA -> EX -> READ_DATA -> FIN -> IDLE            (so do 2)
//  FSM_BUTTERFLY : IDLE -> READ -> EX -> WR -+-> NEXT_BF    -> READ              (so do 3)
//                                            +-> NEXT_GRP   -> READ
//                                            +-> NEXT_STAGE -> READ
//                                            +-> (SCALE ->) DONE -> IDLE
//
//  Counter (so do 4) : cnt_data 0..256 | j_cnt | start_r (+= 2*len) | len (/2 | x2) | i (zeta_addr)
//                      stage_cnt 1..7 | scale_cnt (chi dung cho buoc SCALE cua INTT)
//
//  NTT : len = 128 -> 2 (7 tang), i = 1   tang dan      (FIPS 203 Alg. 9)
//  INTT: len = 2 -> 128 (7 tang), i = 127 giam dan      (FIPS 203 Alg. 10)
//        + buoc SCALE nhan 128^-1 = 3303 (tham so INTT_SCALE = 1). Dat INTT_SCALE = 0
//          de FSM_BUTTERFLY dung y het so do 3 (WR -> DONE, khong co SCALE).
//
//  sel_proc = (state_top == EX) : 0 -> FSM Top dieu khien RAM, 1 -> Process A / Process B
//==============================================================================
module ntt_control #(
    parameter INTT_SCALE = 1
)(
    input  wire        clk,
    input  wire        rst_n,
    // ---- phia ben ngoai ----
    input  wire        start,
    input  wire        mode,                // 0 NTT, 1 INTT
    input  wire        ext_wr_en,           // ghi ext_din vao RAM[cnt_data] khi o LOAD_DATA
    output wire        busy,
    output wire        done,
    output wire        ext_ready,           // dang o LOAD_DATA, san sang nhan
    output wire        ext_rvalid,          // ext_rdata hop le (READ_DATA)
    // ---- RAM A ----
    output wire        sel_proc,
    output wire        ram_we,
    output wire        ram_re,
    output wire [7:0]  ext_addr,            // = cnt_data
    output reg         wr_en_a,
    output reg         rd_en_a,
    output reg         wr_en_b,
    output reg         rd_en_b,
    output wire [7:0]  addr_a,              // j
    output wire [7:0]  addr_b,              // j + len  (| scale_cnt khi SCALE)
    input  wire        valid_a,             // rdata_a hop le (RAM tra tre 1 chu ky)
    // ---- ROM Zeta ----
    output reg         rom_en,
    output wire [6:0]  zeta_addr,           // = i
    // ---- Butterfly ----
    output wire        valid_in,
    output wire        mode_bf,             // mode chot o IDLE
    output wire        scale,
    input  wire        valid_out,
    // ---- debug ----
    output wire [2:0]  state_top,
    output wire [3:0]  state_bf
);
    //==========================================================================
    //  FSM_TOPCORE
    //==========================================================================
    localparam [2:0] T_IDLE = 3'd0, T_LOAD_DATA = 3'd1, T_EX = 3'd2,
                     T_READ_DATA = 3'd3, T_FIN = 3'd4;

    reg  [2:0] st_top, nst_top;
    reg        mode_r;                     // mode <= ext mode (chot o IDLE)
    reg        done_r;
    reg        dout_vld;                   // da co 1 he so cho ben ngoai lay
    wire       calc_done;                  // FSM_BUTTERFLY -> FSM_TOPCORE (trang thai DONE)

    reg  [8:0] cnt_data;                   // counter data 0..256
    reg        cnt_data_clr, load_en;      // load_en: cnt_data + 1
    reg        top_we, top_re;
    wire       rd_done = cnt_data[8];      // cnt_data == 256

    assign state_top  = st_top;
    assign sel_proc   = (st_top == T_EX);
    assign busy       = (st_top == T_LOAD_DATA) | (st_top == T_EX) | (st_top == T_READ_DATA);
    assign done       = done_r;
    assign ext_ready  = (st_top == T_LOAD_DATA) & ~rd_done;
    assign ext_rvalid = dout_vld;
    assign ram_we     = top_we;
    assign ram_re     = top_re;
    assign ext_addr   = cnt_data[7:0];                   // addr = cnt_data
    assign mode_bf    = mode_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)             cnt_data <= 9'd0;
        else if (cnt_data_clr)  cnt_data <= 9'd0;
        else if (load_en)       cnt_data <= cnt_data + 9'd1;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st_top <= T_IDLE; mode_r <= 1'b0; done_r <= 1'b0; dout_vld <= 1'b0;
        end else begin
            st_top <= nst_top;
            if (st_top == T_IDLE) mode_r <= mode;                   // mode <= ext mode
            if (st_top == T_FIN)                            done_r <= 1'b1;
            else if (st_top == T_IDLE && start)             done_r <= 1'b0;
            if (st_top == T_READ_DATA) begin
                if (valid_a)                                dout_vld <= 1'b1;
                else if (dout_vld)                          dout_vld <= 1'b0;
            end else                                        dout_vld <= 1'b0;
        end
    end

    always @(*) begin
        nst_top      = st_top;
        cnt_data_clr = 1'b0;
        load_en      = 1'b0;
        top_we       = 1'b0;
        top_re       = 1'b0;
        case (st_top)
            T_IDLE: begin                                           // busy=0, done=0
                cnt_data_clr = 1'b1;
                if (start) nst_top = T_LOAD_DATA;
            end
            T_LOAD_DATA: begin                                      // nap 256 he so
                top_we  = (~rd_done) & ext_wr_en;                   // ram_we = (cnt_data < 256)
                load_en = top_we;
                if (rd_done) nst_top = T_EX;                        // cnt = 256
            end
            T_EX: begin                                             // RAM do Process A/B dieu khien
                cnt_data_clr = 1'b1;
                if (calc_done) nst_top = T_READ_DATA;
            end
            T_READ_DATA: begin                                      // doc 256 he so (co bat tay)
                top_re  = (~rd_done) & ~valid_a & ~dout_vld;        // ram_re : FSM chi gui dia chi
                load_en = dout_vld;                                 // lay xong 1 he so -> dia chi ke
                if (rd_done) nst_top = T_FIN;
            end
            T_FIN: begin                                            // busy=0, done=1
                if (!start) nst_top = T_IDLE;
            end
            default: nst_top = T_IDLE;
        endcase
    end

    //==========================================================================
    //  FSM_BUTTERFLY + COUNTER (j_cnt, start_r, len, i, stage_cnt)
    //==========================================================================
    localparam [3:0] B_IDLE = 4'd0, B_READ = 4'd1, B_EX = 4'd2, B_WR = 4'd3,
                     B_NEXT_BF = 4'd4, B_NEXT_GRP = 4'd5, B_NEXT_STAGE = 4'd6,
                     B_SCALE = 4'd7, B_DONE = 4'd8;

    reg [3:0] st_bf, nst_bf;
    assign state_bf  = st_bf;
    assign scale     = (st_bf == B_SCALE);
    assign calc_done = (st_bf == B_DONE);

    wire scale_en = mode_r & (INTT_SCALE != 0);

    // ---- tin hieu giua FSM va counter (so do 4) ----
    reg        cnt_clr;                    // IDLE: nap gia tri khoi tao
    reg        j_clr, j_en;
    reg        start_clr, start_ld;
    reg        i_en, upd_len, stage_en, k_en;

    reg [8:0]  j_cnt;                      // vi tri trong nhom (0..len-1)
    reg [8:0]  start_r;                    // bat dau nhom
    reg [8:0]  len;                        // khoang cach
    reg [7:0]  i_cnt;                      // chi so zeta
    reg [3:0]  stage_cnt;                  // 1..7
    reg [8:0]  scale_cnt;                  // dem ghi SCALE 0..256

    wire [8:0] nxt_start = start_r + {len[7:0], 1'b0};          // start_r + 2*len
    wire       j_end     = ((j_cnt + 9'd1) >= len);             // j_cnt + 1 >= len : butterfly cuoi cua nhom
    wire       grp_end   = nxt_start[8];                        // nxt_start >= 256 : nhom cuoi cua tang
    wire       last_stg  = (stage_cnt >= 4'd7);                 // tang thu 7
    wire       k_end     = scale_cnt[8];
    wire       j_sc_end  = j_cnt[8];                            // da phat du 256 lenh doc (SCALE)

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            j_cnt <= 9'd0; start_r <= 9'd0; len <= 9'd0; i_cnt <= 8'd0; stage_cnt <= 4'd0; scale_cnt <= 9'd0;
        end else begin
            // j_cnt : clr -> 0 ; en -> +1
            if (j_clr | cnt_clr)            j_cnt <= 9'd0;
            else if (j_en)                  j_cnt <= j_cnt + 9'd1;
            // start_r : clr -> 0 ; ld -> nxt_start
            if (start_clr | cnt_clr)        start_r <= 9'd0;
            else if (start_ld)              start_r <= nxt_start;
            // len : NTT 128 (/2) ; INTT 2 (x2)
            if (cnt_clr)                    len <= mode_r ? 9'd2 : 9'd128;
            else if (upd_len)               len <= mode_r ? {len[7:0], 1'b0} : {1'b0, len[8:1]};
            // i : NTT 1 (+1) ; INTT 127 (-1)
            if (cnt_clr)                    i_cnt <= mode_r ? 8'd127 : 8'd1;
            else if (i_en)                  i_cnt <= mode_r ? (i_cnt - 8'd1) : (i_cnt + 8'd1);
            // stage_cnt : 1 -> 7
            if (cnt_clr)                    stage_cnt <= 4'd1;
            else if (stage_en)              stage_cnt <= stage_cnt + 4'd1;
            // scale_cnt : 0..256
            if (cnt_clr)                    scale_cnt <= 9'd0;
            else if (k_en)                  scale_cnt <= scale_cnt + 9'd1;
        end
    end

    wire [8:0] j_abs = start_r + j_cnt;                         // j
    wire [8:0] sum_jl = j_abs + len;                            // j + len
    assign addr_a    = j_abs[7:0];                              // addr_a = j
    assign addr_b    = scale ? scale_cnt[7:0] : sum_jl[7:0];    // addr_b = j + len | k
    assign zeta_addr = i_cnt[6:0];                              // zeta_addr = i

    // valid_in: READ -> EX (cho 1 chu ky RAM/ROM) : xung o chu ky dau cua EX ; SCALE: theo valid_a
    reg rd_d;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) rd_d <= 1'b0;
        else        rd_d <= (st_bf == B_READ);
    end
    assign valid_in = rd_d | ((st_bf == B_SCALE) & valid_a);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) st_bf <= B_IDLE;
        else        st_bf <= nst_bf;
    end

    always @(*) begin
        nst_bf    = st_bf;
        cnt_clr   = 1'b0;
        j_clr     = 1'b0;  j_en = 1'b0;
        start_clr = 1'b0;  start_ld = 1'b0;
        i_en      = 1'b0;  upd_len = 1'b0;  stage_en = 1'b0;  k_en = 1'b0;
        rom_en    = 1'b0;
        wr_en_a   = 1'b0;  wr_en_b = 1'b0;
        rd_en_a   = 1'b0;  rd_en_b = 1'b0;

        case (st_bf)
            B_IDLE: begin                         // NTT: len=128,i=1 | INTT: len=2,i=127 ; start_r=0, j=0
                cnt_clr = 1'b1;
                if (st_top == T_LOAD_DATA && rd_done) nst_bf = B_READ;     // rd_done = 256
            end
            B_READ: begin                         // a = f[j], b = f[j+len], zeta = ROM[i]
                rd_en_a = 1'b1;
                rd_en_b = 1'b1;
                rom_en  = 1'b1;
                nst_bf  = B_EX;                   // cho 1 chu ky
            end
            B_EX: begin                           // valid_in = 1, mode, a,b,z -> y0,y1
                if (valid_out) nst_bf = B_WR;     // valid_out = 0 : o lai EX
            end
            B_WR: begin                           // wr_en_a/b <= valid_out ; y0 -> addr_a, y1 -> addr_b
                wr_en_a = 1'b1;
                wr_en_b = 1'b1;
                if (!j_end) begin                 // j_cnt < len
                    j_en   = 1'b1;
                    nst_bf = B_NEXT_BF;
                end else if (!grp_end) begin      // j_cnt >= len, nxt_start < 256
                    j_en   = 1'b1;
                    nst_bf = B_NEXT_GRP;
                end else if (!last_stg) begin     // j_cnt >= len, nxt_start >= 256, stage_cnt < 7
                    j_en   = 1'b1;
                    nst_bf = B_NEXT_STAGE;
                end else if (scale_en) begin      // (INTT) tang cuoi xong -> SCALE
                    j_clr     = 1'b1;
                    start_clr = 1'b1;
                    nst_bf    = B_SCALE;
                end else begin                    // stage_cnt >= 7
                    nst_bf = B_DONE;
                end
            end
            B_NEXT_BF: begin                      // addr_a = j, addr_b = j + len
                nst_bf = B_READ;
            end
            B_NEXT_GRP: begin                     // start_r = nxt_start, j_cnt = 0, i = i +/- 1
                start_ld = 1'b1;
                j_clr    = 1'b1;
                i_en     = 1'b1;
                nst_bf   = B_READ;
            end
            B_NEXT_STAGE: begin                   // len /2 | x2, start_r = 0, j_cnt = 0, i = i +/- 1, stage_cnt + 1
                upd_len   = 1'b1;
                start_clr = 1'b1;
                j_clr     = 1'b1;
                i_en      = 1'b1;
                stage_en  = 1'b1;
                nst_bf    = B_READ;
            end
            B_SCALE: begin                        // y1 = RAM[k] * 128^-1 : doc port A, ghi port B
                if (!j_sc_end) begin
                    rd_en_a = 1'b1;
                    j_en    = 1'b1;
                end
                if (valid_out) begin
                    wr_en_b = 1'b1;
                    k_en    = 1'b1;
                end
                if (k_end) nst_bf = B_DONE;
            end
            B_DONE: begin                         // bao calc_done cho FSM_TOPCORE
                nst_bf = B_IDLE;
            end
            default: nst_bf = B_IDLE;
        endcase
    end
endmodule
