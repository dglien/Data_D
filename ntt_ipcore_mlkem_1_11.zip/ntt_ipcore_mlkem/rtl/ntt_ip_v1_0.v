//==============================================================================
// ntt_ip_v1_0 : TOP NTT/INTT IP core cho ML-KEM (FIPS 203, q = 3329, 256 he so x 12 bit)
//
//   ntt_ip_v1_0
//    +- u_control   : ntt_control FSM_TOPCORE + FSM_BUTTERFLY + counter (j_cnt, start_r, len, i, stage_cnt)
//    +- u_ram_a     : ram_a       RAM A 256x12 true dual port (blk_mem_gen_ram) + MUX port A (sel_proc)
//    +- u_rom_zeta  : rom_zeta    ROM Zeta 128x12 (blk_mem_gen_zeta, ip/zeta.coe)
//    +- u_butterfly : butterfly   Butterfly CT/GS hop nhat (1 mod_add + 1 mod_sub + 1 mod_mul)
//
//   KHONG AXI. Giao tiep voi 2 mang nho ben ngoai (trong testbench):
//        mang vao  mem_in[0..255]  <--- ext_addr = cnt_data ---   IP
//                                  --- ext_din[11:0] ---------->  (ghi vao RAM A khi ext_wr_en = 1)
//        mang ra   mem_out[0..255] <--- ext_rdata[11:0] + ext_rvalid (dia chi = ext_addr)
//
//   Quy trinh:
//     1) start (1 xung), mode: 0 = NTT, 1 = INTT                -> IDLE -> LOAD_DATA
//     2) ext_ready = 1: ben ngoai dat ext_wr_en = 1 trong 256 chu ky; moi chu ky IP dua ext_addr = 0..255,
//        ben ngoai tra ext_din = mem_in[ext_addr], RAM[ext_addr] <= ext_din
//     3) du 256 he so -> EX (FSM_BUTTERFLY chay NTT hoac INTT, 7 tang x 128 butterfly)
//     4) READ_DATA: moi he so ra tren ext_rdata, ext_rvalid = 1 (1 chu ky), ext_addr = vi tri he so do
//     5) du 256 he so -> FIN, done = 1
//==============================================================================
module ntt_ip_v1_0 #(
    parameter INTT_SCALE = 1                // 1: INTT nhan 128^-1 (dung FIPS 203) ; 0: bo SCALE nhu so do 3
)(
    input  wire        clk,
    input  wire        rst_n,
    // ---------------- dieu khien ----------------
    input  wire        start,
    input  wire        mode,                // 0 = NTT (CT), 1 = INTT (GS)
    // ---------------- mang nho dau vao (ben ngoai) ----------------
    input  wire        ext_wr_en,           // write enable vao RAM A (LOAD_DATA)
    input  wire [11:0] ext_din,             // he so tu mang vao
    output wire [7:0]  ext_addr,            // = cnt_data
    output wire        ext_ready,           // dang o LOAD_DATA, san sang nhan
    // ---------------- mang nho ket qua (ben ngoai) ----------------
    output wire [11:0] ext_rdata,
    output wire        ext_rvalid,
    // ---------------- trang thai / debug ----------------
    output wire        busy,
    output wire        done,
    output wire [2:0]  dbg_state_top,       // 0 IDLE 1 LOAD_DATA 2 EX 3 READ_DATA 4 FIN
    output wire [3:0]  dbg_state_bf         // 0 IDLE 1 READ 2 EX 3 WR 4 NEXT_BF 5 NEXT_GRP 6 NEXT_STAGE 7 SCALE 8 DONE
);
    // ---- control <-> RAM A ----
    wire        sel_proc, ram_we, ram_re;
    wire        wr_en_a, rd_en_a, wr_en_b, rd_en_b;
    wire [7:0]  addr_a, addr_b;
    wire        valid_a, valid_b;
    wire [11:0] rdata_a, rdata_b;
    // ---- control <-> ROM Zeta ----
    wire        rom_en, zeta_valid;
    wire [6:0]  zeta_addr;
    wire [11:0] zeta;
    // ---- control <-> butterfly ----
    wire        valid_in, mode_bf, scale, valid_out;
    wire [11:0] y0, y1;

    assign ext_rdata = rdata_a;                               // ext_rdata = rdata_a

    ntt_control #(.INTT_SCALE(INTT_SCALE)) u_control (
        .clk(clk), .rst_n(rst_n),
        .start(start), .mode(mode), .ext_wr_en(ext_wr_en),
        .busy(busy), .done(done), .ext_ready(ext_ready), .ext_rvalid(ext_rvalid),
        .sel_proc(sel_proc), .ram_we(ram_we), .ram_re(ram_re), .ext_addr(ext_addr),
        .wr_en_a(wr_en_a), .rd_en_a(rd_en_a), .wr_en_b(wr_en_b), .rd_en_b(rd_en_b),
        .addr_a(addr_a), .addr_b(addr_b), .valid_a(valid_a),
        .rom_en(rom_en), .zeta_addr(zeta_addr),
        .valid_in(valid_in), .mode_bf(mode_bf), .scale(scale), .valid_out(valid_out),
        .state_top(dbg_state_top), .state_bf(dbg_state_bf));

    ram_a u_ram_a (
        .clk(clk), .rst_n(rst_n), .sel_proc(sel_proc),
        .ram_we(ram_we), .ram_re(ram_re), .ext_addr(ext_addr), .ext_din(ext_din),
        .wr_en_a(wr_en_a), .rd_en_a(rd_en_a), .addr_a(addr_a), .wr_data_a(y0),
        .wr_en_b(wr_en_b), .rd_en_b(rd_en_b), .addr_b(addr_b), .wr_data_b(y1),
        .rdata_a(rdata_a), .rdata_b(rdata_b), .valid_a(valid_a), .valid_b(valid_b));

    rom_zeta u_rom_zeta (
        .clk(clk), .rst_n(rst_n),
        .rom_en(rom_en), .zeta_addr(zeta_addr), .zeta(zeta), .zeta_valid(zeta_valid));

    butterfly u_butterfly (
        .clk(clk), .rst_n(rst_n),
        .valid_in(valid_in), .mode(mode_bf), .scale(scale),
        .a(rdata_a), .b(rdata_b), .z(zeta),
        .y0(y0), .y1(y1), .valid_out(valid_out));
endmodule
