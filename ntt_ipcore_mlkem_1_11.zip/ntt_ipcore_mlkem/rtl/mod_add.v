//==============================================================================
// mod_add : result = (a + b) mod q          (ML-KEM: q = 3329, 12 bit)
// Latency 1 chu ky. done = 1 chu ky khi ket qua hop le. Ket qua giu den lan valid_in tiep theo.
//==============================================================================
module mod_add #(
    parameter [11:0] Q = 12'd3329
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        valid_in,
    input  wire [11:0] a,
    input  wire [11:0] b,
    output reg  [11:0] result,
    output reg         done
);
    wire [12:0] sum     = {1'b0, a} + {1'b0, b};
    wire [12:0] sum_red = sum - {1'b0, Q};
    wire        ge_q    = (sum >= {1'b0, Q});

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            result <= 12'd0;
            done   <= 1'b0;
        end else begin
            done <= valid_in;
            if (valid_in) result <= ge_q ? sum_red[11:0] : sum[11:0];
        end
    end
endmodule
