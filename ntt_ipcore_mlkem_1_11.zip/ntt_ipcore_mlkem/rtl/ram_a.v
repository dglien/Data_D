//==============================================================================
// ram_a : RAM A 256 x 12 bit true dual port  =  BRAM (blk_mem_gen_ram) + MUX port A
//   MUX port A:  sel_proc = 0 -> FSM Top (LOAD_DATA: ram_we, ext_din / READ_DATA: ram_re, chi gui dia chi)
//                sel_proc = 1 -> Process A (addr_a = j, wr_data_a = y0)
//   Port B chi do Process B dieu khien (addr_b = j + len, wr_data_b = y1).
//   IP: Read First, khong output register -> latency doc 1 chu ky
//       doc: ena=1, wea=0 | ghi: ena=1, wea=1 | ena=0: dout giu nguyen
//   valid_x = rd_en tre 1 chu ky (BMG khong co chan valid)
//==============================================================================
module ram_a (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        sel_proc,
    // phia FSM Top (port A)
    input  wire        ram_we,
    input  wire        ram_re,
    input  wire [7:0]  ext_addr,            // = cnt_data
    input  wire [11:0] ext_din,
    // Process A (port A)
    input  wire        wr_en_a,
    input  wire        rd_en_a,
    input  wire [7:0]  addr_a,
    input  wire [11:0] wr_data_a,           // y0
    // Process B (port B)
    input  wire        wr_en_b,
    input  wire        rd_en_b,
    input  wire [7:0]  addr_b,
    input  wire [11:0] wr_data_b,           // y1
    // du lieu doc
    output wire [11:0] rdata_a,             // a  (= ext_rdata khi READ_DATA)
    output wire [11:0] rdata_b,             // b
    output reg         valid_a,
    output reg         valid_b
);
    // ---- MUX port A ----
    wire        we_a    = sel_proc ? wr_en_a   : ram_we;
    wire        re_a    = sel_proc ? rd_en_a   : ram_re;
    wire [7:0]  adr_a   = sel_proc ? addr_a    : ext_addr;
    wire [11:0] wdata_a = sel_proc ? wr_data_a : ext_din;
    // ---- port B ----
    wire        we_b = sel_proc & wr_en_b;
    wire        re_b = sel_proc & rd_en_b;

    blk_mem_gen_0 u_bram (
        .clka (clk), .ena(we_a | re_a), .wea(we_a), .addra(adr_a),  .dina(wdata_a),   .douta(rdata_a),
        .clkb (clk), .enb(we_b | re_b), .web(we_b), .addrb(addr_b), .dinb(wr_data_b), .doutb(rdata_b));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin valid_a <= 1'b0; valid_b <= 1'b0; end
        else        begin valid_a <= re_a; valid_b <= re_b; end
    end
endmodule
