CAU HINH BLOCK MEMORY GENERATOR (Vivado IP Catalog) - ML-KEM (q = 3329)
====================================================
IP 1 - ROM Zeta     Component Name : blk_mem_gen_zeta
  Basic    : Interface Type = Native ; Memory Type = Single Port ROM ; Common Clock
  Port A   : Width = 12 ; Depth = 128 ; Enable Port Type = Use ENA Pin
             Primitives Output Register = OFF ; Core Output Register = OFF   (latency = 1)
  Other    : Load Init File = ON -> ip/zeta.coe (radix 10, 128 gia tri, zeta[i] = 17^BitRev7(i) mod 3329)
             khong dung RSTA
  Cong     : clka, ena, addra[6:0], douta[11:0]

IP 2 - RAM A        Component Name : blk_mem_gen_ram
  Basic    : Interface Type = Native ; Memory Type = True Dual Port RAM ; Common Clock
  Port A/B : Width = 12 ; Depth = 256 ; Operating Mode = Read First ;
             Enable Port Type = Use ENA / ENB Pin
             Primitives Output Register = OFF ; Core Output Register = OFF   (latency = 1)
  Other    : khong init file ; khong dung RSTA/RSTB ; khong Byte Write
  Cong     : clka, ena, wea[0:0], addra[7:0], dina[11:0], douta[11:0]
             clkb, enb, web[0:0], addrb[7:0], dinb[11:0], doutb[11:0]

Quy uoc dieu khien (RTL da tuan theo):
  doc : ena=1, wea=0 -> du lieu o douta sau 1 chu ky ; douta giu nguyen khi ena=0
  ghi : ena=1, wea=1
  IP khong co chan "valid" -> RTL tu tao valid = (rd_en) tre 1 chu ky.
Neu ban bat Output Register (latency 2) thi phai them 1 tang tre cho valid trong RTL.
