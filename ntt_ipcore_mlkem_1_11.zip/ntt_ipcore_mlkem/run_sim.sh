#!/bin/bash
# Chay cac testbench bang Icarus Verilog (ML-KEM, q = 3329):  ./run_sim.sh   (chay tu thu muc goc cua project)
# Thu tu: add/sub/mul -> bo nho -> butterfly -> control -> tong (co file he so dau vao)
# (sim_models/ = model mo phong cua Block Memory Generator; trong Vivado dung IP that thay the)
set -e
ARITH="rtl/mod_add.v rtl/mod_sub.v rtl/mod_mul.v"
MEM="rtl/ram_a.v rtl/rom_zeta.v sim_models/blk_mem_gen_ram.v sim_models/blk_mem_gen_zeta.v"
CORE="$ARITH rtl/butterfly.v $MEM rtl/ntt_control.v"
mkdir -p sim
iverilog -g2005 -o sim/tb_arith_chain tb/tb_arith_chain.v $ARITH
iverilog -g2005 -o sim/tb_mem         tb/tb_mem.v $MEM
iverilog -g2005 -o sim/tb_butterfly   tb/tb_butterfly.v $ARITH rtl/butterfly.v
iverilog -g2005 -o sim/tb_ntt_control tb/tb_ntt_control.v $CORE
iverilog -g2005 -o sim/tb_all         tb/tb_all.v rtl/ntt_ip_v1_0.v $CORE
for t in tb_arith_chain tb_mem tb_butterfly tb_ntt_control tb_all; do
  echo "################ $t ################"
  vvp sim/$t | tee sim/$t.log
done
echo; grep -hE "tb_.* : " sim/*.log
# kiem bang phan mem (file do tb_all ghi ra)
python3 tools/rtl_model.py   # mo hinh Python cua RTL (khong can trinh mo phong)
python3 tools/check_ntt.py --mode ntt  --in data/ntt_input_single.txt --out data/ntt_output_single.txt
python3 tools/check_ntt.py --mode intt --in data/ntt_output_single.txt --out data/intt_output_single.txt
