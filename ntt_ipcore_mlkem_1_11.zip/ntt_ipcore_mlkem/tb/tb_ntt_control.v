`timescale 1ns/1ps
//==============================================================================
// tb_ntt_control : test CONTROL PATH (ntt_control = FSM_TOPCORE + FSM_Butterfly + counter)
//   noi truc tiep voi ram_a, rom_zeta, butterfly (khong qua top ntt_ip_v1_0):
//     start/mode -> din_ready -> wr_en (ext_wr_en) = 1, mem_in tra ext_data theo ext_addr = cnt_data
//     -> 256 he so vao RAM -> FSM tu tinh -> READ_DATA: dout/dout_valid -> mem_out[ext_addr]
//   Kiem tra: ket qua so voi mo hinh vang FIPS 203, chuyen state hop le (Top + Butterfly),
//             so lan vao state, WAIT_RESULT = 7 chu ky, xung calc_done.
//==============================================================================
module tb_ntt_control;
    localparam [63:0] Q   = 64'd3329;
    localparam [11:0] F12 = 12'd3303;
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    // ---- tin hieu tb <-> top ; 2 mang nho (mem_in, mem_out) nam NGOAI IP, trong testbench ----
    reg         start = 0, mode = 0, wr_en = 0;            // wr_en = ext_wr_en
    reg  [11:0] ext_data = 0;                               // ext_din  (doc tu mem_in)
    wire [7:0]  ext_addr;                                   // ext_addr  = cnt_data
    wire        busy, done, din_ready, dout_valid;
    wire [11:0] dout;                                       // ext_rdata
    wire [2:0]  st_top;  wire [3:0] st_bf;

    wire        sel_proc, ram_we, ram_re;
    wire        wr_en_a, rd_en_a, wr_en_b, rd_en_b;
    wire [7:0]  addr_a, addr_b;
    wire        valid_a, valid_b;
    wire [11:0] rdata_a, rdata_b;
    wire        rom_en, zeta_valid;  wire [6:0] zeta_addr;  wire [11:0] zeta;
    wire        valid_in, mode_bf, scale, valid_out;  wire [11:0] y0, y1;
    assign dout = rdata_a;

    ntt_control dut (
        .clk(clk), .rst_n(rst_n),
        .start(start), .mode(mode), .ext_wr_en(wr_en),
        .busy(busy), .done(done), .ext_ready(din_ready), .ext_rvalid(dout_valid),
        .sel_proc(sel_proc), .ram_we(ram_we), .ram_re(ram_re), .ext_addr(ext_addr),
        .wr_en_a(wr_en_a), .rd_en_a(rd_en_a), .wr_en_b(wr_en_b), .rd_en_b(rd_en_b),
        .addr_a(addr_a), .addr_b(addr_b), .valid_a(valid_a),
        .rom_en(rom_en), .zeta_addr(zeta_addr),
        .valid_in(valid_in), .mode_bf(mode_bf), .scale(scale), .valid_out(valid_out),
        .state_top(st_top), .state_bf(st_bf));

    ram_a u_ram_a (.clk(clk), .rst_n(rst_n), .sel_proc(sel_proc),
        .ram_we(ram_we), .ram_re(ram_re), .ext_addr(ext_addr), .ext_din(ext_data),
        .wr_en_a(wr_en_a), .rd_en_a(rd_en_a), .addr_a(addr_a), .wr_data_a(y0),
        .wr_en_b(wr_en_b), .rd_en_b(rd_en_b), .addr_b(addr_b), .wr_data_b(y1),
        .rdata_a(rdata_a), .rdata_b(rdata_b), .valid_a(valid_a), .valid_b(valid_b));

    rom_zeta u_rom_zeta (.clk(clk), .rst_n(rst_n), .rom_en(rom_en), .zeta_addr(zeta_addr),
                         .zeta(zeta), .zeta_valid(zeta_valid));

    butterfly u_butterfly (.clk(clk), .rst_n(rst_n), .valid_in(valid_in), .mode(mode_bf), .scale(scale),
        .a(rdata_a), .b(rdata_b), .z(zeta), .y0(y0), .y1(y1), .valid_out(valid_out));

    integer errors = 0;
    integer seed   = 32'hC0DE;

    //---------------- mo hinh vang ----------------
    reg [11:0] mem_in [0:255];
    reg [11:0] mem_out[0:255];
    reg [11:0] gold   [0:255];

    // mang dau vao tra du lieu theo dia chi IP dua ra: ext_din = mem_in[ext_addr]
    always @(negedge clk) ext_data = mem_in[ext_addr];
    function [11:0] g_mul(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t * b; g_mul = t % Q; end endfunction
    function [11:0] g_add(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t + b; g_add = t % Q; end endfunction
    function [11:0] g_sub(input [11:0] a, input [11:0] b); reg [63:0] t; begin t = a; t = t + Q - b; g_sub = t % Q; end endfunction
    function [11:0] g_zeta(input [6:0] k);
        reg [6:0] rev; reg [63:0] r, bb; integer i;
        begin
            for (i = 0; i < 7; i = i + 1) rev[i] = k[6-i];
            r = 1; bb = 17;
            for (i = 0; i < 7; i = i + 1) begin
                if (rev[i]) r = (r * bb) % Q;
                bb = (bb * bb) % Q;
            end
            g_zeta = r;
        end
    endfunction
    task golden_ntt;                                   // FIPS 203 Algorithm 9
        integer m, len, start_, j; reg [11:0] z, t;
        begin
            m = 1; len = 128;
            while (len >= 2) begin
                start_ = 0;
                while (start_ < 256) begin
                    z = g_zeta(m); m = m + 1;
                    for (j = start_; j < start_ + len; j = j + 1) begin
                        t = g_mul(z, gold[j + len]);
                        gold[j + len] = g_sub(gold[j], t);
                        gold[j]       = g_add(gold[j], t);
                    end
                    start_ = start_ + 2 * len;
                end
                len = len / 2;
            end
        end
    endtask
    task golden_intt;                                  // FIPS 203 Algorithm 10 (co nhan 128^-1)
        integer m, len, start_, j; reg [11:0] z, t, u;
        begin
            m = 127; len = 2;
            while (len <= 128) begin
                start_ = 0;
                while (start_ < 256) begin
                    z = g_zeta(m); m = m - 1;
                    for (j = start_; j < start_ + len; j = j + 1) begin
                        t = gold[j]; u = gold[j + len];
                        gold[j]       = g_add(t, u);
                        gold[j + len] = g_mul(z, g_sub(u, t));
                    end
                    start_ = start_ + 2 * len;
                end
                len = len * 2;
            end
            for (j = 0; j < 256; j = j + 1) gold[j] = g_mul(F12, gold[j]);
        end
    endtask

    //---------------- monitor state ----------------
    function [87:0] top_name(input [2:0] s);
        case (s)
            3'd0: top_name = "IDLE";       3'd1: top_name = "LOAD_DATA";
            3'd2: top_name = "EX";         3'd3: top_name = "READ_DATA";
            3'd4: top_name = "FIN";        default: top_name = "???";
        endcase
    endfunction
    function [87:0] bf_name(input [3:0] s);
        case (s)
            4'd0: bf_name = "IDLE";        4'd1: bf_name = "READ";
            4'd2: bf_name = "EX";          4'd3: bf_name = "WR";
            4'd4: bf_name = "NEXT_BF";     4'd5: bf_name = "NEXT_GRP";
            4'd6: bf_name = "NEXT_STAGE";  4'd7: bf_name = "SCALE";
            4'd8: bf_name = "DONE";        default: bf_name = "???";
        endcase
    endfunction
    function top_legal(input [2:0] p, input [2:0] c);
        top_legal = (p == 0 && c == 1) || (p == 1 && c == 2) || (p == 2 && c == 3) ||
                    (p == 3 && c == 4) || (p == 4 && c == 0);
    endfunction
    function bf_legal(input [3:0] p, input [3:0] c);
        bf_legal = (p == 0 && c == 1) || (p == 1 && c == 2) || (p == 2 && c == 3) ||
                   (p == 3 && (c == 4 || c == 5 || c == 6 || c == 7 || c == 8)) ||
                   (p == 4 && c == 1) || (p == 5 && c == 1) || (p == 6 && c == 1) ||
                   (p == 7 && c == 8) || (p == 8 && c == 0);
    endfunction

    wire [87:0] name_top = top_name(st_top);       // radix ASCII trong waveform
    wire [87:0] name_bf  = bf_name(st_bf);

    integer cyc = 0;  always @(posedge clk) cyc <= cyc + 1;
    reg [2:0] p_top = 0;  reg [3:0] p_bf = 0;
    integer n_load, n_ex, n_read, n_fin, n_rd, n_exb, n_wr, n_nbf, n_ng, n_ns, n_sc, n_scw, n_done, trace, ex_cycles;
    task clear_cnt; begin n_load = 0; n_ex = 0; n_read = 0; n_fin = 0; n_rd = 0; n_exb = 0; n_wr = 0; n_nbf = 0; n_ng = 0;
                          n_ns = 0; n_sc = 0; n_scw = 0; n_done = 0; trace = 12; ex_cycles = 0; end endtask

    always @(posedge clk) if (rst_n) begin
        if (st_top !== p_top) begin
            $display("  [cyc %6d] FSM_TOPCORE   : %-10s -> %-10s (busy=%b done=%b)", cyc, top_name(p_top), top_name(st_top), busy, done);
            if (!top_legal(p_top, st_top)) begin errors = errors + 1; $display("  [FAIL] chuyen state Top khong hop le"); end
            case (st_top) 3'd1: n_load = n_load + 1; 3'd2: n_ex = n_ex + 1; 3'd3: n_read = n_read + 1; 3'd4: n_fin = n_fin + 1; endcase
            p_top <= st_top;
        end
        if (st_bf == 4'd2) ex_cycles = ex_cycles + 1;
        if (st_bf !== p_bf) begin
            if (!bf_legal(p_bf, st_bf)) begin errors = errors + 1; $display("  [FAIL] chuyen state BF sai: %0s -> %0s", bf_name(p_bf), bf_name(st_bf)); end
            if (p_bf == 4'd2 && st_bf == 4'd3 && ex_cycles != 8) begin errors = errors + 1; $display("  [FAIL] EX = %0d chu ky (ky vong 8: valid_in o chu ky dau, valid_out sau 7 chu ky)", ex_cycles); end
            if (st_bf != 4'd2) ex_cycles = 0;
            case (st_bf) 4'd1: n_rd = n_rd + 1; 4'd2: n_exb = n_exb + 1; 4'd3: n_wr = n_wr + 1; 4'd4: n_nbf = n_nbf + 1;
                         4'd5: n_ng = n_ng + 1; 4'd6: n_ns = n_ns + 1; 4'd7: n_sc = n_sc + 1; endcase
            if (trace > 0 || st_bf == 4'd5 || st_bf == 4'd6 || st_bf == 4'd7 || (st_bf == 4'd0 && p_bf != 4'd0)) begin
                $display("  [cyc %6d]   FSM_BUTTERFLY: %-10s -> %-10s len=%0d i=%0d start_r=%0d j_cnt=%0d stage_cnt=%0d",
                         cyc, bf_name(p_bf), bf_name(st_bf), dut.len, dut.i_cnt, dut.start_r, dut.j_cnt, dut.stage_cnt);
                if (trace > 0) trace = trace - 1;
            end
            p_bf <= st_bf;
        end
        if (st_bf == 4'd7 && dut.wr_en_b) n_scw = n_scw + 1;
        if (dut.calc_done) begin n_done = n_done + 1; $display("  [cyc %6d]   >>> calc_done = 1 (DONE: Butterfly -> FSM_TOPCORE)", cyc); end
    end

    //---------------- bo nho dau ra: luu moi he so khi dout_valid : mem_out[ext_addr] = ext_rdata ----------------
    integer out_idx = 0;
    always @(posedge clk) if (dout_valid && out_idx < 256) begin
        mem_out[ext_addr] = dout;                  // mang ket qua: mem_out[ext_addr] = ext_rdata
        out_idx = out_idx + 1;
    end

    //---------------- 1 lan chay ----------------
    integer i, guard, mism, t_load, t_calc0, t_calc1;
    task run(input m);
        begin
            clear_cnt; out_idx = 0;
            // (1) start + mode
            @(negedge clk); mode = m; start = 1;
            @(negedge clk); start = 0;
            guard = 0;
            while (!din_ready && guard < 100) begin @(negedge clk); guard = guard + 1; end
            if (!din_ready) begin errors = errors + 1; $display("  [FAIL] khong len din_ready (FSM_TOPCORE khong vao LOAD_DATA)"); end
            $display("  --- start xong, FSM_TOPCORE = LOAD_DATA, din_ready = %b", din_ready);
            // (2) ghi 256 he so bang write_enable, moi chu ky 1 he so
            $display("  --- ghi 256 he so: ext_wr_en = 1, IP dua ext_addr = 0..255, mang vao tra ext_din = mem_in[ext_addr]");
            t_load = cyc;
            @(negedge clk); wr_en = 1;                     // ext_wr_en = 1 : IP tu dua ext_addr = 0..255
            guard = 0;
            while (din_ready && guard < 1000) begin @(negedge clk); guard = guard + 1; end
            wr_en = 0;                                     // du 256 he so -> ext_ready = 0
            $display("  --- da ghi du 256 he so vao RAM (mat %0d chu ky) -> FSM tu chay %0s", cyc - t_load, m ? "INTT" : "NTT");
            // (3) cho FSM tinh va doc ra
            guard = 0;
            while (!done && guard < 400000) begin @(negedge clk); guard = guard + 1; end
            if (!done) begin errors = errors + 1; $display("  [FAIL] timeout cho done"); end
            repeat (4) @(negedge clk);
            if (out_idx != 256) begin errors = errors + 1; $display("  [FAIL] chi doc duoc %0d/256 he so", out_idx); end
            if (busy || st_top !== 3'd0 || st_bf !== 4'd0) begin errors = errors + 1; $display("  [FAIL] cuoi phai busy=0 va ca 2 FSM ve IDLE"); end

            // (4) so voi mo hinh vang
            mism = 0;
            for (i = 0; i < 256; i = i + 1) if (mem_out[i] !== gold[i]) begin
                mism = mism + 1; if (mism <= 5) $display("  [FAIL] [%0d] DUT=%0d GOLD=%0d", i, mem_out[i], gold[i]); end
            if (mism == 0) $display("  [ OK ] 256/256 he so khop mo hinh vang (mem_out[0]=%0d mem_out[255]=%0d)", mem_out[0], mem_out[255]);
            else begin errors = errors + 1; $display("  [FAIL] %0d/256 he so sai", mism); end
            $display("  --- Dem: Top[LOAD_DATA=%0d EX=%0d READ_DATA=%0d FIN=%0d] BF[READ=%0d EX=%0d WR=%0d NEXT_BF=%0d NEXT_GRP=%0d NEXT_STAGE=%0d SCALE=%0d ghi_scale=%0d calc_done=%0d]",
                     n_load, n_ex, n_read, n_fin, n_rd, n_exb, n_wr, n_nbf, n_ng, n_ns, n_sc, n_scw, n_done);
            if (n_load != 1 || n_ex != 1 || n_read != 1 || n_fin != 1 || n_done != 1) begin errors = errors + 1; $display("  [FAIL] Top phai qua moi state 1 lan, calc_done 1 xung"); end
            if (n_wr != 896 || n_rd != 896 || n_exb != 896 || n_nbf != 769 || n_ng != 120 || n_ns != 6) begin errors = errors + 1; $display("  [FAIL] ky vong 896 butterfly (7 tang x 128), NEXT_BF=769, NEXT_GRP=120, NEXT_STAGE=6"); end
            if (m == 0 && (n_sc != 0 || n_scw != 0))   begin errors = errors + 1; $display("  [FAIL] NTT khong duoc SCALE"); end
            if (m == 1 && (n_sc != 1 || n_scw != 256)) begin errors = errors + 1; $display("  [FAIL] INTT phai SCALE 256 he so"); end
        end
    endtask

    integer n;
    reg [11:0] x_orig [0:255];
    initial begin
        clear_cnt;
        repeat (5) @(negedge clk); rst_n = 1; repeat (3) @(negedge clk);
        if (st_top !== 3'd0 || st_bf !== 4'd0) begin errors = errors + 1; $display("[FAIL] trang thai sau reset"); end

        $display("\n##### T1: NTT x=[1,0,...,0] -> toan 1 #####");
        for (n = 0; n < 256; n = n + 1) begin mem_in[n] = (n == 0); gold[n] = mem_in[n]; end
        golden_ntt; run(1'b0);

        $display("\n##### T2: NTT ngau nhien #####");
        for (n = 0; n < 256; n = n + 1) begin mem_in[n] = {$random(seed)} % 32'd3329; gold[n] = mem_in[n]; x_orig[n] = mem_in[n]; end
        golden_ntt; run(1'b0);

        $display("\n##### T3: INTT(ket qua T2) phai ra lai x #####");
        for (n = 0; n < 256; n = n + 1) begin mem_in[n] = mem_out[n]; gold[n] = x_orig[n]; end
        run(1'b1);

        $display("\n##### T4: INTT ngau nhien #####");
        for (n = 0; n < 256; n = n + 1) begin mem_in[n] = {$random(seed)} % 32'd3329; gold[n] = mem_in[n]; end
        golden_intt; run(1'b1);

        $display("\n==================================================");
        if (errors == 0) $display(" tb_ntt_control : PASS"); else $display(" tb_ntt_control : FAIL (%0d loi)", errors);
        $display("==================================================");
        $finish;
    end
    initial begin #400000000; $display("[TIMEOUT] tb_ntt_control"); $finish; end
endmodule
