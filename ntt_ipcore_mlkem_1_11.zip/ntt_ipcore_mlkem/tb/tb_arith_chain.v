`timescale 1ns/1ps
//==============================================================================
// tb_arith_chain : test mod_add, mod_sub, mod_mul
//  PHAN 1: chuoi phep tinh noi tiep - phep nay xong (done) moi chuyen sang phep ke
//          ADD -> done -> SUB -> done -> MUL -> done -> ADD ... (kiem tra latency 1/1/5)
//  PHAN 2: corner case
//  PHAN 3: streaming 1 phep/chu ky (pipeline), so sanh theo thu tu voi mo hinh vang
//==============================================================================
module tb_arith_chain;
    localparam [63:0] Q = 64'd3329;
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    reg         add_v, sub_v, mul_v;
    reg  [11:0] add_a, add_b, sub_a, sub_b, mul_a, mul_b;
    wire [11:0] add_r, sub_r, mul_r;
    wire        add_done, sub_done, mul_done;

    mod_add u_add (.clk(clk), .rst_n(rst_n), .valid_in(add_v), .a(add_a), .b(add_b), .result(add_r), .done(add_done));
    mod_sub u_sub (.clk(clk), .rst_n(rst_n), .valid_in(sub_v), .a(sub_a), .b(sub_b), .result(sub_r), .done(sub_done));
    mod_mul u_mul (.clk(clk), .rst_n(rst_n), .valid_in(mul_v), .a(mul_a), .b(mul_b), .result(mul_r), .done(mul_done));

    integer errors = 0;
    integer seed   = 32'h1234;

    // tin hieu "ten" de doc song (them vao wave voi radix ASCII)
    reg [8*24-1:0] phase;      // dang o PHAN nao
    reg [8*3-1:0]  cur_op;     // phep dang chay: ADD / SUB / MUL / ALL

    function [11:0] g_add(input [11:0] a, input [11:0] b);
        reg [63:0] t; begin t = a; t = t + b; g_add = t % Q; end
    endfunction
    function [11:0] g_sub(input [11:0] a, input [11:0] b);
        reg [63:0] t; begin t = a; t = t + Q - b; g_sub = t % Q; end
    endfunction
    function [11:0] g_mul(input [11:0] a, input [11:0] b);
        reg [63:0] t; begin t = a; t = t * b; g_mul = t % Q; end
    endfunction
    function [11:0] rnd(input dummy);
        begin rnd = {$random(seed)} % 32'd3329; end
    endfunction

    //----------------------------------------------------------- tasks 1 phep
    task run_add(input [11:0] a, input [11:0] b, output [11:0] r);
        integer cyc;
        begin
            cur_op = "ADD";
            @(negedge clk); add_a = a; add_b = b; add_v = 1;
            @(negedge clk); add_v = 0; cyc = 1;
            while (!add_done) begin @(negedge clk); cyc = cyc + 1; end
            r = add_r;
            if (r !== g_add(a,b) || cyc != 1) begin errors = errors + 1;
                $display("  [FAIL] ADD %0d + %0d = %0d (exp %0d) latency=%0d", a, b, r, g_add(a,b), cyc); end
            else $display("  [ OK ] ADD %0d + %0d = %0d  -> done sau %0d chu ky", a, b, r, cyc);
        end
    endtask
    task run_sub(input [11:0] a, input [11:0] b, output [11:0] r);
        integer cyc;
        begin
            cur_op = "SUB";
            @(negedge clk); sub_a = a; sub_b = b; sub_v = 1;
            @(negedge clk); sub_v = 0; cyc = 1;
            while (!sub_done) begin @(negedge clk); cyc = cyc + 1; end
            r = sub_r;
            if (r !== g_sub(a,b) || cyc != 1) begin errors = errors + 1;
                $display("  [FAIL] SUB %0d - %0d = %0d (exp %0d) latency=%0d", a, b, r, g_sub(a,b), cyc); end
            else $display("  [ OK ] SUB %0d - %0d = %0d  -> done sau %0d chu ky", a, b, r, cyc);
        end
    endtask
    task run_mul(input [11:0] a, input [11:0] b, output [11:0] r);
        integer cyc;
        begin
            cur_op = "MUL";
            @(negedge clk); mul_a = a; mul_b = b; mul_v = 1;
            @(negedge clk); mul_v = 0; cyc = 1;
            while (!mul_done) begin @(negedge clk); cyc = cyc + 1; end
            r = mul_r;
            if (r !== g_mul(a,b) || cyc != 5) begin errors = errors + 1;
                $display("  [FAIL] MUL %0d * %0d = %0d (exp %0d) latency=%0d", a, b, r, g_mul(a,b), cyc); end
            else $display("  [ OK ] MUL %0d * %0d = %0d  -> done sau %0d chu ky", a, b, r, cyc);
        end
    endtask

    //----------------------------------------------------------- streaming
    localparam N = 4000;
    reg [11:0] ea [0:N-1];  reg [11:0] eb [0:N-1];
    reg [11:0] x_add [0:N-1], x_sub [0:N-1], x_mul [0:N-1];
    integer i_add = 0, i_sub = 0, i_mul = 0;
    integer e_add = 0, e_sub = 0, e_mul = 0;
    reg     stream_en = 0;

    always @(posedge clk) if (stream_en) begin
        if (add_done) begin if (add_r !== x_add[i_add]) e_add = e_add + 1; i_add = i_add + 1; end
        if (sub_done) begin if (sub_r !== x_sub[i_sub]) e_sub = e_sub + 1; i_sub = i_sub + 1; end
        if (mul_done) begin if (mul_r !== x_mul[i_mul]) e_mul = e_mul + 1; i_mul = i_mul + 1; end
    end

    //----------------------------------------------------------- main
    reg [11:0] r, r1, r2, r3;
    reg [11:0] ba, bb_, bz, bt, bo0, bo1, bd;
    integer k;
    initial begin
        phase = "RESET"; cur_op = "---";
        add_v = 0; sub_v = 0; mul_v = 0;
        add_a = 0; add_b = 0; sub_a = 0; sub_b = 0; mul_a = 0; mul_b = 0;
        repeat (4) @(negedge clk); rst_n = 1; repeat (2) @(negedge clk);

        $display("=====================================================");
        $display(" PHAN 1: chuoi ADD -> SUB -> MUL (done cua phep truoc kich phep sau)");
        phase = "P1_CHAIN_ADD_SUB_MUL";
        $display("=====================================================");
        for (k = 0; k < 6; k = k + 1) begin
            $display("--- Vong %0d ---", k);
            run_add(rnd(0), rnd(0), r1);          // ADD xong (add_done)
            $display("     >> add_done=1, chuyen sang SUB voi r_add = %0d", r1);
            run_sub(r1, rnd(0), r2);              // SUB xong (sub_done)
            $display("     >> sub_done=1, chuyen sang MUL voi r_sub = %0d", r2);
            run_mul(r2, rnd(0), r3);              // MUL xong (mul_done)
            $display("     >> mul_done=1, ket qua cuoi vong = %0d", r3);
        end

        $display("=====================================================");
        $display(" PHAN 2: corner case");
        phase = "P2_CORNER";
        $display("=====================================================");
        run_add(12'd0, 12'd0, r);
        run_add(12'd3328, 12'd1, r);           // = 0
        run_add(12'd3328, 12'd3328, r);     // = q-2
        run_add(12'd1664, 12'd1665, r);           // = 0 (dung q)
        run_sub(12'd0, 12'd1, r);                 // = q-1
        run_sub(12'd5, 12'd5, r);                 // = 0
        run_sub(12'd0, 12'd3328, r);           // = 1
        run_sub(12'd3328, 12'd0, r);
        run_mul(12'd0, 12'd3328, r);
        run_mul(12'd3328, 12'd3328, r);     // = 1
        run_mul(12'd3328, 12'd1, r);
        run_mul(12'd3303, 12'd128, r);         // F * 128 = 1  (he so scale INTT)
        run_mul(12'd17, 12'd17, r);

        $display("=====================================================");
        $display(" PHAN 3: streaming %0d phep, moi chu ky 1 phep (pipeline)", N);
        phase = "P3_STREAM";
        $display("=====================================================");
        for (k = 0; k < N; k = k + 1) begin
            ea[k] = rnd(0); eb[k] = rnd(0);
            if (k < 8) begin ea[k] = 12'd3328 - k; eb[k] = 12'd3328 - 2*k; end   // them cac gia tri lon
            x_add[k] = g_add(ea[k], eb[k]);
            x_sub[k] = g_sub(ea[k], eb[k]);
            x_mul[k] = g_mul(ea[k], eb[k]);
        end
        stream_en = 1; cur_op = "ALL";
        for (k = 0; k < N; k = k + 1) begin
            @(negedge clk);
            add_v = 1; sub_v = 1; mul_v = 1;
            add_a = ea[k]; add_b = eb[k]; sub_a = ea[k]; sub_b = eb[k]; mul_a = ea[k]; mul_b = eb[k];
        end
        @(negedge clk); add_v = 0; sub_v = 0; mul_v = 0;
        repeat (12) @(negedge clk);
        stream_en = 0;
        $display("  ADD: nhan %0d ket qua, sai %0d", i_add, e_add);
        $display("  SUB: nhan %0d ket qua, sai %0d", i_sub, e_sub);
        $display("  MUL: nhan %0d ket qua, sai %0d", i_mul, e_mul);
        errors = errors + e_add + e_sub + e_mul;
        if (i_add != N || i_sub != N || i_mul != N) begin errors = errors + 1; $display("  [FAIL] so luong done khong khop"); end

        $display("=====================================================");
        $display(" PHAN 4: ghep add/sub/mul thanh BUTTERFLY (done phep truoc -> phep sau)");
        phase = "P4_BUTTERFLY";
        $display("=====================================================");
        for (k = 0; k < 4; k = k + 1) begin
            ba = rnd(0); bb_ = rnd(0); bz = rnd(0);
            $display("--- CT (NTT): a=%0d b=%0d z=%0d ---", ba, bb_, bz);
            run_mul(bz, bb_, bt);                 // t = z*b           -> mul_done
            $display("     >> mul_done, t=%0d -> cho add va sub", bt);
            run_add(ba, bt, bo0);                 // o0 = a + t        -> add_done
            run_sub(ba, bt, bo1);                 // o1 = a - t        -> sub_done
            if (bo0 !== g_add(ba, g_mul(bz, bb_)) || bo1 !== g_sub(ba, g_mul(bz, bb_))) begin
                errors = errors + 1; $display("  [FAIL] CT butterfly sai"); end
            else $display("  [ OK ] CT butterfly: o0=%0d o1=%0d", bo0, bo1);

            $display("--- GS (INTT): a=%0d b=%0d z=%0d ---", ba, bb_, bz);
            run_add(ba, bb_, bo0);                // o0 = a + b        -> add_done
            run_sub(ba, bb_, bd);                 // d  = a - b        -> sub_done
            $display("     >> sub_done, d=%0d -> cho mul voi -z", bd);
            run_mul(bd, (bz == 0) ? 12'd0 : (12'd3329 - bz), bo1);   // o1 = d*(-z)  -> mul_done
            if (bo0 !== g_add(ba, bb_) || bo1 !== g_mul(g_sub(ba, bb_), (bz == 0) ? 12'd0 : (12'd3329 - bz))) begin
                errors = errors + 1; $display("  [FAIL] GS butterfly sai"); end
            else $display("  [ OK ] GS butterfly: o0=%0d o1=%0d", bo0, bo1);
        end

        $display("=====================================================");
        if (errors == 0) $display(" tb_arith_chain : PASS");
        else             $display(" tb_arith_chain : FAIL (%0d loi)", errors);
        $display("=====================================================");
        $finish;
    end

    initial begin #20000000; $display("[TIMEOUT] tb_arith_chain"); $finish; end
endmodule
