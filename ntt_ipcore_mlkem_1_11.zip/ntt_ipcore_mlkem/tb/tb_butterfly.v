`timescale 1ns/1ps
//==============================================================================
// tb_butterfly : test KHOI BUTTERFLY (1 mod_add + 1 mod_sub + 1 mod_mul dung chung, mux theo CT/GS)
//   PHAN 1: tung butterfly CT / GS / SCALE, do latency (ky vong 7 chu ky)
//   PHAN 2: streaming 3 dot (CT, GS, SCALE) moi chu ky 1 butterfly, kiem tra thu tu + latency
//           (mode giu nguyen trong 1 dot; giua 2 dot cho pipeline can - dung nhu luc chay that)
//   PHAN 3: y0/y1 duoc giu sau khi het valid
//   Co them tin hieu noi bo (add_done, mul_done) de xem "done" noi tiep nhau:
//     CT : mul_done -> add/sub -> valid_out      GS : add_done -> mul -> mul_done -> valid_out
//==============================================================================
module tb_butterfly;
    localparam [63:0] Q   = 64'd3329;
    localparam [63:0] F   = 64'd3303;
    localparam [11:0] F12 = 12'd3303;
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    reg         v, gs, sc;
    reg  [11:0] a, b, z;
    wire [11:0] o0, o1;
    wire        ov;

    butterfly dut (.clk(clk), .rst_n(rst_n), .valid_in(v), .mode(gs), .scale(sc),
                   .a(a), .b(b), .z(z), .y0(o0), .y1(o1), .valid_out(ov));

    // tin hieu "ten" de doc song
    reg [8*5-1:0] cur_mode;

    integer errors = 0;
    integer seed = 32'hBEEF;

    function [11:0] mulq(input [11:0] x, input [11:0] y);
        reg [63:0] t; begin t = x; t = t * y; mulq = t % Q; end endfunction
    function [11:0] addq(input [11:0] x, input [11:0] y);
        reg [63:0] t; begin t = x; t = t + y; addq = t % Q; end endfunction
    function [11:0] subq(input [11:0] x, input [11:0] y);
        reg [63:0] t; begin t = x; t = t + Q - y; subq = t % Q; end endfunction
    function [11:0] negq(input [11:0] x);
        begin negq = (x == 0) ? 12'd0 : (Q - x); end endfunction
    function [11:0] rnd(input dummy);
        begin rnd = {$random(seed)} % 32'd3329; end endfunction

    // mode: 0 = CT, 1 = GS, 2 = SCALE
    function [11:0] exp_o0(input [1:0] mode, input [11:0] xa, input [11:0] xb, input [11:0] xz);
        begin
            case (mode)
                2'd0:    exp_o0 = addq(xa, mulq(xz, xb));
                2'd1:    exp_o0 = addq(xa, xb);
                default: exp_o0 = xa;
            endcase
        end
    endfunction
    function [11:0] exp_o1(input [1:0] mode, input [11:0] xa, input [11:0] xb, input [11:0] xz);
        begin
            case (mode)
                2'd0:    exp_o1 = subq(xa, mulq(xz, xb));
                2'd1:    exp_o1 = mulq(subq(xa, xb), negq(xz));
                default: exp_o1 = mulq(xa, F12);
            endcase
        end
    endfunction

    //---------------------------------------------------------- 1 butterfly
    task single(input [1:0] mode, input [11:0] xa, input [11:0] xb, input [11:0] xz);
        integer cyc;
        begin
            cur_mode = (mode == 0) ? "CT" : (mode == 1) ? "GS" : "SCALE";
            @(negedge clk);
            v = 1; gs = (mode != 0); sc = (mode == 2); a = xa; b = xb; z = xz;
            @(negedge clk); v = 0; cyc = 1;
            while (!ov) begin
                @(negedge clk); cyc = cyc + 1;
                if (dut.add_done)  $display("     [chu ky %0d] add_done : mod_add/mod_sub xong (CT: ket qua cuoi | GS: truoc nhan)", cyc);
                if (dut.mul_done)  $display("     [chu ky %0d] mul_done : mod_mul xong, t=%0d", cyc, dut.mul_t);
            end
            if (cyc != 7) begin errors = errors + 1; $display("  [FAIL] latency = %0d (ky vong 7)", cyc); end
            if (o1 !== exp_o1(mode, xa, xb, xz) || (mode != 2 && o0 !== exp_o0(mode, xa, xb, xz))) begin
                errors = errors + 1;
                $display("  [FAIL] mode=%0d a=%0d b=%0d z=%0d : o0=%0d (exp %0d) o1=%0d (exp %0d)",
                         mode, xa, xb, xz, o0, exp_o0(mode,xa,xb,xz), o1, exp_o1(mode,xa,xb,xz));
            end else
                $display("  [ OK ] %-5s a=%0d b=%0d z=%0d -> o0=%0d o1=%0d  (valid_out sau %0d chu ky)",
                         (mode==0) ? "CT" : (mode==1) ? "GS" : "SCALE", xa, xb, xz, o0, o1, cyc);
        end
    endtask

    //---------------------------------------------------------- streaming
    localparam N = 3000;
    reg [11:0] sa [0:N-1], sb [0:N-1], sz [0:N-1];
    reg [1:0]  sm [0:N-1];
    integer    iss = 0, rcv = 0, err_s = 0, err_lat = 0;
    integer    cyc_now = 0;
    integer    t_issue [0:N-1];
    reg        stream_en = 0;

    always @(posedge clk) cyc_now <= cyc_now + 1;

    always @(posedge clk) if (stream_en && ov) begin
        if (o1 !== exp_o1(sm[rcv], sa[rcv], sb[rcv], sz[rcv]) ||
            (sm[rcv] != 2 && o0 !== exp_o0(sm[rcv], sa[rcv], sb[rcv], sz[rcv]))) begin
            err_s = err_s + 1;
            if (err_s < 10) $display("  [FAIL] stream #%0d mode=%0d", rcv, sm[rcv]);
        end
        if (cyc_now - t_issue[rcv] != 7) err_lat = err_lat + 1;
        rcv = rcv + 1;
    end

    integer k;
    reg [11:0] h0, h1;
    initial begin
        v = 0; gs = 0; sc = 0; a = 0; b = 0; z = 0; cur_mode = "---";
        repeat (4) @(negedge clk); rst_n = 1; repeat (2) @(negedge clk);

        $display("===== PHAN 1: tung butterfly =====");
        single(2'd0, 12'd100, 12'd200, 12'd300);            // CT
        single(2'd0, 12'd3328, 12'd3328, 12'd3328);
        single(2'd0, 12'd0, 12'd0, 12'd0);
        single(2'd0, 12'd5, 12'd7, 12'd1729);            // zeta[1]
        single(2'd1, 12'd100, 12'd200, 12'd300);            // GS
        single(2'd1, 12'd3328, 12'd1, 12'd2580);
        single(2'd1, 12'd0, 12'd0, 12'd0);                  // z = 0
        single(2'd2, 12'd1, 12'd0, 12'd0);                  // SCALE: 1*F = F
        single(2'd2, 12'd128, 12'd0, 12'd0);                // SCALE: 128*F = 1
        single(2'd2, 12'd3328, 12'd0, 12'd0);
        for (k = 0; k < 6; k = k + 1) single(k % 3, rnd(0), rnd(0), rnd(0));

        $display("===== PHAN 2: streaming %0d butterfly (3 dot CT/GS/SCALE), 1/chu ky =====", N);
        cur_mode = "BATCH";
        for (k = 0; k < N; k = k + 1) begin
            sa[k] = rnd(0); sb[k] = rnd(0); sz[k] = rnd(0);
            sm[k] = k / 1000;                         // dot 0 = CT, dot 1 = GS, dot 2 = SCALE
        end
        stream_en = 1;
        for (k = 0; k < N; k = k + 1) begin
            if (k > 0 && sm[k] != sm[k-1]) begin       // doi che do: cho pipeline can
                @(negedge clk); v = 0; repeat (12) @(negedge clk);
            end
            @(negedge clk);
            v = 1; gs = (sm[k] != 0); sc = (sm[k] == 2);
            a = sa[k]; b = sb[k]; z = sz[k];
            t_issue[k] = cyc_now;
            iss = iss + 1;
        end
        @(negedge clk); v = 0;
        repeat (12) @(negedge clk);
        stream_en = 0;
        $display("  Da day %0d, nhan %0d ket qua, sai gia tri %0d, sai latency %0d", iss, rcv, err_s, err_lat);
        errors = errors + err_s + err_lat;
        if (rcv != N) begin errors = errors + 1; $display("  [FAIL] so luong valid_out khong khop"); end

        $display("===== PHAN 3: giu ket qua sau khi het valid =====");
        h0 = o0; h1 = o1;
        repeat (10) @(negedge clk);
        if (o0 !== h0 || o1 !== h1) begin errors = errors + 1; $display("  [FAIL] o0/o1 bi thay doi khi khong co valid"); end
        else $display("  [ OK ] o0/o1 giu on dinh");

        $display("======================================");
        if (errors == 0) $display(" tb_butterfly : PASS"); else $display(" tb_butterfly : FAIL (%0d loi)", errors);
        $finish;
    end
    initial begin #30000000; $display("[TIMEOUT] tb_butterfly"); $finish; end
endmodule
