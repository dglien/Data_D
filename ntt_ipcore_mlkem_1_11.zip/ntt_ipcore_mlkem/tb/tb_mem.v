`timescale 1ns/1ps
//==============================================================================
// tb_mem : test rom_zeta va ram_a (BRAM + MUX), dung model IP trong sim_models/
//   rom_zeta : 128 gia tri doi chieu 17^BitRev7(k) mod 3329, latency 1, zeta_valid, giu zeta
//   ram_a    : sel_proc=1: ghi 2 port cung luc, doc cheo | sel_proc=0: FSM Top dieu khien port A
//              kiem tra valid, giu rdata, MUX chon dung nguon
//==============================================================================
module tb_mem;
    localparam [63:0] Q = 64'd3329;
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;
    integer errors = 0;

    reg         rom_en;  reg [6:0] rom_addr;  wire [11:0] rom_z;  wire rom_v;
    rom_zeta u_rom_zeta (.clk(clk), .rst_n(rst_n), .rom_en(rom_en), .zeta_addr(rom_addr), .zeta(rom_z), .zeta_valid(rom_v));

    function [11:0] g_zeta(input [6:0] k);
        reg [6:0] rev; reg [63:0] r, bb; integer i;
        begin
            for (i = 0; i < 7; i = i + 1) rev[i] = k[6-i];
            r = 1; bb = 17;
            for (i = 0; i < 7; i = i + 1) begin
                if (rev[i]) r = (r * bb) % Q;
                bb = (bb * bb) % Q;
            end
            g_zeta = r;
        end
    endfunction

    reg         sel;
    reg         t_we, t_re;  reg [7:0] t_addr;  reg [11:0] t_wd;
    reg         a_we, a_re, b_we, b_re;
    reg  [7:0]  a_ad, b_ad;
    reg  [11:0] a_wd, b_wd;
    wire [11:0] rd_a, rd_b;
    wire        v_a, v_b;
    ram_a u_ram_a (.clk(clk), .rst_n(rst_n), .sel_proc(sel),
        .ram_we(t_we), .ram_re(t_re), .ext_addr(t_addr), .ext_din(t_wd),
        .wr_en_a(a_we), .rd_en_a(a_re), .addr_a(a_ad), .wr_data_a(a_wd),
        .wr_en_b(b_we), .rd_en_b(b_re), .addr_b(b_ad), .wr_data_b(b_wd),
        .rdata_a(rd_a), .rdata_b(rd_b), .valid_a(v_a), .valid_b(v_b));

    function [11:0] pat(input integer n);       // du lieu thu: n*13+7 mod 3329
        begin pat = (n * 13 + 7) % 3329; end
    endfunction

    integer k;
    reg [11:0] held;
    initial begin
        rom_en = 0; rom_addr = 0; sel = 0;
        t_we = 0; t_re = 0; t_addr = 0; t_wd = 0;
        a_we = 0; a_re = 0; b_we = 0; b_re = 0; a_ad = 0; b_ad = 0; a_wd = 0; b_wd = 0;
        repeat (3) @(negedge clk); rst_n = 1; repeat (2) @(negedge clk);

        $display("===== rom_zeta (128 x 12, ip/zeta.coe) =====");
        for (k = 0; k < 128; k = k + 1) begin
            @(negedge clk); rom_en = 1; rom_addr = k;
            @(negedge clk); rom_en = 0;
            if (rom_v !== 1'b1) begin errors = errors + 1; $display("[FAIL] zeta_valid khong len, k=%0d", k); end
            if (rom_z !== g_zeta(k)) begin errors = errors + 1; $display("[FAIL] zeta[%0d]=%0d exp %0d", k, rom_z, g_zeta(k)); end
            if (k == 1 && rom_z !== 12'd1729) begin errors = errors + 1; $display("[FAIL] zeta[1] sai so voi FIPS 203"); end
            if (k == 2 && rom_z !== 12'd2580) begin errors = errors + 1; $display("[FAIL] zeta[2] sai so voi FIPS 203"); end
        end
        $display("  zeta[0]=%0d zeta[1]=%0d zeta[2]=%0d zeta[127]=%0d : da doi chieu 128 gia tri", g_zeta(0), g_zeta(1), g_zeta(2), g_zeta(127));
        @(negedge clk);
        if (rom_v !== 1'b0) begin errors = errors + 1; $display("[FAIL] zeta_valid phai ve 0 khi rom_en = 0"); end
        rom_addr = 7'd77; held = rom_z; repeat (3) @(negedge clk);
        if (rom_z !== held) begin errors = errors + 1; $display("[FAIL] zeta phai giu khi rom_en = 0"); end

        $display("===== ram_a, sel_proc = 1 (Process A / B dieu khien 2 port) =====");
        sel = 1;
        for (k = 0; k < 256; k = k + 2) begin
            @(negedge clk);
            a_we = 1; a_ad = k;     a_wd = pat(k);
            b_we = 1; b_ad = k + 1; b_wd = pat(k + 1);
        end
        @(negedge clk); a_we = 0; b_we = 0;
        for (k = 0; k < 256; k = k + 2) begin
            @(negedge clk); a_re = 1; a_ad = k + 1; b_re = 1; b_ad = k;
            @(negedge clk); a_re = 0; b_re = 0;
            if (!v_a || !v_b) begin errors = errors + 1; $display("[FAIL] RAM valid khong len, k=%0d", k); end
            if (rd_a !== pat(k + 1) || rd_b !== pat(k)) begin
                errors = errors + 1; $display("[FAIL] RAM doc sai k=%0d: A=%0d B=%0d", k, rd_a, rd_b); end
        end
        @(negedge clk);
        if (v_a || v_b) begin errors = errors + 1; $display("[FAIL] RAM valid phai ve 0 khi khong doc"); end
        held = rd_a; a_ad = 8'd5; repeat (3) @(negedge clk);
        if (rd_a !== held) begin errors = errors + 1; $display("[FAIL] rdata phai giu khi khong doc"); end

        $display("===== ram_a, sel_proc = 0 (FSM Top dieu khien port A) =====");
        sel = 0;
        @(negedge clk); t_we = 1; t_addr = 8'd10; t_wd = 12'd123;           // Top ghi
        a_we = 1; a_ad = 8'd11; a_wd = 12'd999;                              // Process A co ghi cung luc -> phai bi MUX chan
        @(negedge clk); t_we = 0; a_we = 0;
        @(negedge clk); t_re = 1; t_addr = 8'd10;
        @(negedge clk); t_re = 0;
        if (rd_a !== 12'd123 || !v_a) begin errors = errors + 1; $display("[FAIL] Top doc lai addr 10 = %0d", rd_a); end
        sel = 1;
        @(negedge clk); a_re = 1; a_ad = 8'd11;
        @(negedge clk); a_re = 0;
        if (rd_a === 12'd999) begin errors = errors + 1; $display("[FAIL] MUX khong chan ghi cua Process A khi sel_proc=0"); end
        else $display("  MUX: sel_proc=0 chan dung nguon Process A, chon dung nguon Top : OK");

        $display("======================================");
        if (errors == 0) $display(" tb_mem : PASS"); else $display(" tb_mem : FAIL (%0d loi)", errors);
        $finish;
    end
    initial begin #5000000; $display("[TIMEOUT] tb_mem"); $finish; end
endmodule
