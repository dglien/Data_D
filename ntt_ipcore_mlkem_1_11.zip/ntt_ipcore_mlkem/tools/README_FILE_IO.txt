QUY TRINH KIEM IP BANG PHAN MEM (theo huong dan cua thay) - dung testbench tong tb_all
=====================================================================================
  data/ntt_input_single.txt  --(tb_all doc vao mem_in)--> IP --> data/ntt_output_single.txt   (NTT)
  data/ntt_output_single.txt --(tb_all doc lai)--------> IP --> data/intt_output_single.txt   (INTT)
  tools/check_ntt.py tinh NTT/INTT chuan tren file dau vao roi so voi file do IP ghi ra.

Dinh dang file: moi dong 1 he so dang hex (vi du 5BE), 0 <= he so < q = 3329, 256 dong / 1 case.

VIVADO (Windows)
 1) Them rtl/*.v vao Design Sources, tb/tb_all.v vao Simulation Sources, Set as Top.
 2) Sua dong dau file tb_all.v:
        `define DATA_DIR "D:/Oanh/DATN/NTT_BaseLine/2710/ntt_ipcore/data/"
    (dung dau / , co / o cuoi)
 3) Run Behavioral Simulation > run all  -> tb_all ghi ntt_output_single.txt va intt_output_single.txt vao DATA_DIR.
 4) Mo Command Prompt:
        cd D:\Oanh\DATN\NTT_BaseLine\2710\ntt_ipcore
        python tools\check_ntt.py --mode ntt  --in data\ntt_input_single.txt --out data\ntt_output_single.txt
        python tools\check_ntt.py --mode intt --in data\ntt_output_single.txt --out data\intt_output_single.txt
    "[PASS] ... khop mo hinh phan mem" la IP dung.
    Muon thu du lieu khac: thay noi dung data/ntt_input_single.txt (va ntt_expected_single.txt neu co dap an)
    - check_ntt.py cung chay duoc voi file nhieu case (ntt_input_100cases.txt) neu ban ghi file ra tuong ung.

LINUX / ICARUS: ./run_sim.sh  (chay tat ca testbench roi chay python kiem)

MO HINH PHAN MEM trong check_ntt.py (2 cach doc lap, phai trung nhau):
  fips   : thuat toan butterfly FIPS 203 Algorithm 9/10
  direct : dinh nghia toan hoc: f_hat[2i], f_hat[2i+1] = E(g_i), O(g_i), g_i = 17^(2*brv7(i)+1) mod q
Co the dung them phan mem khac (vd thu vien ML-KEM/Kyber) lam mo hinh thu 3: tao file dap an bang
  python tools/check_ntt.py --mode ntt --in data/ntt_input_single.txt --gen data/ntt_ref.txt
roi so file cua ban voi file do bang cong cu so sanh file bat ky.
LUU Y: ban C tham chieu pq-crystals/kyber (ntt.c) tra he so o dang Montgomery/co dau; muon so voi IP phai dua ve [0,q).
INTT cua IP mac dinh co nhan 128^-1 (INTT_SCALE=1). Neu dat INTT_SCALE=0 thi them --no-scale vao check_ntt.py.
Chua co Icarus/Vivado: python tools/rtl_model.py chay mo hinh cycle-accurate cua RTL de kiem FSM/dia chi/zeta.
