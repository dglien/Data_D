#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_ntt.py - Kiem tra ket qua cua IP NTT/INTT ML-KEM (file txt tu testbench) bang mo hinh chuan (phan mem).

Quy trinh:
  1) Testbench doc  <IN_FILE>  (he so dau vao, hex, 1 he so / dong, 256 dong / case)
  2) Testbench ghi  <OUT_FILE> (ket qua cua IP, cung dinh dang)
  3) Script nay lay <IN_FILE>, tinh NTT/INTT bang phan mem, roi so voi <OUT_FILE>.

Hai mo hinh chuan (theo FIPS 203 / ML-KEM, q = 3329, zeta = 17):
  fips   : thuat toan butterfly Algorithm 9 (NTT) / Algorithm 10 (INTT, co nhan 128^-1 = 3303)
  direct : dinh nghia toan hoc  f_hat[2i] = E(g_i), f_hat[2i+1] = O(g_i), g_i = 17^(2*brv7(i)+1)
           (a(X) = E(X^2) + X*O(X^2) ; ham nay doc lap voi thuat toan butterfly)
Mac dinh chay ca hai; ca hai phai trung nhau va trung voi IP.

Vi du:
  python tools/check_ntt.py --mode ntt  --in data/ntt_input_single.txt  --out data/ntt_output_single.txt
  python tools/check_ntt.py --mode intt --in data/ntt_output_single.txt --out data/intt_output_single.txt
  python tools/check_ntt.py --mode ntt  --in data/ntt_input_single.txt  --gen data/ntt_expected_single.txt
  python tools/check_ntt.py --mode intt --in data/ntt_output_single.txt --out data/intt_output_single.txt --no-scale
      (--no-scale: IP chay voi INTT_SCALE = 0 -> ket qua = 128 * f)
"""
import argparse, sys

Q = 3329
ZETA = 17                         # can bac 256 nguyen thuy cua 1 mod q
N = 256
INV_128 = pow(128, -1, Q)         # 3303 = 128^-1 mod q


def brv7(k):
    return int(format(k, '07b')[::-1], 2)


ZETAS = [pow(ZETA, brv7(k), Q) for k in range(128)]          # bang zeta FIPS 203 Appendix A (= zeta.coe)
GAMMA = [pow(ZETA, 2 * brv7(i) + 1, Q) for i in range(128)]  # nghiem cua Y^128 + 1 (X^2 = gamma_i)


# ---------------- mo hinh 1: butterfly (FIPS 203 Alg. 9 / 10) ----------------
def ntt_fips(a):
    f = a[:]
    k, ln = 1, 128
    while ln >= 2:
        for start in range(0, N, 2 * ln):
            z = ZETAS[k]; k += 1
            for j in range(start, start + ln):
                t = z * f[j + ln] % Q
                f[j + ln] = (f[j] - t) % Q
                f[j] = (f[j] + t) % Q
        ln //= 2
    return f


def intt_fips(a, scale=True):
    f = a[:]
    k, ln = 127, 2
    while ln <= 128:
        for start in range(0, N, 2 * ln):
            z = ZETAS[k]; k -= 1
            for j in range(start, start + ln):
                t = f[j]
                f[j] = (t + f[j + ln]) % Q
                f[j + ln] = z * (f[j + ln] - t) % Q
        ln *= 2
    return [INV_128 * x % Q for x in f] if scale else f


# ---------------- mo hinh 2: dinh nghia truc tiep ----------------
def ntt_direct(a):
    E, O = a[0::2], a[1::2]
    out = [0] * N
    for i in range(128):
        g = GAMMA[i]
        e = o = 0
        gp = 1
        for m in range(128):
            e += E[m] * gp
            o += O[m] * gp
            gp = gp * g % Q
        out[2 * i], out[2 * i + 1] = e % Q, o % Q
    return out


def intt_direct(a, scale=True):
    E, O = a[0::2], a[1::2]            # E[i] = f_hat[2i] = E(g_i) ; O[i] = f_hat[2i+1]
    ginv = [pow(g, -1, Q) for g in GAMMA]
    res = [0] * N
    for m in range(128):
        e = o = 0
        for i in range(128):
            w = pow(ginv[i], m, Q)
            e += E[i] * w
            o += O[i] * w
        # tong = 128 * he so  (khong nhan 1/128)
        res[2 * m], res[2 * m + 1] = e % Q, o % Q
    return [INV_128 * x % Q for x in res] if scale else res


# ---------------- doc / ghi file ----------------
def read_hex(path):
    vals = []
    with open(path) as f:
        for ln, line in enumerate(f, 1):
            t = line.strip()
            if not t:
                continue
            try:
                v = int(t, 16)
            except ValueError:
                sys.exit(f"[LOI] {path} dong {ln}: '{t}' khong phai so hex")
            if v >= Q:
                sys.exit(f"[LOI] {path} dong {ln}: {t} = {v} >= q ({Q})")
            vals.append(v)
    if len(vals) % N:
        sys.exit(f"[LOI] {path}: {len(vals)} dong, khong chia het cho {N}")
    return vals


def write_hex(path, vals):
    with open(path, 'w') as f:
        for v in vals:
            f.write("%03X\n" % v)


def main():
    ap = argparse.ArgumentParser(description="Kiem tra ket qua NTT/INTT ML-KEM cua IP bang mo hinh phan mem chuan")
    ap.add_argument('--mode', choices=['ntt', 'intt'], required=True)
    ap.add_argument('--in', dest='infile', required=True, help="file he so dau vao (da dua vao IP)")
    ap.add_argument('--out', dest='outfile', help="file ket qua cua IP (testbench ghi ra)")
    ap.add_argument('--expected', help="(tuy chon) file dap an co san de so them")
    ap.add_argument('--gen', help="(tuy chon) ghi dap an cua phan mem ra file nay")
    ap.add_argument('--ref', choices=['fips', 'direct', 'both'], default='both')
    ap.add_argument('--no-scale', action='store_true', help="INTT khong nhan 128^-1 (IP dung INTT_SCALE=0)")
    ap.add_argument('--maxshow', type=int, default=5, help="so he so sai in ra cho moi case")
    args = ap.parse_args()

    inp = read_hex(args.infile)
    ncase = len(inp) // N
    sc = not args.no_scale
    f_fips = ntt_fips if args.mode == 'ntt' else (lambda a: intt_fips(a, sc))
    f_dir = ntt_direct if args.mode == 'ntt' else (lambda a: intt_direct(a, sc))

    ref = []
    for c in range(ncase):
        a = inp[c * N:(c + 1) * N]
        r1 = f_fips(a) if args.ref in ('fips', 'both') else None
        r2 = f_dir(a) if args.ref in ('direct', 'both') else None
        if r1 is not None and r2 is not None and r1 != r2:
            sys.exit(f"[LOI NOI BO] case {c}: hai mo hinh phan mem khong trung nhau")
        ref += (r1 if r1 is not None else r2)
    print(f"Mo hinh: {args.mode.upper()} | {ncase} case x {N} he so | tham chieu = {args.ref}"
          + (" (butterfly == dinh nghia truc tiep)" if args.ref == 'both' else ""))

    if args.gen:
        write_hex(args.gen, ref)
        print(f"Da ghi dap an phan mem: {args.gen}")

    targets = []
    if args.outfile:
        targets.append(("IP", args.outfile, ref))
    if args.expected:
        exp = read_hex(args.expected)
        if len(exp) != len(ref):
            sys.exit(f"[LOI] {args.expected} co {len(exp)} dong, mong doi {len(ref)}")
        targets.append(("file dap an", args.expected, ref))
    if not targets:
        print("Khong co --out/--expected de so sanh.")
        return 0

    ok_all = True
    for name, path, ref_vals in targets:
        got = read_hex(path)
        if len(got) != len(ref_vals):
            print(f"[FAIL] {name} ({path}): {len(got)} dong, mong doi {len(ref_vals)}")
            ok_all = False
            continue
        bad_cases = []
        for c in range(ncase):
            g = got[c * N:(c + 1) * N]
            r = ref_vals[c * N:(c + 1) * N]
            bad = [i for i in range(N) if g[i] != r[i]]
            if bad:
                bad_cases.append(c)
                print(f"  case {c:3d}: FAIL {len(bad)}/{N} he so sai")
                for i in bad[:args.maxshow]:
                    print(f"      [{i:3d}] IP={g[i]:03X} ({g[i]})  PHAN MEM={r[i]:03X} ({r[i]})")
        if bad_cases:
            ok_all = False
            print(f"[FAIL] {name} ({path}): {len(bad_cases)}/{ncase} case sai: {bad_cases[:10]}")
        else:
            print(f"[PASS] {name} ({path}): {ncase}/{ncase} case khop mo hinh phan mem")
    return 0 if ok_all else 1


if __name__ == '__main__':
    sys.exit(main())
