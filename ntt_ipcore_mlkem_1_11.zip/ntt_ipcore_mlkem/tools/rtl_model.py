#!/usr/bin/env python3
"""rtl_model.py - mo hinh cycle-accurate (Python) cua ntt_control.v + ram_a + rom_zeta + butterfly.
Dung de kiem logic FSM/dia chi/zeta/SCALE khi KHONG co trinh mo phong Verilog.
Chay:  python tools/rtl_model.py [--no-scale]"""
import sys, re, os
sys.path.insert(0, os.path.dirname(__file__))
from check_ntt import ntt_fips, intt_fips, ZETAS, Q, INV_128, read_hex

T_IDLE, T_LOAD, T_EX, T_READ, T_FIN = range(5)
B_IDLE, B_READ, B_EX, B_WR, B_NBF, B_NGRP, B_NSTG, B_SCALE, B_DONE = range(9)

class Core:
    def __init__(s, intt_scale=1):
        s.INTT_SCALE = intt_scale
        s.mem = [0]*256; s.douta = s.doutb = 0; s.zeta = 0
        s.valid_a = 0; s.rd_d = 0
        s.st_top = T_IDLE; s.mode_r = 0; s.done_r = 0; s.dout_vld = 0; s.cnt_data = 0
        s.st_bf = B_IDLE
        s.j_cnt = s.start_r = s.len = s.i_cnt = s.stage_cnt = s.scale_cnt = 0
        s.pipe = [None]*6           # butterfly pipeline (valid_in -> valid_out = 7 cycles)
        s.y0 = s.y1 = 0; s.valid_out = 0
        s.bf_count = s.wr_count = 0
        s.out = {}; s.trace = []

    def bf_func(s, a, b, z, mode, scale):
        if scale: return a, a*INV_128 % Q
        if not mode:
            t = z*b % Q; return (a+t) % Q, (a-t) % Q
        return (a+b) % Q, (a-b)*(Q-z) % Q

    def step(s, start, mode, ext_wr_en, ext_din):
        # ---------- combinational ----------
        rd_done = s.cnt_data >= 256
        sel_proc = s.st_top == T_EX
        calc_done = s.st_bf == B_DONE
        scale = s.st_bf == B_SCALE
        scale_en = s.mode_r and s.INTT_SCALE
        # top FSM
        nst_top = s.st_top; cnt_clr = 0; load_en = 0; top_we = 0; top_re = 0
        if s.st_top == T_IDLE:
            cnt_clr = 1
            if start: nst_top = T_LOAD
        elif s.st_top == T_LOAD:
            top_we = (not rd_done) and ext_wr_en; load_en = top_we
            if rd_done: nst_top = T_EX
        elif s.st_top == T_EX:
            cnt_clr = 1
            if calc_done: nst_top = T_READ
        elif s.st_top == T_READ:
            top_re = (not rd_done) and not s.valid_a and not s.dout_vld
            load_en = s.dout_vld
            if rd_done: nst_top = T_FIN
        elif s.st_top == T_FIN:
            if not start: nst_top = T_IDLE
        # counters/addresses
        j_abs = s.start_r + s.j_cnt
        addr_a = j_abs & 255
        addr_b = (s.scale_cnt & 255) if scale else ((j_abs + s.len) & 255)
        nxt_start = s.start_r + 2*s.len
        j_end = (s.j_cnt + 1) >= s.len
        grp_end = nxt_start >= 256
        last_stg = s.stage_cnt >= 7
        k_end = s.scale_cnt >= 256
        j_sc_end = s.j_cnt >= 256
        # butterfly FSM
        nst_bf = s.st_bf
        c = dict(cnt_clr=0,j_clr=0,j_en=0,start_clr=0,start_ld=0,i_en=0,upd_len=0,stage_en=0,k_en=0)
        rom_en = wr_a = wr_b = rd_a = rd_b = 0
        if s.st_bf == B_IDLE:
            c['cnt_clr'] = 1
            if s.st_top == T_LOAD and rd_done: nst_bf = B_READ
        elif s.st_bf == B_READ:
            rd_a = rd_b = rom_en = 1; nst_bf = B_EX
        elif s.st_bf == B_EX:
            if s.valid_out: nst_bf = B_WR
        elif s.st_bf == B_WR:
            wr_a = wr_b = 1
            if not j_end: c['j_en'] = 1; nst_bf = B_NBF
            elif not grp_end: c['j_en'] = 1; nst_bf = B_NGRP
            elif not last_stg: c['j_en'] = 1; nst_bf = B_NSTG
            elif scale_en: c['j_clr'] = 1; c['start_clr'] = 1; nst_bf = B_SCALE
            else: nst_bf = B_DONE
        elif s.st_bf == B_NBF: nst_bf = B_READ
        elif s.st_bf == B_NGRP:
            c['start_ld'] = c['j_clr'] = c['i_en'] = 1; nst_bf = B_READ
        elif s.st_bf == B_NSTG:
            c['upd_len'] = c['start_clr'] = c['j_clr'] = c['i_en'] = c['stage_en'] = 1; nst_bf = B_READ
        elif s.st_bf == B_SCALE:
            if not j_sc_end: rd_a = 1; c['j_en'] = 1
            if s.valid_out: wr_b = 1; c['k_en'] = 1
            if k_end: nst_bf = B_DONE
        elif s.st_bf == B_DONE: nst_bf = B_IDLE
        valid_in = s.rd_d or (scale and s.valid_a)
        # RAM mux
        we_a = wr_a if sel_proc else top_we
        re_a = rd_a if sel_proc else top_re
        adr_a = addr_a if sel_proc else (s.cnt_data & 255)
        wd_a = s.y0 if sel_proc else ext_din
        we_b = sel_proc and wr_b; re_b = sel_proc and rd_b
        # ---------- sequential (tat ca dung gia tri cu) ----------
        old = dict(douta=s.douta, doutb=s.doutb)
        a_in, b_in, z_in = s.douta, s.doutb, s.zeta     # gia tri tai chu ky nay
        mode_bf = s.mode_r
        if we_a or re_a:
            if we_a: s.mem_w = (adr_a, wd_a)
            s.douta = s.mem[adr_a]
        if we_b or re_b:
            s.doutb = s.mem[addr_b]
        if we_a: s.mem[adr_a] = wd_a
        if we_b: s.mem[addr_b] = s.y1
        if we_a and sel_proc: s.wr_count += 1
        if rom_en: s.zeta = ZETAS[s.i_cnt & 127]
        if s.st_top == T_READ and s.valid_a is not None and False: pass
        ext_rvalid = s.dout_vld
        if ext_rvalid: s.out[s.cnt_data & 255] = a_in   # ext_rdata = rdata_a (tai chu ky co valid)
        s.valid_a = 1 if re_a or we_a and False else (1 if re_a else 0)
        # butterfly pipeline
        res = None
        if valid_in:
            res = s.bf_func(a_in, 0 if scale else b_in, z_in, mode_bf, scale)
            if not scale: s.bf_count += 1
        last = s.pipe[5]
        s.valid_out = 1 if last is not None else 0
        if last is not None: s.y0, s.y1 = last
        s.pipe = [res] + s.pipe[:5]
        s.rd_d = 1 if s.st_bf == B_READ else 0
        # counters
        if c['j_clr'] or c['cnt_clr']: s.j_cnt = 0
        elif c['j_en']: s.j_cnt += 1
        if c['start_clr'] or c['cnt_clr']: s.start_r = 0
        elif c['start_ld']: s.start_r = nxt_start
        if c['cnt_clr']: s.len = 2 if s.mode_r else 128
        elif c['upd_len']: s.len = (s.len*2) if s.mode_r else (s.len//2)
        if c['cnt_clr']: s.i_cnt = 127 if s.mode_r else 1
        elif c['i_en']: s.i_cnt = (s.i_cnt-1) & 255 if s.mode_r else (s.i_cnt+1) & 255
        if c['cnt_clr']: s.stage_cnt = 1
        elif c['stage_en']: s.stage_cnt += 1
        if c['cnt_clr']: s.scale_cnt = 0
        elif c['k_en']: s.scale_cnt += 1
        # top regs
        if s.st_top == T_IDLE: s.mode_r = mode
        if s.st_top == T_FIN: s.done_r = 1
        elif s.st_top == T_IDLE and start: s.done_r = 0
        if s.st_top == T_READ:
            if s.valid_a_prev: s.dout_vld = 1
            elif s.dout_vld: s.dout_vld = 0
        else: s.dout_vld = 0
        if cnt_clr: s.cnt_data = 0
        elif load_en: s.cnt_data += 1
        s.st_top, s.st_bf = nst_top, nst_bf
        return top_we

    valid_a_prev = 0

def run(vec, mode, intt_scale=1):
    c = Core(intt_scale)
    # valid_a duoc dung trong T_READ la gia tri CU (thanh ghi) -> sua: dung bien rieng
    cycles = 0
    def tick(start, ext_wr, din):
        c.valid_a_prev = c.valid_a
        c.step(start, mode, ext_wr, din)
    tick(0,0,0); tick(0,0,0)
    tick(1,0,0); tick(0,0,0)
    guard = 0
    while c.st_top != T_FIN and guard < 400000:
        # cap du lieu: ext_din = mem_in[ext_addr] (tb tra theo dia chi hien tai)
        addr = c.cnt_data & 255
        tick(0, 1, vec[addr]); guard += 1
        if c.st_top == T_IDLE: break
    return c, guard

if __name__ == '__main__':
    scale = 0 if '--no-scale' in sys.argv else 1
    here = os.path.dirname(os.path.abspath(__file__))
    vec = read_hex(os.path.join(here, '..', 'data', 'ntt_input_single.txt'))
    ok = True
    c, g = run(vec, 0)
    got = [c.out.get(i, -1) for i in range(256)]
    exp = ntt_fips(vec)
    print("NTT : cycles=%d butterflies=%d writes=%d match=%s" % (g, c.bf_count, c.wr_count, got == exp))
    ok &= got == exp
    c2, g2 = run(got, 1, scale)
    got2 = [c2.out.get(i, -1) for i in range(256)]
    exp2 = intt_fips(got, bool(scale))
    print("INTT: cycles=%d butterflies=%d match_model=%s roundtrip=%s" % (g2, c2.bf_count, got2 == exp2, got2 == vec))
    ok &= got2 == exp2
    sys.exit(0 if ok else 1)
