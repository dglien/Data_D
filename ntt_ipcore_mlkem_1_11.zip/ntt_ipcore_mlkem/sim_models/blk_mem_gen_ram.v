// MODEL MO PHONG cua Block Memory Generator: True Dual Port RAM 256x12, common clock,
// Operating Mode = Read First, Use ENA/ENB, KHONG output register (latency doc = 1).
//   doc : ena=1, wea=0  -> douta cap nhat sau 1 chu ky
//   ghi : ena=1, wea=1  (douta nhan gia tri cu - read first)
//   ena=0 -> douta giu nguyen
// Khi dung Vivado, bo file nay, dung IP blk_mem_gen_ram sinh ra.
module blk_mem_gen_ram (
    input  wire        clka,
    input  wire        ena,
    input  wire [0:0]  wea,
    input  wire [7:0]  addra,
    input  wire [11:0] dina,
    output reg  [11:0] douta,
    input  wire        clkb,
    input  wire        enb,
    input  wire [0:0]  web,
    input  wire [7:0]  addrb,
    input  wire [11:0] dinb,
    output reg  [11:0] doutb
);
    reg [11:0] mem [0:255];
    integer i;
    initial begin
        for (i = 0; i < 256; i = i + 1) mem[i] = 12'd0;
        douta = 12'd0; doutb = 12'd0;
    end
    always @(posedge clka) if (ena) begin
        if (wea) mem[addra] <= dina;
        douta <= mem[addra];
    end
    always @(posedge clkb) if (enb) begin
        if (web) mem[addrb] <= dinb;
        doutb <= mem[addrb];
    end
endmodule
