# ---------------------------------------------------------------------------
# Ham tien ich tao nhom tin hieu trong cua so Waveform cua Vivado
#   add_grp  <ten nhom> <duong dan scope> <danh sach tin hieu> [radix]
#   add_div  <chu thich>   : vach ngan co chu
# ---------------------------------------------------------------------------
proc add_grp {name scope sigs {radix hex}} {
    set g [add_wave_group $name]
    foreach s $sigs {
        add_wave -into $g -radix $radix ${scope}/${s}
    }
    return $g
}
proc add_div {txt} {
    add_wave_divider $txt
}
