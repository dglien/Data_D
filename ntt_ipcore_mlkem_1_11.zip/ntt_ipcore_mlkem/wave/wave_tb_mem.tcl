set T /tb_mem
remove_wave [get_waves -quiet *]
add_grp "CLK_RST" $T {clk rst_n} bin
add_div "===== rom_zeta ====="
add_grp "ROM : rom_zeta" $T {rom_en rom_addr rom_z rom_v} hex
add_grp "ROM : IP blk_mem_gen_zeta" $T/u_rom_zeta/u_bram {clka ena addra douta} hex
add_div "===== ram_a ====="
add_grp "MUX / chon nguon" $T {sel} bin
add_grp "FSM Top -> ram_a" $T {t_we t_re t_addr t_wd} hex
add_grp "Butterfly PORT A" $T {a_we a_re a_ad a_wd} hex
add_grp "Butterfly PORT B" $T {b_we b_re b_ad b_wd} hex
add_grp "RAM ra" $T {rd_a v_a rd_b v_b} hex
add_grp "RAM : IP blk_mem_gen_ram" $T/u_ram_a/u_bram {ena wea addra dina douta enb web addrb dinb doutb} hex
add_grp "CHECK" $T {k errors} unsigned
save_wave_config tb_mem.wcfg
