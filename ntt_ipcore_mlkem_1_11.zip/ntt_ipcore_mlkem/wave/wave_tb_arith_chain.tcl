# source wave_common.tcl truoc, roi source file nay  (xem huong dan trong tra loi)
set T /tb_arith_chain
remove_wave [get_waves -quiet *]

add_grp "00_CLK_RST_PHASE" $T {clk rst_n} bin
add_grp "00_PHASE (PHAN dang chay)" $T {phase cur_op} ascii

add_div "===== ADD ====="
add_grp "ADD  (mod_add, latency 1)" $T {add_v add_a add_b add_r add_done} hex
add_div "===== SUB ====="
add_grp "SUB  (mod_sub, latency 1)" $T {sub_v sub_a sub_b sub_r sub_done} hex
add_div "===== MUL ====="
add_grp "MUL  (mod_mul Barrett, latency 5)" $T {mul_v mul_a mul_b mul_r mul_done} hex
add_grp "MUL pipeline noi bo (S1..S5)" $T/u_mul {valid_in v1 v2 v3 v4 done p1 p2 m2 tq3 r4 result} hex

add_div "===== PHAN 1-2 : ket qua chuoi ADD>SUB>MUL ====="
add_grp "CHAIN (r1=add, r2=sub, r3=mul)" $T {k r1 r2 r3 r} hex

add_div "===== PHAN 4 : BUTTERFLY ghep tu add/sub/mul ====="
add_grp "BUTTERFLY (a,b,z,t,o0,o1,d)" $T {ba bb_ bz bt bo0 bo1 bd} hex

add_div "===== PHAN 3 : STREAMING + kiem tra ====="
add_grp "STREAM / CHECK" $T {stream_en i_add i_sub i_mul e_add e_sub e_mul errors} unsigned

save_wave_config tb_arith_chain.wcfg
