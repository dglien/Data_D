set T /tb_ntt_control
remove_wave [get_waves -quiet *]
add_grp "CLK_RST" $T {clk rst_n} bin

add_div "===== TESTBENCH -> TOP : start / write_enable / doc ra ====="
add_grp "DIEU KHIEN (start, mode)" $T {start mode} bin
add_grp "GHI VAO RAM (ext_wr_en, ext_addr, ext_din)" $T {din_ready wr_en ext_addr ext_data} hex
add_grp "DOC RA (ext_rvalid, ext_addr, ext_rdata)" $T {dout_valid ext_addr dout} hex
add_grp "TRANG THAI (busy, done)" $T {busy done} bin

add_div "===== u_control : FSM_TOPCORE ====="
add_grp "STATE FSM_TOPCORE" $T {name_top} ascii
add_grp "TOP counter / tin hieu" $T/dut {cnt_data cnt_data_clr load_en mode_r rd_done calc_done dout_vld sel_proc ext_ready ext_rvalid} hex

add_div "===== u_control : FSM_BUTTERFLY ====="
add_grp "STATE FSM_BUTTERFLY" $T {name_bf} ascii
add_grp "BF counter (j_cnt,start_r,len,i,stage_cnt,scale_cnt)" $T/dut {j_cnt start_r len i_cnt stage_cnt scale_cnt} unsigned
add_grp "BF flag ket thuc" $T/dut {j_end grp_end last_stg k_end} bin

add_div "===== u_ram_a ====="
add_grp "RAM sel / port A (sau MUX)" $T/u_ram_a {sel_proc we_a re_a adr_a wdata_a rdata_a valid_a} hex
add_grp "RAM port B" $T/u_ram_a {we_b re_b addr_b wr_data_b rdata_b valid_b} hex

add_div "===== u_rom_zeta ====="
add_grp "ROM ZETA" $T/u_rom_zeta {rom_en zeta_addr zeta zeta_valid} hex

add_div "===== u_butterfly ====="
add_grp "BF vao (a,b,z)" $T/u_butterfly {valid_in mode scale a b z} hex
add_grp "BF add/sub dung chung (u_mod_add + u_mod_sub)" $T/u_butterfly {as_valid as_a as_b add_r sub_r add_done} hex
add_grp "BF mul dung chung (u_mod_mul)" $T/u_butterfly {mul_valid mul_x mul_y z_1 mul_done mul_t} hex
add_grp "BF chon ngo ra CT/GS" $T/u_butterfly {fin_valid fin_y0 fin_y1} hex
add_grp "BF ra (o0,o1)" $T/u_butterfly {valid_out y0 y1} hex

add_div "===== Dem & kiem tra ====="
add_grp "DEM STATE" $T {n_load n_ex n_read n_fin n_rd n_exb n_wr n_nbf n_ng n_ns n_sc n_scw out_idx errors cyc} unsigned
save_wave_config tb_ntt_control.wcfg
