set T /tb_all
remove_wave [get_waves -quiet *]
add_grp "CLK_RST" $T {clk rst_n} bin
add_grp "00_STAGE (buoc dang chay)" $T {stage} ascii
add_div "===== S1 ADD ====="
add_grp "ADD  (mod_add)" $T {add_v add_a add_b add_r add_done} hex
add_div "===== S2 SUB ====="
add_grp "SUB  (mod_sub)" $T {sub_v sub_a sub_b sub_r sub_done} hex
add_div "===== S3 MUL ====="
add_grp "MUL  (mod_mul Barrett)" $T {mul_v mul_a mul_b mul_r mul_done} hex
add_grp "  pipeline mod_mul" $T/u_mul {v1 v2 v3 v4 p1 p2 m2 tq3 r4} hex
add_div "===== S4 BUTTERFLY doc lap ====="
add_grp "BFU vao" $T {bfu_v bfu_gs bfu_sc bfu_a bfu_b bfu_z} hex
add_grp "BFU add/sub dung chung" $T/u_bf_unit {as_valid as_a as_b add_r sub_r add_done} hex
add_grp "BFU mul dung chung (u_mod_mul)" $T/u_bf_unit {mul_valid mul_x mul_y z_1 mul_done mul_t} hex
add_grp "BFU chon ngo ra chon ngo ra (CT/GS)" $T/u_bf_unit {fin_valid fin_y0 fin_y1} hex
add_grp "BFU ra" $T {bfu_ov bfu_o0 bfu_o1} hex
add_div "===== S5-S6 TOAN IP ntt_ip_v1_0 ====="

add_div "===== TESTBENCH -> TOP : start / write_enable / doc ra ====="
add_grp "DIEU KHIEN (start, mode)" $T {start mode} bin
add_grp "GHI VAO RAM (ext_wr_en, ext_addr, ext_din)" $T {din_ready wr_en ext_addr ext_data} hex
add_grp "DOC RA (ext_rvalid, ext_addr, ext_rdata)" $T {dout_valid ext_addr dout} hex
add_grp "TRANG THAI (busy, done)" $T {busy done} bin

add_div "===== u_control : FSM_TOPCORE ====="
add_grp "STATE FSM_TOPCORE" $T {name_top} ascii
add_grp "TOP counter / tin hieu" $T/dut/u_control {cnt_data cnt_data_clr load_en mode_r rd_done calc_done dout_vld sel_proc ext_ready ext_rvalid} hex

add_div "===== u_control : FSM_BUTTERFLY ====="
add_grp "STATE FSM_BUTTERFLY" $T {name_bf} ascii
add_grp "BF counter (j_cnt,start_r,len,i,stage_cnt,scale_cnt)" $T/dut/u_control {j_cnt start_r len i_cnt stage_cnt scale_cnt} unsigned
add_grp "BF flag ket thuc" $T/dut/u_control {j_end grp_end last_stg k_end} bin

add_div "===== u_ram_a ====="
add_grp "RAM sel / port A (sau MUX)" $T/dut/u_ram_a {sel_proc we_a re_a adr_a wdata_a rdata_a valid_a} hex
add_grp "RAM port B" $T/dut/u_ram_a {we_b re_b addr_b wr_data_b rdata_b valid_b} hex

add_div "===== u_rom_zeta ====="
add_grp "ROM ZETA" $T/dut/u_rom_zeta {rom_en zeta_addr zeta zeta_valid} hex

add_div "===== u_butterfly ====="
add_grp "BF vao (a,b,z)" $T/dut/u_butterfly {valid_in mode scale a b z} hex
add_grp "BF add/sub dung chung (u_mod_add + u_mod_sub)" $T/dut/u_butterfly {as_valid as_a as_b add_r sub_r add_done} hex
add_grp "BF mul dung chung (u_mod_mul)" $T/dut/u_butterfly {mul_valid mul_x mul_y z_1 mul_done mul_t} hex
add_grp "BF chon ngo ra CT/GS" $T/dut/u_butterfly {fin_valid fin_y0 fin_y1} hex
add_grp "BF ra (o0,o1)" $T/dut/u_butterfly {valid_out y0 y1} hex

add_div "===== Dem & kiem tra ====="
add_grp "DEM STATE" $T {n_load n_ex n_read n_fin n_rd n_exb n_wr n_nbf n_ng n_ns n_sc n_scw out_idx errors cyc} unsigned
save_wave_config tb_all.wcfg
