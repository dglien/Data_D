set T /tb_butterfly
remove_wave [get_waves -quiet *]
add_grp "CLK_RST" $T {clk rst_n} bin
add_grp "MODE dang chay" $T {cur_mode} ascii
add_div "===== VAO ====="
add_grp "VAO (valid, gs, scale, a, b, z)" $T {v gs sc a b z} hex
add_div "===== add/sub + mul dung chung ====="
add_grp "add/sub dung chung (u_mod_add + u_mod_sub)" $T/dut {as_valid as_a as_b add_r sub_r add_done} hex
add_div "===== S1-5 : u_mod_mul (Barrett) ====="
add_grp "mul dung chung (u_mod_mul)" $T/dut {mul_valid mul_x mul_y z_1 mul_done mul_t} hex
add_grp "  pipeline noi bo mod_mul" $T/dut/u_mod_mul {v1 v2 v3 v4 p1 p2 m2 tq3 r4} hex
add_div "===== ngo ra ====="
add_grp "chon ngo ra CT/GS" $T/dut {fin_valid fin_y0 fin_y1} hex
add_div "===== RA ====="
add_grp "RA (o0, o1, valid_out)" $T {ov o0 o1} hex
add_grp "STREAM / CHECK" $T {stream_en iss rcv err_s err_lat errors} unsigned
save_wave_config tb_butterfly.wcfg
