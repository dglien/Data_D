CACH DUNG (Vivado, sau khi da Run Simulation > Run Behavioral Simulation)
1) Trong Tcl Console cua Vivado:
       cd <duong_dan_toi_thu_muc_wave>
       source wave_common.tcl
       source wave_tb_arith_chain.tcl      ;# hoac wave_tb_mem / wave_tb_butterfly / wave_tb_all
       restart
       run all
   (Script tu luu them file .wcfg cung thu muc; lan sau chi can File > Open Waveform Configuration.)
2) Doi radix cua mot nhom: chuot phai vao tin hieu > Radix.
3) Tin hieu ten dang chu (name_top, name_bf, phase, cur_op) dung radix ASCII de doc ten state/phep.
